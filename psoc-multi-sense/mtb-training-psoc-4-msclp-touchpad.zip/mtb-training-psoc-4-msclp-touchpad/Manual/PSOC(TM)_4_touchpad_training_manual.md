# PSOC&trade; 4 E3 training manual: Touchpad

## About this document

### Scope and purpose

This document is a training manual for the hands-on labs covering the implementation and tuning of touchpads using 5th generation CAPSENSE&trade; (MSCLP) on PSOC&trade; 4 devices. It covers both self-capacitance (CSD-RM) and mutual-capacitance (CSX-RM) sensing techniques using the PSOC&trade; 4100T Plus.

### Intended audience

This manual is intended for design engineers, technicians, and developers of electronic systems.

## Table of contents

* [About this document](#about-this-document)
* [Introduction](#introduction)
* [Required development tools](#required-development-tools)
* [Prerequisites](#prerequisites)
* [Lab 1: CSD touchpad tuning](#lab-1-csd-touchpad-tuning)
* [Lab 2: CSX touchpad tuning](#lab-2-csx-touchpad-tuning)
* [Appendix A: Touchpad raw count filters](#appendix-a-touchpad-raw-count-filters)
* [Appendix B: Touchpad position filters](#appendix-b-touchpad-position-filters)
* [Appendix C: Touchpad adaptive IIR filter](#appendix-c-touchpad-adaptive-iir-filter)
* [Disclaimer](#disclaimer)

## Introduction

This manual provides step-by-step instructions to create, configure, and tune CAPSENSE&trade; touchpad projects on the PSOC&trade; 4100T Plus. In these lab sessions you will gain hands-on experience tuning both self-capacitance (CSD-RM) and mutual-capacitance (CSX-RM) touchpads, understand the key hardware parameters that affect touchpad performance, and learn how to use the CAPSENSE&trade; Tuner to validate SNR and set threshold parameters.

## Required development tools

* **ModusToolbox&trade; software** v3.9 or later (Recommended installation via [ModusToolbox&trade; Setup tool](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup))
* [**Microsoft Visual Studio Code**](https://code.visualstudio.com/) with the [**ModusToolbox&trade; for VS Code**](https://marketplace.visualstudio.com/items?itemName=InfineonAG.modustoolbox-for-vscode) extension installed
* **ModusToolbox&trade; Programming Tools** v1.9.0 or later (Installed by [ModusToolbox&trade; Setup tool](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup) as a dependency to ModusToolbox&trade; v3.9)
* **ModusToolbox&trade; CAPSENSE&trade; and Multi-Sense Pack** v1.6.0 or later (Recommended installation via [ModusToolbox&trade; Setup tool](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup))
* **PSOC 4100T Plus Prototyping Kit** ([CY8CPROTO-041TP](https://www.infineon.com/evaluation-board/CY8CPROTO-041TP))
   

    <img src="assets/images/CY8CPROTO_041TP.png" alt="PSOC 4100T Plus prototyping kit" style="width:300px; height:auto; display:block; margin:0 auto;" />

## Prerequisites

Install the software and obtain hardware listed in the [Required development tools](#required-development-tools) section.


This class will not cover basic concepts of ModusToolbox&trade; and PSOC&trade; 4100T Plus.

* For an introduction to PSOC&trade;, including a getting started guide to ModusToolbox&trade;, visit [PSOC&trade; developer](https://www.infineon.com/product-information/psocdeveloper).
* PSOC&trade; 4 CAPSENSE&trade; using PSOC&trade; 4000T and PSOC&trade; 4100T Plus training, visit [PSOC&trade; 4 CAPSENSE&trade; training](https://github.com/Infineon/mtb-training-psoc-4-msclp-capsense).


## Lab 1: CSD touchpad tuning

### Objective

In this lab, you will create and tune the MSCLP Low Power CSD (self-capacitance) Touchpad example. You will follow the full tuning procedure, from setting initial hardware parameters through to final threshold configuration, using the CSD-RM sensing technique and the CAPSENSE&trade; Tuner. The project used has already been tuned, so you may find that ultimately the settings chosen will be the same or very similar to what was in the project to start with. 

### Project creation

1. <span id="step1-workspace-creation"></span>Open **ModusToolbox&trade;** from the **Windows Start** menu

> **Note:** If you have not installed ModusToolbox&trade;, see the [Required development tools](#required-development-tools) section.


<img src="assets/images/opening_modustoolbox_from_windows_11_start.png" alt="Running ModusToolbox Dashboard" style="width:427px; height:auto; display:block; margin:0 auto;" />

2. <span id="step2-directory-selection"></span> Select your **Target IDE** (this lab manual demonstrates the use of **Microsoft Visual Studio Code**), and then click **Launch Project Creator**

<img src="assets/images/launch_project_creator.png" alt="Launching Project Creator" style="width:1200px; height:auto; display:block; margin:0 auto;" />

3. The **Project Creator** tool will first prompt you to choose a **BSP** (Board Support Package)

> **Note:** BSPs are aligned with the development/evaluation kits; they provide files for basic device functionality. A BSP typically has a `design.modus` file that configures clocks and other board-specific capabilities. That file is used by the ModusToolbox&trade; configurators. A BSP also includes the required device support code for the device on the board. You can modify the configuration to suit your application.

4. Once the **Project Creator** launches, select the **CY8CPROTO-041TP** BSP under the PSOC 4 BSPs, and then click **Next**


    <img src="assets/images/project_creator_cy8proto041tp_bsp_selection.png" alt="Project Creator BSP selection" style="width:800px; height:auto; display:block; margin:0 auto;" />

5. On the **Select Application** page, search for and select **MSCLP low-power self-capacitance touchpad** under the **Sensing** section, and then click **Create**


    <img src="assets/images/project_creator_csd_touchpad_selection.png" alt="Project Creator CSD touchpad application" style="width:800px; height:auto; display:block; margin:0 auto;" />

6. When you click **Create**, a new project is created. The project location is under the **Application root path**, in a folder with the given project name. Navigate to the project directory, and find the **.code-workspace** file and open it with Microsoft Visual Studio Code. 


<img src="assets/images/vscode_workspace_file.png" alt="VSCODE workspace file after project creation" style="width:400px; height:auto; display:block; margin:0 auto;" />

7. Once opened in Microsoft Visual Studio Code, make sure you have the **ModusToolbox&trade; for VS Code** extension installed. Once the extension is running, you will see the extension in the main panel. 

<img src="assets/images/vsocde_modustoolbox_extension.png" alt="VSCODE workspace file after project creation" style="width:1200px; height:auto; display:block; margin:0 auto;" />

<br>

> **Note:** VS Code may launch the workspace in **Restricted Mode**. If this happens, locate the blue ribbon under the taskbar indicating **Restricted Mode** and select **Manage**. A **Workspace Trust** window will pop up. Select **Trust** and close the window. The workspace will refresh and the ModusToolbox&trade; for VS Code extension will display after a brief delay.

<img src="assets/images/restricted_mode.png" alt="VS Code extension prompting to fix tasks and settings" style="width:1000px; height:auto; display:block; margin:0 auto;" />

<br>

> **Note:** The ModusToolbox&trade; for VS Code extension may display buttons indicating that the VS Code tasks and settings need to be updated. Simply click the buttons to correct the issues. This is a minor version mismatch between the ModusToolbox&trade; tools and the VS Code extension and does not affect functionality.

<img src="assets/images/vscode_fix_tasks_settings_prompt.png" alt="VS Code extension prompting to fix tasks and settings" style="width:800px; height:auto; display:block; margin:0 auto;" />

### Stage 1: Set the initial hardware parameters

1. In the ModusToolbox&trade; for VS Code extension, scroll down to **Tools**, and then open **CAPSENSE&trade; Configurator**

<img src="assets/images/launching_capsense_configurator_from_modustoolbox_vscode_extension.png" alt="Launching CAPSENSE Configurator" style="width:800px; height:auto; display:block; margin:0 auto;" />

2. In the **Basic** tab, confirm that a single touchpad widget, **TOUCHPAD_SELF_CAP**, is configured with **CSD RM (self-cap)** as the **Sensing Mode**


    <img src="assets/images/capsense_basictab.png" alt="CAPSENSE Basic tab for the CSD touchpad" style="width:800px; height:auto; display:block; margin:0 auto;" />

3. In the **Advanced** > **General** tab, set the following parameters:

    | Parameter | Setting | Comment |
    | --------- | ------- | ------- |
    | CAPSENSE&trade; IMO Clock frequency (MHz) | 46 | Clock source for the CAPSENSE&trade; peripheral |
    | Modulator clock divider | 1 | Achieves the optimum modulator clock frequency |
    | Number of init sub-conversions | 3 | Ensures proper initialization of CAPSENSE&trade; |

    > **Note:** Retain the default settings for all widget filters. Filters can be enabled later if needed to meet SNR requirements (see [Stage 5](#stage-5-fine-tune-sensitivity-to-improve-snr)). Using filters will increase scan time.


    <img src="assets/images/adv_general_csd.png" alt="CSD general settings" style="width:900px; height:auto; display:block; margin:0 auto;" />

4. In the **Advanced** > **CSD Settings** tab, make the following changes:

    | Parameter | Setting | Comment |
    | --------- | ------- | ------- |
    | Inactive sensor connection | Shield | Connects inactive sensors to the driven shield |
    | Shield mode | Active | Replicates the sensor-switching signal to reduce parasitic capacitance |
    | Total shield count | 2 | Number of dedicated shield electrodes |
    | Raw count calibration level (%) | 85 | Target raw count level; reduce if saturation occurs on touch |


    <img src="assets/images/csd_advanced.png" alt="CSD advanced settings" style="width:600px; height:auto; display:block; margin:0 auto;" />

5. In the **Advanced** > **Widget Details** tab, select **TOUCHPAD_SELF_CAP** and set the following initial widget parameters:

    | Parameter | Setting | Comment |
    | --------- | ------- | ------- |
    | Maximum X-Axis position | 255 | Position range for the X axis |
    | Maximum Y-Axis position | 255 | Position range for the Y axis |
    | Column sense clock divider | Default | Set in [Stage 2](#stage-2-set-the-sense-clock-frequency) |
    | Row sense clock divider | Default | Set in [Stage 2](#stage-2-set-the-sense-clock-frequency) |
    | Clock source | Direct | Constant frequency sense clock |
    | Number of sub-conversions | 12 | Starting point for scan time and signal; adjust in [Stage 5](#stage-5-fine-tune-sensitivity-to-improve-snr) |
    | Finger threshold | 20 | Low initial value to allow Touchpad View tracking during tuning |
    | Noise threshold | 10 | Baseline is not updated when raw count exceeds baseline + noise threshold |
    | Negative noise threshold | 10 | Baseline is not updated when raw count drops below baseline − negative noise threshold |
    | Hysteresis | 5 | Prevents status toggling due to noise |
    | ON debounce | 3 | Consecutive scans a sensor must be active before a touch is reported |


    <img src="assets/images/adv_widget_detail.png" alt="CSD widget detail settings" style="width:600px; height:auto; display:block; margin:0 auto;" />

6. In the **Scan Configuration** tab, confirm the electrode pins using the dropdown menus and assign scan slots using the **Auto-Assign Slots** option. Check the **Notice List** for any warnings or errors


    <img src="assets/images/scan-configuration.png" alt="CSD scan configuration" style="width:800px; height:auto; display:block; margin:0 auto;" />

7. Click **Save** to apply the settings

8. Program the device from the ModusToolbox&trade; for VS Code extension. 

<img src="assets/images/programming_device_from_modustoolbox_vscode_extension.png" alt="Program the Device" style="width:800px; height:auto; display:block; margin:0 auto;" />

### Stage 2: Set the sense clock frequency

The sense clock drives the CAPSENSE&trade; switched-capacitor circuits and must be set so that each scan phase allows the sensor capacitance to fully charge and discharge. Verify this by observing the sensor waveform with an oscilloscope and an active probe placed close to the electrode (not at the series resistor or sense pin).

A properly settled waveform shows the voltage reaching at least 99.3% of the target (5 Tau) at the end of each phase. An improperly settled waveform shows incomplete charging or discharging.


<img src="assets/images/csdrm-waveform.png" alt="Properly settled CSD-RM waveform" style="width:600px; height:auto; display:block; margin:0 auto;" />


<img src="assets/images/csdrm-waveform-improper.png" alt="Improperly settled CSD-RM waveform" style="width:600px; height:auto; display:block; margin:0 auto;" />

> **Note:** The sense clock divider for this project has already been set using the method in this stage. These steps are here to demonstrate how to find the proper sense clock frequency. 

1. Open the **CAPSENSE&trade; Tuner** from the ModusToolbox&trade; for VS Code extension

<img src="assets/images/launching_capsense_tuner_from_modustoolbox_vscode_extension.png" alt="Opening CAPSENSE Tuner" style="width:800px; height:auto; display:block; margin:0 auto;" />

2. Observe the charging waveform of the sensor on the oscilloscope

3. If the charging is incomplete, increase the sense clock divider. Select the sensor in the **CAPSENSE&trade; Tuner** and edit the **Sense Clock Divider** parameter in the **Widget/Sensor Parameters** panel

    > **Note:** The sense clock divider must be **divisible by 4** for CSD-RM. This ensures all four scan phases have equal durations.

    Click **Apply to Device** and observe the waveform again. Repeat until complete settling is observed.

4. Click **Apply to Project** to save the setting


    <img src="assets/images/sense_clock_divider_setting-csd.png" alt="CSD sense clock divider setting" style="width:400px; height:auto; display:block; margin:0 auto;" />

5. Repeat for all sensors. If multiple sensors share a scan slot, use the largest sense clock divider value across that slot for all sensors in it

    | Parameter | CY8CPROTO-041TP |
    | --------- | --------------- |
    | Sense clock divider | 28 |

### Stage 3: Measure sensor capacitance to set CDAC tuning mode

CDACs have inherent production tolerance that causes unit-to-unit variation in the measured signal. To compensate, MSCLP devices store CDAC trim codes in SFLASH (read-only). The middleware reads these trim codes to scale the Reference CDAC (Cref) and Fine CDAC (Cfine) values, reducing signal variation across units.

> **Note:** CDAC scaling is applicable to PSOC&trade; 4100T Plus devices only.

The effective parasitic capacitance (Cp) of a sensor has two contributors:

* **Csensor** – capacitance of the sensor electrode and traces, excluding the device pin
* **Cpin** – capacitance of the device pin (approximately 2.77 pF on PSOC&trade; 4100T Plus)

When Cp is small (below 4 pF), Cpin becomes a significant fraction of the total Cp and amplifies the impact of CDAC tolerance on signal variation. In this case, CDAC scaling must be enabled so the middleware can apply the SFLASH trim codes to Cref and Cfine.

CDAC scaling applies only when **all** of the following conditions are met:

* Sensor Cp is less than 4 pF
* Widget type is CSD (regular or low-power)
* Reference CDAC and Fine CDAC are set to **Manual** mode

If sensor Cp is 4 pF or greater, set CDAC tuning to **Auto** mode instead.

1. Stop the **CAPSENSE&trade; Tuner** and close it. In the ModusToolbox&trade; for VS Code extension, scroll down to **Tools**, open **CAPSENSE&trade; Configurator**, and then enable the BIST library to measure sensor Cp


    <img src="assets/images/bist_config.png" alt="BIST library configuration" style="width:900px; height:auto; display:block; margin:0 auto;" />

2. Add the **Cy_CapSense_RunSelfTest** API to measure the Cp of CSD widgets. It should be placed after the MSCLP block is initialized, but before the infinite for loop begins. 

    ```c
    /* Measures the actual ILO frequency and compensate MSCLP wake up timers */
    Cy_CapSense_IloCompensate(&cy_capsense_context);

    Cy_CapSense_RunSelfTest(CY_CAPSENSE_BIST_SNS_CAP_MASK, &cy_capsense_context);

    /* Configure the MSCLP wake up timer as per the ACTIVE mode refresh rate */
    Cy_CapSense_ConfigureMsclpTimer(ACTIVE_MODE_TIMER, &cy_capsense_context);
    ```
3. Program the device from the ModusToolbox&trade; for VS Code extension

4. Open the **CAPSENSE&trade; Tuner** from the ModusToolbox&trade; for VS Code extension and check the measured Cp values for each row and column sensor in the widget. Use the lowest measured value for the check to see if CDAC scaling is required


    <img src="assets/images/bist_cp.png" alt="Measured sensor capacitance values" style="width:400px; height:auto; display:block; margin:0 auto;" />

    * If **Cp > 4 pF**: set all CDAC parameters to **Auto** and proceed to [Stage 4](#stage-4-obtain-noise-and-crossover-point).
    * If **Cp ≤ 4 pF**: continue with the steps below to enable CDAC scaling.

    > **Note:** Disable the BIST library after measurement to reduce power consumption.

5. If Cp ≤ 4 pF, set all CDAC parameters to **Auto** in **CAPSENSE&trade; Configurator**


    <img src="assets/images/cdac_auto_config.png" alt="Automatic CDAC configuration" style="width:600px; height:auto; display:block; margin:0 auto;" />

6. Flash the device, open the **CAPSENSE&trade; Tuner** from the ModusToolbox&trade; for VS Code extension, and click **Apply to Project** to capture the auto-calculated CDAC values


    <img src="assets/images/cdac_values.png" alt="Calculated CDAC values" style="width:400px; height:auto; display:block; margin:0 auto;" />

7. Close **CAPSENSE&trade; Configurator**. In the ModusToolbox&trade; for VS Code extension, scroll down to **Tools**, and then open **CAPSENSE&trade; Configurator**. Enable **CDAC scaling**


    <img src="assets/images/enable_cdac_scale.png" alt="CDAC scaling enabled" style="width:1017px; height:auto; display:block; margin:0 auto;" />

8. Set the **Reference CDAC mode** and **Fine CDAC mode** to **Manual**. The values observed in step 4 are pre-populated


    <img src="assets/images/manual_CDAC.png" alt="Manual CDAC settings" style="width:1000px; height:auto; display:block; margin:0 auto;" />

9. Flash the device with the updated configuration. Open the **CAPSENSE&trade; Tuner** from the ModusToolbox&trade; for VS Code extension to verify the scaled parameters


    <img src="assets/images/cdac_trim.png" alt="Scaled CDAC trim values" style="width:383px; height:auto; display:block; margin:0 auto;" />

### Stage 4: Obtain noise and crossover point

1. In the **CAPSENSE&trade; Tuner**, navigate to the **Touchpad View** tab and verify that the raw counts of each sensor element are approximately 85% (± 5%) of MaxCount

    Change the **Display settings** as follows:

    | Parameter | Setting |
    | --------- | ------- |
    | Display mode | Touch reporting |
    | Data type | RawCount |
    | Value type | Current |
    | Number of samples | 1000 |


    <img src="assets/images/touchpad-view-rc-csd.png" alt="CSD touchpad raw count view" style="width:1200px; height:auto; display:block; margin:0 auto;" />

2. Measure the peak-to-peak noise for each sensor. In the **Widget Explorer**, select a column sensor, and then go to the **SNR Measurement** tab and click **Acquire Noise**


    <img src="assets/images/column-snr-noise.png" alt="Column sensor noise measurement" style="width:1200px; height:auto; display:block; margin:0 auto;" />

3. Do the same for a row sensor. 

    <img src="assets/images/row-snr-noise.png" alt="Row sensor noise measurement" style="width:1200px; height:auto; display:block; margin:0 auto;" />

    | Kit | Max noise – row sensors | Max noise – column sensors |
    | --- | ----------------------- | -------------------------- |
    | CY8CPROTO-041TP | 61 | 53 |

4. Observe the LTI (least touch intensity) signal. In the **Graph View** tab, swipe a 6 mm finger horizontally across the touchpad in the LTI position (the intersection of four nodes, farthest from the sensor pin connection) and note the lowest crossover point in the **Sensor Signal** graph


    <img src="assets/images/column-signal.png" alt="Column sensor signal" style="width:1200px; height:auto; display:block; margin:0 auto;" />

5. Repeat for the row direction by swiping vertically


    <img src="assets/images/row-signal.png" alt="Row sensor signal" style="width:1200px; height:auto; display:block; margin:0 auto;" />

    The following values are representative LTI measurements collected across multiple boards. The worked SNR example below uses the measurements shown in the screenshots from one development board, not these representative values.

    | Kit | LTI signal – row | LTI signal – column |
    | --- | ---------------- | ------------------- |
    | CY8CPROTO-041TP | 1200 | 1600 |

### Stage 5: Fine-tune sensitivity to improve SNR

The touchpad must achieve SNR > 5:1 to avoid false touches and ensure reliable detection.

> **Note:** For gesture detection, target SNR ≥ 10:1.

1. Calculate the SNR for both row and column sensors using Equation 1

    $$\text{SNR} = \frac{\text{LTI signal}}{\text{Peak-to-peak noise}}$$

    Using the single-board measurements from the noise and signal screenshots in [Stage 4](#stage-4-obtain-noise-and-crossover-point):

    * SNR (column) = 898 / 53 = 16.9
    * SNR (row) = 962 / 61 = 15.8

    Here, LTI is the measured signal amplitude. SNR is calculated separately by dividing that LTI measurement by the peak-to-peak noise.

2. If SNR < 5:1 or the LTI signal count is below 50, increase the **Number of sub-conversions** in the **Widget/Sensor Parameters** panel of the **CAPSENSE&trade; Tuner** in increments of 10. Click **Apply to Device** after each change

    > **Note:** The number of sub-conversions must be ≥ 8. Current consumption is proportional to the number of sub-conversions, so minimize this value while meeting the SNR requirement.

3. Enable filters in the **CAPSENSE&trade; Configurator** **Advanced** > **General** tab if the SNR requirement cannot be met with sub-conversions alone

    | Filter | Description |
    | ------ | ----------- |
    | Median | Eliminates noise spikes from motors and switching power supplies |
    | Average | Eliminates periodic noise (for example, from power supplies) |
    | First order IIR | Software filter that eliminates high-frequency noise; lower coefficient gives lower noise but slower response |
    | Hardware IIR | Eliminates high-frequency noise; lower coefficient means less filtering and higher response |

4. Once the SNR requirement is met, click **Apply to Project** to save the settings

### Stage 6: Tune threshold parameters

After confirming SNR > 5:1, set the threshold parameters. Thresholds are based on the LTI signal because it represents the weakest valid touch.

1. Set the following threshold values for the **TOUCHPAD_SELF_CAP** widget:

    | Parameter | Value | Guidance |
    | --------- | ----- | -------- |
    | Number of sub-conversions | 12 | – |
    | Finger threshold | 718 | 80% of the lower LTI signal (row or column) |
    | Noise threshold | 359 | Greater of: twice the highest noise, or 40% of the lower LTI signal |
    | Negative noise threshold | 359 | Same rule as Noise threshold |
    | Hysteresis | 90 | 10% of the lower LTI signal |
    | Low baseline reset | 30 | Default |
    | ON debounce | 3 | Default |

2. Click **Apply to Device** and then **Apply to Project** in the **CAPSENSE&trade; Tuner** to save the settings to both the device and the project


    <img src="assets/images/apply_to_project_csd.png" alt="Apply to Project for the CSD touchpad" style="width:387px; height:auto; display:block; margin:0 auto;" />

3. Close the **CAPSENSE&trade; Tuner**

### Expected result

After programming the board with the tuned project, test the touchpad as follows:

* Slide a finger over the touchpad. **LED3** brightness increases as the finger moves from left to right. **LED2** brightness increases as the finger moves from bottom to top.
* Open the **CAPSENSE&trade; Tuner** from the ModusToolbox&trade; for VS Code extension and confirm in the **Touchpad View** that the finger position is tracked accurately without false touches or discontinuities.


### Re-tuning

If you observe performance issues, consider the following troubleshooting steps:

* **Jumping or coordinate jumping from crossover point areas**:
  * Lower the **Noise threshold** and **Negative noise threshold** parameters.
* **Jittery touch coordinates**:

  * Enable widget filters, or increase the first-order IIR filter coefficient to smooth coordinate output. 
  * Refer to the detailed touchpad filter options and configuration steps in the appendixes:

    * [Appendix A: Touchpad raw count filters](#appendix-a-touchpad-raw-count-filters) (for reducing raw sensor noise)
    * [Appendix B: Touchpad position filters](#appendix-b-touchpad-position-filters) (for coordinate smoothing and stabilization)
    * [Appendix C: Touchpad adaptive IIR filter](#appendix-c-touchpad-adaptive-iir-filter) (for advanced speed-adaptive coordinate filtering)

### Optional further configuration of centroid and ballistic multiplier parameters

Advanced centroid parameters and ballistic multiplier options are configured in the **CAPSENSE&trade; Configurator** under the advanced widget details. These parameters are used to optimize position resolution on touchpads, handle edge inaccuracy, enable basic multi-finger behavior, and dynamically scale cursor speed.

1. If **CAPSENSE&trade; Configurator** is not already open, in the ModusToolbox&trade; for VS Code extension, scroll down to **Tools**, and then open **CAPSENSE&trade; Configurator**

2. Select the **Advanced** > **Widget Details** tab

3. Under the widget list in the left pane, select the CSD touchpad widget (**TOUCHPAD_SELF_CAP**)

4. Expand the **Centroid parameters** section in the right pane to configure touchpad coordinate tracking optimization:

    * **Centroid type**: Set to **5x5** (Advanced Centroid). The 5x5 centroid type calculates the touch centroid across a larger block of sensors, providing much-improved accuracy, and is required to enable **Edge correction** and **Pseudo two-finger detection**.
    * **Cross-coupling position threshold**: Leave this at the default value of **5**. This defines a signal threshold subtracted from the sensor signal before calculating the coordinate. Ideally, this should match the tiny raw count increase observed when a finger is hovering near (but not yet touching) a sensor.
    * **Edge correction**: Check the box to enable this feature. When a finger is on the edge of the touchpad, there are no neighboring sensors on one side to calculate a standard centroid properly, leading to coordinate non-linearities. Edge correction logically adds virtual sensors to resolve this effect.
    * **Virtual sensor threshold**: Used by the edge correction algorithm to calculate the simulated difference count of the virtual neighboring sensor on the edge.
    * **Penultimate threshold**: Defines the signal threshold on the penultimate (second-from-edge) sensor. Edge correction is only active if a local-maxima occurs on the absolute edge sensor and the penultimate sensor's signal is below this threshold.
    * **Pseudo two-finger detection**: Enable this checkbox to allow tracking of up to two touches. Because self-capacitance CSD scans rows and columns sequentially, two touches create "ghost" intersections that cannot be physically resolved (to get true independent multi-touch, use CSX). Pseudo two-finger detection reports two positions, which is suitable for basic two-finger gestures.


    <img src="assets/images/centroid_config.png" alt="Centroid parameter configuration" style="width:900px; height:auto; display:block; margin:0 auto;" />

5. Expand the **Ballistic multiplier parameters** section in the right pane to optimize cursor response:

    * **Ballistic multiplier**: Check the box to enable pointer acceleration. This feature helps provide a smoother user experience where fast finger movement moves the cursor across the screen faster (acceleration), while slow movements remain high-precision. Enabling this consumes 16 bytes of RAM per position.
    * **Acceleration coefficient**: Defines the multiplier used for position displacement under fast finger movement.
    * **Speed coefficient**: Defines the multiplier used for position displacement under slow finger movement.
    * **Divisor value**: Specifies the divisor used to scale down the multiplied acceleration/speed fractions.
    * **X-axis speed threshold** / **Y-axis speed threshold**: The coordinate change per scan threshold used to distinguish between fast and slow movements on each respective axis.

    <img src="assets/images/ballistic_multiplier_equation.png" alt="Ballistic multiplier equation" style="width:400px; height:auto; display:block; margin:0 auto;" />

    Together, these parameters define how the filtered displacement is calculated each scan. When the input displacement exceeds the speed threshold (fast movement), acceleration is applied:

    $$\text{dPosFiltered} = \text{dPos} \cdot \left(\frac{S}{D}\right) + (\text{dPos} - \text{SpeedThreshold}) \cdot \left(S \cdot \frac{A}{D}\right)$$

    When the input displacement is at or below the speed threshold (slow movement), only the base speed scaling applies:

    $$\text{dPosFiltered} = \text{dPos} \cdot \left(\frac{S}{D}\right)$$

    where,
    * $\text{dPos}$ is the raw position displacement on a given axis
    * $\text{dPosFiltered}$ is the output displacement after scaling
    * $S$ is the Speed coefficient
    * $A$ is the Acceleration coefficient
    * $D$ is the Divisor value
    * $\text{SpeedThreshold}$ is the per-axis speed threshold.

    <img src="assets/images/ballistic_config.png" alt="Ballistic multiplier configuration" style="width:900px; height:auto; display:block; margin:0 auto;" />

6. Click **Save** in the **CAPSENSE&trade; Configurator** to generate the configurations



## Lab 2: CSX touchpad tuning

### Objective

In this lab, you will create and tune the MSCLP Low Power CSX (mutual-capacitance) Touchpad example. You will follow the full tuning procedure using the CSX-RM sensing technique, which supports multi-touch and gesture detection. The project used has already been tuned, so you may find that ultimately the settings chosen will be the same or very similar to what was in the project to start with. 

### Project creation

1. If you do not already have a ModusToolbox&trade; workspace open, follow steps 1 and 2 from [Lab 1: Project creation](#project-creation)

2. The **Project Creator** tool will first prompt you to choose a **BSP** (Board Support Package). Select the **CY8CPROTO-041TP** BSP under the **PSOC&trade; 4 BSPs** category, and then click **Next**

3. On the **Select Application** page, search for and select **MSCLP low-power multitouch mutual-capacitance touchpad** under the **Sensing** section, and then click **Create**


<img src="assets/images/project_creator_csx_touchpad_selection.png" alt="Project Creator CSX touchpad application" style="width:800px; height:auto; display:block; margin:0 auto;" />

4. When you click **Create**, a new project is created. The project location is under the **Application root path**, in a folder with the given project name. Navigate to the project directory, and find the **.code-workspace** file and open it with Microsoft Visual Studio Code. 


<img src="assets/images/vscode_workspace_file.png" alt="VSCODE workspace file after project creation" style="width:400px; height:auto; display:block; margin:0 auto;" />

5. Once opened in Microsoft Visual Studio Code, make sure you have the **ModusToolbox&trade; for VS Code** extension installed. Once the extension is running, you will see the extension in the main panel. 

<img src="assets/images/csx_touchpad_vsocde_modustoolbox_extension.png" alt="VSCODE workspace file after project creation" style="width:1200px; height:auto; display:block; margin:0 auto;" />

<br>

> **Note:** VS Code may launch the workspace in **Restricted Mode**. If this happens, locate the blue ribbon under the taskbar indicating **Restricted Mode** and select **Manage**. A **Workspace Trust** window will pop up. Select **Trust** and close the window. The workspace will refresh and the ModusToolbox&trade; for VS Code extension will display after a brief delay.

<img src="assets/images/restricted_mode.png" alt="VS Code extension prompting to fix tasks and settings" style="width:1000px; height:auto; display:block; margin:0 auto;" />

<br>

> **Note:** The ModusToolbox&trade; for VS Code extension may display buttons indicating that the VS Code tasks and settings need to be updated. Simply click the buttons to correct the issues. This is a minor version mismatch between the ModusToolbox&trade; tools and the VS Code extension and does not affect functionality.

<img src="assets/images/vscode_fix_tasks_settings_prompt.png" alt="VS Code extension prompting to fix tasks and settings" style="width:800px; height:auto; display:block; margin:0 auto;" />

### Stage 1: Set the initial hardware parameters

1. In the ModusToolbox&trade; for VS Code extension, scroll down to **Tools**, and then open **CAPSENSE&trade; Configurator**

2. In the **Basic** tab, confirm that the **Touchpad** widget is configured with **CSX RM (Mutual-cap)** as the **Sensing Mode**


    <img src="assets/images/capsense_basictab_csx.png" alt="CAPSENSE Basic tab for the CSX touchpad" style="width:1017px; height:auto; display:block; margin:0 auto;" />

3. In the **Advanced** > **General** tab, set the following parameters:

    | Parameter | Setting | Comment |
    | --------- | ------- | ------- |
    | CAPSENSE&trade; IMO Clock frequency (MHz) | 46 | Clock source for the CAPSENSE&trade; peripheral |
    | Modulator clock divider | 1 | Achieves the optimum modulator clock frequency |
    | Number of init sub-conversions | 3 | Ensures proper initialization of CAPSENSE&trade; |

    > **Note:** Retain the default settings for all widget filters. Filters can be enabled later if needed to meet SNR requirements.


    <img src="assets/images/adv_general_csx.png" alt="CSX general settings" style="width:1019px; height:auto; display:block; margin:0 auto;" />

4. In the **Advanced** > **CSX Settings** tab, make the following changes:

    | Parameter | Setting | Comment |
    | --------- | ------- | ------- |
    | Inactive sensor connection | Ground | Connects inactive sensors to ground |
    | Number of reported fingers | 2 | Enables two-finger detection |
    | Raw count calibration level (%) | 40 | Target raw count level; reduce if saturation occurs on touch |


    <img src="assets/images/adv_csx.png" alt="CSX advanced settings" style="width:477px; height:auto; display:block; margin:0 auto;" />

5. In the **Advanced** > **Widget Details** tab, select **Touchpad** and set the following initial widget parameters:

    | Parameter | Setting | Comment |
    | --------- | ------- | ------- |
    | Maximum X-Axis position | 255 | Position range for the X axis |
    | Maximum Y-Axis position | 255 | Position range for the Y axis |
    | Tx clock divider | Default | Set in [Stage 2](#stage-2-set-the-sense-clock-frequency) |
    | Clock source | Direct | Constant frequency sense clock |
    | Number of sub-conversions | 25 | Starting point; adjust in [Stage 4](#stage-4-fine-tune-sensitivity-to-improve-snr) |
    | Finger threshold | 20 | Low initial value to allow Touchpad View tracking during tuning |
    | Noise threshold | 10 | Baseline is not updated when raw count exceeds baseline + noise threshold |
    | Negative noise threshold | 10 | Baseline is not updated when raw count drops below baseline − negative noise threshold |
    | Hysteresis | 5 | Prevents status toggling due to noise |
    | ON debounce | 10 | Consecutive scans a sensor must be active before a touch is reported |


    <img src="assets/images/adv_widget_detail_csx.png" alt="CSX widget detail settings" style="width:1001px; height:auto; display:block; margin:0 auto;" />

6. In the **Scan Configuration** tab, configure the electrode pins using the dropdown menus and assign scan slots using the **Auto-Assign Slots** option. Check the **Notice List** for any warnings or errors


    <img src="assets/images/scan-config.png" alt="CSX scan configuration" style="width:1016px; height:auto; display:block; margin:0 auto;" />

7. Click **Save** to apply the settings

### Stage 2: Set the sense clock frequency

The sense clock divider must allow the sensor capacitance to fully charge and discharge during each scan phase. Verify settling by observing the waveform with an oscilloscope and an active probe placed close to the electrode.

> **Note:** For CSX-RM, the sense clock divider must be **divisible by 2**. This ensures both scan phases have equal durations.

1. Connect the board to the PC using the USB cable through the KitProg3 USB connector

2. Program the board. Open the **CAPSENSE&trade; Tuner** from the ModusToolbox&trade; for VS Code extension

3. Observe the charging waveform of the sensor

<img src="assets/images/improper_charge_cycle_csx.png" alt="Improper CSX charge cycle waveform" style="width:635px; height:auto; display:block; margin:0 auto;" />

<img src="assets/images/proper_charge_cycle_csx.png" alt="Proper CSX charge cycle waveform" style="width:635px; height:auto; display:block; margin:0 auto;" />

> **Note:** The sense clock divider for this project has already been set using the method in this stage. These steps are here to demonstrate how to find the proper sense clock frequency. 

4. If charging is incomplete, increase the **Sense Clock Divider** in the **CAPSENSE&trade; Tuner** **Widget/Sensor Parameters** panel. Click **Apply to Device** and observe again. Repeat until complete settling is observed

5. Click **Apply to Project** to save the setting


    <img src="assets/images/sense_clock_divider_setting-csx.png" alt="CSX sense clock divider setting" style="width:386px; height:auto; display:block; margin:0 auto;" />

6. Repeat for all sensors. Apply the largest sense clock divider value to all sensors sharing the same scan slot

    | Parameter | CY8CPROTO-041TP |
    | --------- | --------------- |
    | Sense clock divider | 16 |

### Stage 3: Obtain crossover point and noise

1. Program the board. Open the **CAPSENSE&trade; Tuner** from the ModusToolbox&trade; for VS Code extension

2. In the **Touchpad View** tab, verify that the raw counts of each sensor element are approximately 40% (± 5%) of MaxCount

    Change the **Display settings** as follows:

    | Parameter | Setting |
    | --------- | ------- |
    | Display mode | Touch reporting |
    | Data type | RawCount |
    | Value type | Current |
    | Number of samples | 1000 |


    <img src="assets/images/touchpad-view-rc-csx.png" alt="CSX touchpad raw count view" style="width:1200px; height:auto; display:block; margin:0 auto;" />

3. Measure the peak-to-peak noise without placing a finger on the touchpad

    In the **Widget Explorer**, select the **Touchpad** widget, and then in the **Touchpad View** tab, change the **Display settings** as follows:

    | Parameter | Setting |
    | --------- | ------- |
    | Display mode | Touch reporting |
    | Data type | RawCount |
    | Value type | Max-Min |
    | Number of samples | 1000 |

    Note the highest noise value observed across all sensor nodes.


    <img src="assets/images/touchpad-view-noise.png" alt="CSX touchpad noise view" style="width:1200px; height:auto; display:block; margin:0 auto;" />


    | Kit | Max peak-to-peak noise |
    | --- | ---------------------- |
    | CY8CPROTO-041TP | 130 |

4. Measure the LTI (least touch intensity) signal. Hold a 6 mm finger at the LTI position — the intersection of four nodes, farthest from the sensor pin connection

    In the **Touchpad View** tab:

    * Set **Data type** to **DiffCount**
    * Set **Value type** to **Current**

    Position the finger so that approximately equal signal appears in all four intersecting nodes.


    <img src="assets/images/touchpad-view-lti.png" alt="CSX touchpad LTI measurement view" style="width:1200px; height:auto; display:block; margin:0 auto;" />

    LTI signal = (1300 + 798 + 828 + 291)/4 = 804

    The following value is a representative LTI measurement collected across multiple boards. The worked LTI and SNR examples use measurements from one development board, so their values can differ from this table.

    | Kit | LTI signal |
    | --- | ---------- |
    | CY8CPROTO-041TP | 850 |

### Stage 4: Fine-tune sensitivity to improve SNR

The touchpad must achieve SNR > 5:1. For gesture detection, target SNR ≥ 10:1.

1. Calculate the SNR using Equation 2

    $$\text{SNR} = \frac{\text{LTI signal}}{\text{Peak-to-peak noise}}$$

    Using the single-board tuning value from [Stage 3](#stage-3-obtain-crossover-point-and-noise):

    SNR = 850 / 130 = 6.5

    The value 850 is the single-board LTI value selected for this tuning example. The preceding 804 value is the average of the four displayed node measurements and illustrates how LTI is measured; it is not an SNR value. The table value is a representative across-board measurement.

2. If SNR < 5:1 or the LTI signal is below 50, increase the **Number of sub-conversions** in the **CAPSENSE&trade; Tuner** **Widget/Sensor Parameters** panel in increments of 10. Click **Apply to Device** after each change

    > **Note:** The number of sub-conversions must be ≥ 8. The number of sub-conversions should not be increased to a point where the raw count exceeds 2¹⁶.

3. Enable filters in the **CAPSENSE&trade; Configurator** **Advanced** > **General** tab if the SNR requirement cannot be met with sub-conversions alone

4. Click **Apply to Project** once the SNR requirement is met

### Stage 5: Tune threshold parameters

After confirming SNR > 5:1, set the threshold parameters. Thresholds are based on the LTI signal.

To measure hysteresis:

1. Place the finger at the LTI position
2. In the **Touchpad View** tab, set **Data type** to **DiffCount** and **Value type** to **Max-Min**. Click **Clear**
3. Record the maximum of all four Max-Min count values (Max_Min_count) for the selected 2×2 sensor nodes
4. Hysteresis = Max_Min_count / 2


<img src="assets/images/touchpad-view-hys.png" alt="CSX touchpad hysteresis view" style="width:1200px; height:auto; display:block; margin:0 auto;" />

Set the following threshold values for the **Touchpad** widget:

| Parameter | Value | Guidance |
| --------- | ----- | -------- |
| Number of sub-conversions | 100 | – |
| Finger threshold | 680 | 80% of the LTI signal |
| Noise threshold | 340 | Greater of: twice the highest noise, or 40% of the LTI signal |
| Negative noise threshold | 340 | Same rule as Noise threshold |
| Hysteresis | 50 | 10% of the LTI signal |
| Low baseline reset | 30 | Default |
| ON debounce | 3 | Default |
| Velocity | 2500 | Default; lower values distinguish two separate finger touches from one moving finger |

Click **Apply to Device** and then **Apply to Project** in the **CAPSENSE&trade; Tuner** to save all settings.


<img src="assets/images/apply-to-project-csx.png" alt="Apply to Project for the CSX touchpad" style="width:391px; height:auto; display:block; margin:0 auto;" />

### Optional further configuration of velocity parameters

Similar to Lab 1, further optimization can be performed for the touchpad's **Velocity** threshold setting, which is located under the widget details threshold parameters in the **CAPSENSE&trade; Configurator**.

1. Select the **Advanced** > **Widget Details** tab

2. In the left pane widget list, select the CSX touchpad widget (**Touchpad**)

3. Expand the **Widget threshold parameters** section in the right pane

4. Adjust the **Velocity** parameter

    * **Velocity**: This parameter defines the maximum displacement speed of an active finger touch across successive scans. The value is configured as a squared distance in terms of the touchpad resolution. If a finger movement reports a displacement greater than this velocity value between two successive scans, the middleware decides that the displacement is too large to belong to the same finger tracked previously. It will therefore terminate the previous touch ID and assign a brand new touch ID to this coordinate.
    * **Tuning guidance**: The default setting (e.g., **2500**) is optimal for most standard finger speeds. If the touchpad experiences rapid coordinate jumps (e.g., from environmental noise or fast swipes) that falsely get linked to the same touch ID to produce erratic gesture outputs, you can reduce this value. If the velocity is set too low, however, a single fast-moving finger may continuously get split and reported as brand new separate touches (generating successive touchdown and liftoff events).


    <img src="assets/images/velocity_config.png" alt="Velocity filter configuration" style="width:900px; height:auto; display:block; margin:0 auto;" />

5. Click **Save** in the **CAPSENSE&trade; Configurator** to generate the configurations

### Expected result

After programming the board with the tuned project, test the touchpad as follows:

* Slide a finger over the touchpad. **LED3** brightness increases as the finger moves from left to right. **LED2** brightness increases as the finger moves from bottom to top.
* Perform gestures (single click, double click, flick, two-finger click) and verify the corresponding LED responses.
* Open the **CAPSENSE&trade; Tuner** from the ModusToolbox&trade; for VS Code extension and use **Touchpad View** to confirm accurate position tracking. Use the **Gesture View** tab to verify gesture detection.

### Re-tuning and filtering

If you observe performance issues or coordinate jitter in the reported touchpad position:

* Refer to the detailed touchpad filter options and configuration steps in the appendixes:

  * [Appendix A: Touchpad raw count filters](#appendix-a-touchpad-raw-count-filters) (for reducing raw sensor noise)
  * [Appendix B: Touchpad position filters](#appendix-b-touchpad-position-filters) (for coordinate smoothing and stabilization)
  * [Appendix C: Touchpad adaptive IIR filter](#appendix-c-touchpad-adaptive-iir-filter) (for advanced speed-adaptive coordinate filtering)

## Appendix A: Touchpad raw count filters

The raw count filter processes the digitized raw capacitance counts before they are processed for touch detection or coordinate calculation. In the CAPSENSE&trade; Configurator, an additional raw count filter available for multi-sensor widgets like touchpads is the **Common mode filter**.

#### Common mode filter overview

Common mode noise (e.g., from power supplies, AC mains ripple, or display coupling) typically affects multiple touchpad sensors simultaneously and in the same direction. The common mode filter minimizes this noise by up to 75% of the touch signal. It dynamically calculates the common mode noise and corrects the raw count of all sensors in the widget.

#### When and what to configure

* **When to enable**: Enable the common mode filter if the peak-to-peak noise on multiple touchpad sensors is high and well-correlated (common mode noise), which often happens when the platform is powered by noisy external power supplies or USB chargers.
* **Common mode filter threshold**: Set this value to approximately **75% of the expected target finger touch signal** (the LTI signal difference count obtained during tuning). If the threshold is too high, sensors touched by a finger will be misclassified as empty and corrupt the noise estimation. If the threshold is too low, the noise calculation will ignore sensors with minor noise, making the filter less effective.

> **Note:** The common mode filter is not supported if **Enable multi-frequency scan**, **Multi-phase Tx order**, or **SMARTSENSE** are enabled.

#### Configuration steps

1. In the ModusToolbox&trade; for VS Code extension, scroll down to **Tools**, and then open **CAPSENSE&trade; Configurator**

2. Select the **Advanced** > **Widget Details** tab

3. Under the widget list in the left pane, select the touchpad widget (**TOUCHPAD_SELF_CAP** for CSD, or **Touchpad** for CSX)

4. Expand the **Raw count filter parameters** section in the right pane

5. Select **Common mode filter** and set it to **Enabled**

6. Set the **Common mode filter threshold** to $75\%$ of the target finger touch signal (e.g., 673 for a 900-count touch signal)


    <img src="assets/images/common_mode_filter_config.png" alt="Common-mode filter configuration" style="width:900px; height:auto; display:block; margin:0 auto;" />

    | Touchpad type / Sensing mode | Measured LTI signal (DiffCount) | Recommended threshold starting point (75%) |
    | ---------------------------- | ------------------------------- | ------------------------------------------ |
    | CSD Touchpad Self-Cap (TOUCHPAD_SELF_CAP) |  898 | 673 |
    | CSX Touchpad Mutual-Cap (Touchpad) | 850 | 638 |

7. Click **Save** to save the configuration

8. Program the device, open the **CAPSENSE&trade; Tuner** from the ModusToolbox&trade; for VS Code extension, re-connect to the device, and observe the position in the **Widget view** or **Touchpad View** tabs. Observe the raw counts in the **Graph View** tab

---

**Return to:** [Lab 1 (CSD) – Re-tuning](#re-tuning) | [Lab 2 (CSX) – Re-tuning and filtering](#re-tuning-and-filtering)

## Appendix B: Touchpad position filters

Position/Level filters are firmware-based filters applied to the calculated centroid (X/Y coordinates) of the touchpad to reduce coordinate jitter, stabilize the reported touch position, and smooth movement tracking.

#### Supported position filters

The following filters can be enabled in any combination. When multiple filters are enabled, they execute in the sequence listed below, and the total RAM consumption increases by the sum of each filter's history:

1. **IIR filter (First-order Infinite Impulse Response)**:

   * **Description**: Smooths high-frequency coordinate noise using a step-response-like equation:

     $$\text{Output} = \frac{N}{256} \times \text{Input} + \frac{256 - N}{256} \times \text{Previous Output}$$

     where $N$ is the filter coefficient (1–255).
   * **When to use**: To eliminate continuous high-frequency coordinate jitter.
   * **What to set**: Set **IIR filter coefficient** ($N$) between 1 and 255. A lower value of $N$ (e.g., < 128) results in maximum noise reduction but introduces coordinate lag/delay. A higher value (e.g., 192–240) preserves responsiveness but provides less smoothing.
   * **RAM usage**: Consumes 2 bytes of RAM per position.

2. **Median filter**:

   * **Description**: A non-linear filter that takes the three most recent coordinate samples and outputs the median.
   * **When to use**: Highly effective at eliminating sharp, single-sample position spikes caused by sudden high-energy electrical noise (e.g., switching power supplies or motors).
   * **RAM usage**: Consumes 4 bytes of RAM per position.

3. **Average filter**:

   * **Description**: A finite impulse response (FIR) filter that takes the average of the two most recent coordinate samples.
   * **When to use**: Helps eliminate high-frequency periodic noise, such as AC mains coupling (50 Hz / 60 Hz).
   * **RAM usage**: Consumes 2 bytes of RAM per position.

4. **Jitter filter**:

   * **Description**: Eliminates stationary coordinate flickering that occurs when a finger sits still and the calculated position toggles between two adjacent values.
   * **When to use**: Best used under low-noise conditions to stop tiny stationary coordinate fluctuations.
   * **RAM usage**: Consumes 2 bytes of RAM per position.

#### Configuration steps

1. In the ModusToolbox&trade; for VS Code extension, scroll down to **Tools**, and then open **CAPSENSE&trade; Configurator**

2. Navigate to the **Advanced** > **Widget Details** tab

3. Select your touchpad widget (**TOUCHPAD_SELF_CAP** for CSD, or **Touchpad** for CSX) in the left list

4. Expand the **Position / Level filter parameters** (or **Position filter parameters**) section in the right pane

5. Enable any desired filters by checking their corresponding boxes (e.g., **IIR filter**, **Median filter**, **Average filter**, **Jitter filter**)

6. For the **IIR filter**, configure the **IIR filter coefficient** value (typically 128 for a balanced response)


    <img src="assets/images/position_filter_config.png" alt="Position filter configuration" style="width:900px; height:auto; display:block; margin:0 auto;" />

7. Click **Save** to save the configuration

8. Program the device, open the **CAPSENSE&trade; Tuner** from the ModusToolbox&trade; for VS Code extension, re-connect to the device, and observe the position in the **Widget view** or **Touchpad View** tabs

---

**Return to:** [Lab 1 (CSD) – Re-tuning](#re-tuning) | [Lab 2 (CSX) – Re-tuning and filtering](#re-tuning-and-filtering)

## Appendix C: Touchpad adaptive IIR filter

The **Adaptive IIR filter** dynamically adjusts its filtering intensity based on the speed of the finger's movement. It provides heavy filtering (smooth coordinates, no jitter) when the finger is stationary or moving slowly, and light filtering (minimal lag, high responsiveness) when the finger is moving quickly.

#### Filter parameters

* **Adaptive IIR filter**: Enables the dynamic coefficient-adjusting firmware filter. Consumes 3 bytes of RAM per position.
* **Position movement threshold**: Position displacement below this threshold is ignored (considered no movement). It prevents slow drift or coordinate jitter from registering as false motion.
* **Position slow movement threshold**: Displacement between the movement threshold and this threshold is treated as slow movement. Under slow movement, the IIR coefficient decreases, making the filter more intensive to keep the coordinate smooth.
* **Position fast movement threshold**: Displacement above this threshold is treated as fast movement. The coefficient is automatically scaled up towards the maximum limit to minimize tracking delay.
* **IIR coefficient maximum limit**: The upper bound of the coefficient when the finger is fast-moving.
* **IIR coefficient minimum limit**: The lower bound of the coefficient when the finger is slow-moving.
* **IIR coefficient divisor**: Acts as a scale factor for the coefficient:

  $$\text{Output} = \frac{\text{Coeff}}{\text{Divisor}} \times \text{Input} + \frac{\text{Divisor} - \text{Coeff}}{\text{Divisor}} \times \text{Previous Output}$$

#### When to use

Use the adaptive IIR filter when a standard IIR filter is insufficient. For instance, if you require a very smooth hover with a stationary finger (suggesting a low IIR coefficient), but that same coefficient causes noticeable tracking lag during rapid finger swipes or gestures.

#### Configuration steps

1. In the ModusToolbox&trade; for VS Code extension, scroll down to **Tools**, and then open **CAPSENSE&trade; Configurator**

2. Navigate to the **Advanced** > **Widget Details** tab

3. Select your touchpad widget (**TOUCHPAD_SELF_CAP** for CSD, or **Touchpad** for CSX) in the left list

4. Expand the **Adaptive IIR filter parameters** section in the right pane

5. Check the **Adaptive IIR filter** box to enable it

6. Configure the thresholds, limits, and divisor


    <img src="assets/images/adaptive_iir_filter_config.png" alt="Adaptive IIR filter configuration" style="width:900px; height:auto; display:block; margin:0 auto;" />

    | Parameter | Starting point value | Guidance for further tuning |
    | --------- | -------------------- | --------------------------- |
    | Position movement threshold | 3 | Increase if very slow finger drift registration causes false coordinate drift |
    | Position slow movement threshold | 12 | Defines slow movement threshold; lower value decreases the coefficient more aggressively |
    | Position fast movement threshold | 24 | Defines fast movement threshold; higher value decreases filtering lag on rapids |
    | IIR coefficient maximum limit | 128 | Dictates the highest coefficient (high responsiveness, low lag) under fast fingers |
    | IIR coefficient minimum limit | 4 | Dictates the lowest coefficient (heavy coordinate filtering) under slow fingers |
    | IIR coefficient divisor | 20 | Scales the coefficient calculation; fixed coefficient scaling divisor |

7. Click **Save** to save the configuration

8. Program the device, open the **CAPSENSE&trade; Tuner** from the ModusToolbox&trade; for VS Code extension, re-connect to the device, and observe the position in the **Widget view** or **Touchpad View** tabs

---

**Return to:** [Lab 1 (CSD) – Re-tuning](#re-tuning) | [Lab 2 (CSX) – Re-tuning and filtering](#re-tuning-and-filtering)


## Disclaimer
All referenced product or service names and trademarks are the property of their respective owners.

The Bluetooth&reg; word mark and logos are registered trademarks owned by Bluetooth SIG, Inc., and any use of such marks by Infineon is under license.

PSOC&trade;, formerly known as PSoC&trade;, is a trademark of Infineon Technologies. Any references to PSoC&trade; in this document or others shall be deemed to refer to PSOC&trade;.

---------------------------------------------------------

© Cypress Semiconductor Corporation, 2023-2025. This document is the property of Cypress Semiconductor Corporation, an Infineon Technologies company, and its affiliates ("Cypress").  This document, including any software or firmware included or referenced in this document ("Software"), is owned by Cypress under the intellectual property laws and treaties of the United States and other countries worldwide.  Cypress reserves all rights under such laws and treaties and does not, except as specifically stated in this paragraph, grant any license under its patents, copyrights, trademarks, or other intellectual property rights.  If the Software is not accompanied by a license agreement and you do not otherwise have a written agreement with Cypress governing the use of the Software, then Cypress hereby grants you a personal, non-exclusive, nontransferable license (without the right to sublicense) (1) under its copyright rights in the Software (a) for Software provided in source code form, to modify and reproduce the Software solely for use with Cypress hardware products, only internally within your organization, and (b) to distribute the Software in binary code form externally to end users (either directly or indirectly through resellers and distributors), solely for use on Cypress hardware product units, and (2) under those claims of Cypress's patents that are infringed by the Software (as provided by Cypress, unmodified) to make, use, distribute, and import the Software solely for use with Cypress hardware products.  Any other use, reproduction, modification, translation, or compilation of the Software is prohibited.
<br>
TO THE EXTENT PERMITTED BY APPLICABLE LAW, CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH REGARD TO THIS DOCUMENT OR ANY SOFTWARE OR ACCOMPANYING HARDWARE, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  No computing device can be absolutely secure.  Therefore, despite security measures implemented in Cypress hardware or software products, Cypress shall have no liability arising out of any security breach, such as unauthorized access to or use of a Cypress product. CYPRESS DOES NOT REPRESENT, WARRANT, OR GUARANTEE THAT CYPRESS PRODUCTS, OR SYSTEMS CREATED USING CYPRESS PRODUCTS, WILL BE FREE FROM CORRUPTION, ATTACK, VIRUSES, INTERFERENCE, HACKING, DATA LOSS OR THEFT, OR OTHER SECURITY INTRUSION (collectively, "Security Breach").  Cypress disclaims any liability relating to any Security Breach, and you shall and hereby do release Cypress from any claim, damage, or other liability arising from any Security Breach.  In addition, the products described in these materials may contain design defects or errors known as errata which may cause the product to deviate from published specifications. To the extent permitted by applicable law, Cypress reserves the right to make changes to this document without further notice. Cypress does not assume any liability arising out of the application or use of any product or circuit described in this document. Any information provided in this document, including any sample design information or programming code, is provided only for reference purposes.  It is the responsibility of the user of this document to properly design, program, and test the functionality and safety of any application made of this information and any resulting product.  "High-Risk Device" means any device or system whose failure could cause personal injury, death, or property damage.  Examples of High-Risk Devices are weapons, nuclear installations, surgical implants, and other medical devices.  "Critical Component" means any component of a High-Risk Device whose failure to perform can be reasonably expected to cause, directly or indirectly, the failure of the High-Risk Device, or to affect its safety or effectiveness.  Cypress is not liable, in whole or in part, and you shall and hereby do release Cypress from any claim, damage, or other liability arising from any use of a Cypress product as a Critical Component in a High-Risk Device. You shall indemnify and hold Cypress, including its affiliates, and its directors, officers, employees, agents, distributors, and assigns harmless from and against all claims, costs, damages, and expenses, arising out of any claim, including claims for product liability, personal injury or death, or property damage arising from any use of a Cypress product as a Critical Component in a High-Risk Device. Cypress products are not intended or authorized for use as a Critical Component in any High-Risk Device except to the limited extent that (i) Cypress's published data sheet for the product explicitly states Cypress has qualified the product for use in a specific High-Risk Device, or (ii) Cypress has given you advance written authorization to use the product as a Critical Component in the specific High-Risk Device and you have signed a separate indemnification agreement.
<br>
Cypress, the Cypress logo, and combinations thereof, ModusToolbox, PSOC, CAPSENSE, EZ-USB, F-RAM, and TRAVEO are trademarks or registered trademarks of Cypress or a subsidiary of Cypress in the United States or in other countries. For a more complete list of Cypress trademarks, visit www.infineon.com. Other names and brands may be claimed as property of their respective owners.
