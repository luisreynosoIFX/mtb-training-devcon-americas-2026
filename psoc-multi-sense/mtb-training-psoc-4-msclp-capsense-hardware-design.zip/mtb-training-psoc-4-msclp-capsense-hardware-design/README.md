# PSOC™ 4 E3 training - CAPSENSE™ hardware design

This training provides a comprehensive look at how to design CAPSENSE™ hardware. It will start by covering the fundamentals of capacitors then applying those fundamentals to PCB design. PCB design, including schematic and layout capture best practices will be covered as well as common design pitfalls. 

## Device family
- [PSOC™ 4](https://www.infineon.com/products/microcontroller/32-bit-psoc-arm-cortex/psoc-4-mcu)

## How to use this training?
1. Download the training [content](#content).
2. Review the presentation at your own pace.

## Training level
- E3: Advanced

## Pre-requisites 

### Training
- [PSOC™ 4 CAPSENSE™ using PSOC™ 4000T and PSOC™ 4100T Plus training](https://github.com/Infineon/mtb-training-psoc-4-msclp-capsense)

See [training content](#content) for versions and instructions.

## Duration
- 60 min 

## Agenda


## Expected outcome
- Get hands-on experience with the gestures on CAPSENSE™ sliders and touchpads
- Understand complexities of wear detection
- Dive deeper with challenges included for all labs

## Content
- [Presentation](./Presentation/PSOC(TM)%204%20CAPSENSE(TM)%20hardware%20design%20training.pdf)

## References and resources
- [ModusToolbox™](https://www.cypress.com/products/modustoolbox)
- [PSOC™ 4 MCUs](https://www.infineon.com/products/microcontroller/32-bit-psoc-arm-cortex/psoc-4-mcu)
- [Introduction to PSOC™ MCUs and ModusToolbox™](https://www.infineon.com/product-information/psocdeveloper)
- [PSOC™ 4 and PSOC™ 6 MCU CAPSENSE™ design guide](https://www.infineon.com/assets/row/public/documents/30/42/infineon-an85951-psoc-4-psoc-6-capsense-design-guide-applicationnotes-en.pdf?fileId=8ac78c8c7cdc391c017d0723535d4661)
