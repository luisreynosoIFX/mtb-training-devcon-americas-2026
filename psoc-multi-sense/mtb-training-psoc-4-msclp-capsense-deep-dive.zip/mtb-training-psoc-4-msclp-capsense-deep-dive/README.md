# PSOC&trade; 4 E3 Training - CAPSENSE&trade; deep dive into the MSCLP ratio-metric converter

This training provides a deep dive into the 5th generation MSCLP ratio-metric converter.
The training includes hands-on labs, providing an in depth understanding of the CAPDAC controls
and filtering available on PSOC&trade; 4 devices with 5th generation capacitive sensing.

## Device family

* [PSOC&trade; 4](https://www.infineon.com/products/microcontroller/32-bit-psoc-arm-cortex/psoc-4-mcu)

## How to use this training?

1. Download the training [content](#content)
2. Watch the video or review the presentation at your own pace
3. Follow the step-by-step instructions in the training manual during the hands-on sections
4. Use the provided source files if needed to verify the solution

## Training level

* E3: Advanced

## Pre-requisites 

### Training

* [PSOC&trade; 4 CAPSENSE&trade; using PSOC&trade; 4000T and PSOC&trade; 4100T Plus training](https://github.com/Infineon/mtb-training-psoc-4-msclp-capsense)

### Tools (see [training manual](#content) for versions and installation instructions)

* [ModusToolbox&trade; with Eclipse IDE](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup)
* [ModusToolbox&trade; Programming tools](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup)
* [ModusToolbox&trade; CAPSENSE&trade; and Multi-Sense Pack](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup)

See [training content](#content) for versions and instructions.

## Hardware

* [CY8CPROTO-040T](https://www.infineon.com/evaluation-board/cy8cproto-040t)
* [CY8CPROTO-041TP](https://www.infineon.com/evaluation-board/CY8CPROTO-041TP)

## Duration

* ~90 min video with hands-on labs

## Agenda

1. Review of 5th Generation CAPSENSE&trade;
2. CAPSENSE&trade; conversion controls
3. Shielding
4. Best practices for sensor tuning to compensate for production variation
5. Lab 1: CSD sensor tuning for production
6. Lab 2: CSX sensor tuning for production

## Expected outcome

* Get hands-on experience with the CAPDAC controls on MSCLP PSOC&trade; 4 devices. 
* Get familiar with PSOC&trade; 4 hardware and software ecosystem
* Dive deeper with challenges included for all labs

## Content

* [Presentation](./Presentation/PSOC%28TM%29%204%20CAPSENSE%28TM%29%20deep%20dive.pdf)
* [Training manual](./Manual/capsense-deep-dive-lab-manual.md)
* [Solution to labs](./Lab%20Solutions/)

## References and resources

* [ModusToolbox&trade;](https://www.cypress.com/products/modustoolbox)
* [PSOC&trade; 4 MCUs](https://www.infineon.com/products/microcontroller/32-bit-psoc-arm-cortex/psoc-4-mcu)
* [Introduction to PSOC&trade; MCUs and ModusToolbox&trade;](https://www.infineon.com/product-information/psocdeveloper)
* [PSOC&trade; 4 and PSOC&trade; 6 MCU CAPSENSE&trade; design guide](https://www.infineon.com/assets/row/public/documents/30/42/infineon-an85951-psoc-4-psoc-6-capsense-design-guide-applicationnotes-en.pdf?fileId=8ac78c8c7cdc391c017d0723535d4661)


All referenced product or service names and trademarks are the property of their respective owners.

The Bluetooth&reg; word mark and logos are registered trademarks owned by Bluetooth SIG, Inc., and any use of such marks by Infineon is under license.

PSOC&trade;, formerly known as PSoC&trade;, is a trademark of Infineon Technologies. Any references to PSoC&trade; in this document or others shall be deemed to refer to PSOC&trade;.

---------------------------------------------------------

© Cypress Semiconductor Corporation, 2023-2025. This document is the property of Cypress Semiconductor Corporation, an Infineon Technologies company, and its affiliates ("Cypress").  This document, including any software or firmware included or referenced in this document ("Software"), is owned by Cypress under the intellectual property laws and treaties of the United States and other countries worldwide.  Cypress reserves all rights under such laws and treaties and does not, except as specifically stated in this paragraph, grant any license under its patents, copyrights, trademarks, or other intellectual property rights.  If the Software is not accompanied by a license agreement and you do not otherwise have a written agreement with Cypress governing the use of the Software, then Cypress hereby grants you a personal, non-exclusive, nontransferable license (without the right to sublicense) (1) under its copyright rights in the Software (a) for Software provided in source code form, to modify and reproduce the Software solely for use with Cypress hardware products, only internally within your organization, and (b) to distribute the Software in binary code form externally to end users (either directly or indirectly through resellers and distributors), solely for use on Cypress hardware product units, and (2) under those claims of Cypress's patents that are infringed by the Software (as provided by Cypress, unmodified) to make, use, distribute, and import the Software solely for use with Cypress hardware products.  Any other use, reproduction, modification, translation, or compilation of the Software is prohibited.
<br>
TO THE EXTENT PERMITTED BY APPLICABLE LAW, CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH REGARD TO THIS DOCUMENT OR ANY SOFTWARE OR ACCOMPANYING HARDWARE, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  No computing device can be absolutely secure.  Therefore, despite security measures implemented in Cypress hardware or software products, Cypress shall have no liability arising out of any security breach, such as unauthorized access to or use of a Cypress product. CYPRESS DOES NOT REPRESENT, WARRANT, OR GUARANTEE THAT CYPRESS PRODUCTS, OR SYSTEMS CREATED USING CYPRESS PRODUCTS, WILL BE FREE FROM CORRUPTION, ATTACK, VIRUSES, INTERFERENCE, HACKING, DATA LOSS OR THEFT, OR OTHER SECURITY INTRUSION (collectively, "Security Breach").  Cypress disclaims any liability relating to any Security Breach, and you shall and hereby do release Cypress from any claim, damage, or other liability arising from any Security Breach.  In addition, the products described in these materials may contain design defects or errors known as errata which may cause the product to deviate from published specifications. To the extent permitted by applicable law, Cypress reserves the right to make changes to this document without further notice. Cypress does not assume any liability arising out of the application or use of any product or circuit described in this document. Any information provided in this document, including any sample design information or programming code, is provided only for reference purposes.  It is the responsibility of the user of this document to properly design, program, and test the functionality and safety of any application made of this information and any resulting product.  "High-Risk Device" means any device or system whose failure could cause personal injury, death, or property damage.  Examples of High-Risk Devices are weapons, nuclear installations, surgical implants, and other medical devices.  "Critical Component" means any component of a High-Risk Device whose failure to perform can be reasonably expected to cause, directly or indirectly, the failure of the High-Risk Device, or to affect its safety or effectiveness.  Cypress is not liable, in whole or in part, and you shall and hereby do release Cypress from any claim, damage, or other liability arising from any use of a Cypress product as a Critical Component in a High-Risk Device. You shall indemnify and hold Cypress, including its affiliates, and its directors, officers, employees, agents, distributors, and assigns harmless from and against all claims, costs, damages, and expenses, arising out of any claim, including claims for product liability, personal injury or death, or property damage arising from any use of a Cypress product as a Critical Component in a High-Risk Device. Cypress products are not intended or authorized for use as a Critical Component in any High-Risk Device except to the limited extent that (i) Cypress's published data sheet for the product explicitly states Cypress has qualified the product for use in a specific High-Risk Device, or (ii) Cypress has given you advance written authorization to use the product as a Critical Component in the specific High-Risk Device and you have signed a separate indemnification agreement.
<br>
Cypress, the Cypress logo, and combinations thereof, ModusToolbox, PSoC, CAPSENSE, EZ-USB, F-RAM, and TRAVEO are trademarks or registered trademarks of Cypress or a subsidiary of Cypress in the United States or in other countries. For a more complete list of Cypress trademarks, visit www.infineon.com. Other names and brands may be claimed as property of their respective owners.