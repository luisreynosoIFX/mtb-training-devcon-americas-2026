# PSOC&trade; 4 training manual: CAPSENSE&trade; deep dive

## About this document

### Scope and purpose

This document is a training manual for the hands-on exercise of the CAPSENSE&trade; built-in self-test and a deep dive into the MSCLP ratio-metric converter available on the latest PSOC&trade; 4 devices.

### Intended audience

This manual is intended for design engineers, technicians, and developers of electronic systems.

## Table of contents

* [About this document](#about-this-document)
* [Introduction](#introduction)
* [Required development tools and prerequisites](#required-development-tools-and-prerequisites)
* [CSD sensor tuning for production](#csd-sensor-tuning-for-production)
* [CSX sensor tuning for production](#csx-sensor-tuning-for-production)
* [References](#references)
* [Revision History](#revision-history)
* [Disclaimer](#disclaimer)

## Introduction

This manual provides specific instructions for creating, configuring, building, and running the code examples on the PSOC&trade; 4100T+. In this lab session, you will learn best practices for tuning CAPSENSE&trade; CSD and CSX sensors while considering the impact of production variation.

## Required development tools and prerequisites

### Tools

* **ModusToolbox&trade; software** v3.9 or later (Recommended installation via [ModusToolbox&trade; Setup tool](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup))
* [**Microsoft Visual Studio Code**](https://code.visualstudio.com/) with the [**ModusToolbox&trade; for VS Code**](https://marketplace.visualstudio.com/items?itemName=InfineonAG.modustoolbox-for-vscode) extension installed
* **ModusToolbox&trade; Programming Tools** v1.9.0 or later (Installed by [ModusToolbox&trade; Setup tool](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup) as a dependency to ModusToolbox&trade; v3.9)
* **ModusToolbox&trade; CAPSENSE&trade; and Multi-Sense Pack** v1.6.0 or later (Recommended installation via [ModusToolbox&trade; Setup tool](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup))
* **PSOC 4100T Plus Prototyping Kit** ([CY8CPROTO-041TP](https://www.infineon.com/evaluation-board/CY8CPROTO-041TP))

    <img src="assets/images/CY8CPROTO_041TP.png" alt="Figure" style="width:533px; height:auto; display:block; margin:0 auto;" />

### Prerequisites

Install the software and obtain the hardware listed in the [Required development tools and prerequisites](#required-development-tools-and-prerequisites) section.


This class does not cover the basic concepts of ModusToolbox&trade; and PSOC&trade; 4100T Plus.

* For an introduction to PSOC, including a getting started guide to ModusToolbox&trade;, visit: [PSOC Developer](https://www.infineon.com/product-information/psocdeveloper)
* For the PSOC 4 CAPSENSE&trade; using PSOC 4000T and PSOC 4100T Plus training, visit: [PSOC 4 CAPSENSE Training Manual](https://github.com/Infineon/mtb-training-psoc-4-msclp-capsense)


## CSD sensor tuning for production

### Objective

In this lab, you will use the MSCLP Low Power CSD Button example to observe the impact of the CAPDAC controls and learn how to manage them for the best performance across production variation.

### Description

You will adjust the number of sub-conversions and observe how the sense clock divider, decimation rate, and conversion gain affect CSD sensor performance. You will then enable the self-test library and compare sensor capacitance with and without shielding.

### Project creation

1. <span id="step1-workspace-creation"></span>Open **ModusToolbox&trade;** from the **Windows Start** menu

> **Note:** If you have not installed ModusToolbox&trade;, see the [Required development tools](#required-development-tools-and-prerequisites) section.


<img src="assets/images/opening_modustoolbox_from_windows_11_start.png" alt="Running ModusToolbox Dashboard" style="width:427px; height:auto; display:block; margin:0 auto;" />

2. <span id="step2-directory-selection"></span>Select your **Target IDE** (**Microsoft Visual Studio Code**), and then click **Launch Project Creator**

<img src="assets/images/launch_project_creator.png" alt="Launching Project Creator" style="width:1000px; height:auto; display:block; margin:0 auto;" />

3. When **Project Creator** prompts you, select a **BSP** (Board Support Package)

> **Note:** BSPs are aligned with the development/evaluation kits; they provide files for basic device functionality. A BSP typically has a `design.modus` file that configures clocks and other board-specific capabilities. That file is used by the ModusToolbox&trade; configurators. A BSP also includes the required device support code for the device on the board. You can modify the configuration to suit your application.

4. Once **Project Creator** launches, select the **CY8CPROTO-041TP** BSP under the PSOC 4 BSPs, and then click **Next**

<img src="assets/images/project_creator_cy8proto041tp_bsp_selection.png" alt="Project Creator BSP Selection" style="width:800px; height:auto; display:block; margin:0 auto;" />

5. Click **Next** to proceed to the application selection menu. Select the **MSCLP Low Power CSD Button** under the Sensing section by clicking the **checkbox** near the application, and then click **Create**

<img src="assets/images/project_creator_example_code_project_creation.png" alt="Project Creator example code creation" style="width:800px; height:auto; display:block; margin:0 auto;" />

6. When you click **Create**, a new project is created. The project location is under the **Application root path**, in a folder with the given project name. Navigate to the project directory, and find the **.code-workspace** file and open it with Microsoft Visual Studio Code. 


<img src="assets/images/vscode_workspace_file.png" alt="VSCODE workspace file after project creation" style="width:500px; height:auto; display:block; margin:0 auto;" />

7. Once opened in Microsoft Visual Studio Code, make sure you have the **ModusToolbox&trade; for VS Code** extension installed. Once the extension is running, you will see the extension in the main panel. 

<img src="assets/images/vsocde_modustoolbox_extension.png" alt="VSCODE workspace file after project creation" style="width:1200px; height:auto; display:block; margin:0 auto;" />

<br>

> **Note:** VS Code may launch the workspace in **Restricted Mode**. If this happens, locate the blue ribbon under the taskbar indicating **Restricted Mode** and select **Manage**. A **Workspace Trust** window will pop up. Select **Trust** and close the window. The workspace will refresh and the ModusToolbox&trade; for VS Code extension will display after a brief delay.

<img src="assets/images/restricted_mode.png" alt="VS Code extension prompting to fix tasks and settings" style="width:1000px; height:auto; display:block; margin:0 auto;" />

> **Note:** The ModusToolbox&trade; for VS Code extension may display buttons indicating that the VS Code tasks and settings need to be updated. Simply click the buttons to correct the issues. This is a minor version mismatch between the ModusToolbox&trade; tools and the VS Code extension and does not affect functionality.

<img src="assets/images/vscode_fix_tasks_settings_prompt.png" alt="VS Code extension prompting to fix tasks and settings" style="width:800px; height:auto; display:block; margin:0 auto;" />



### Adjusting the conversion parameters

By default, the CAPDAC setting for a widget is set to **auto**. This setting tells the CAPSENSE&trade; middleware to calibrate CAPDAC to achieve a raw count target of 85% of the maximum count for a given self-capacitive electrode. This is the most balanced setting for maximizing gain while minimizing the chance of saturation during a touch. Leave the CAPDAC setting at **auto**.

You can change other parameters manually. For example, the number of sub-conversions directly correlates with the SNR of the system. A higher number of sub-conversions yields a higher SNR. However, increasing the number of sub-conversions may reduce the maximum possible raw counts because of the CIC2 filter settings (decimation rate and CIC2 shift). Increase the raw counts until you reach the maximum possible decimation rate for the sense-clock divider.

1. Program the device from the ModusToolbox&trade; for VS Code extension. 

    <img src="assets/images/programming_device_from_modustoolbox_vscode_extension.png" alt="Figure" style="width:800px; height:auto; display:block; margin:0 auto;" />
  
2. Open the CAPSENSE&trade; tuner from the ModusToolbox&trade; for VS Code extension quick panel

    <img src="assets/images/launching_capsense_tuner_from_modustoolbox_vscode_extension.png" alt="Figure" style="width:800px; height:auto; display:block; margin:0 auto;" />

3. In the CAPSENSE&trade; tuner, enable all sensors by clicking the button in the top-left corner of the Widget Explorer. Connect to the device, and then begin streaming

    <img src="assets/images/enabling_sensors_and_connecting_to_device.png" alt="Figure" style="width:426px; height:auto; display:block; margin:0 auto;" />

    <img src="assets/images/begin_streaming.png" alt="Figure" style="width:417px; height:auto; display:block; margin:0 auto;" />

    <br><br>

    > **Note:** You may have to select the tuner communication settings when establishing the connection. By default, the project will use I2C, at address 0x8, with 2-byte sub-addressing.

    <img src="assets/images/tuner_communication_setup.png" alt="Figure" style="width:659px; height:auto; display:block; margin:0 auto;" />

    <br><br>

4. Once streaming begins, observe the raw counts in the sensor data graph

    <img src="assets/images/rawcount_from_startup.png" alt="Figure" style="width:1200px; height:auto; display:block; margin:0 auto;" />

5. In the Widget Explorer, select **Button0**. This enables you to adjust the Widget/Sensor Parameters in the section below. In the Widget/Sensor Parameters, observe the number of sub-conversions, max count, and decimation rate

    <img src="assets/images/widget_sensor_parameters.png" alt="Figure" style="width:423px; height:auto; display:block; margin:0 auto;" />

6. Adjust the number of sub-conversions to 10 and apply the settings to the device. 

    <img src="assets/images/adjust_nsubs_apply_to_device.png" alt="Figure" style="width:412px; height:auto; display:block; margin:0 auto;" />

7. Observe the new max count and updated decimation rate settings once the PSOC 4 runs the auto-calibration routine

    <img src="assets/images/updated_cdac_after_nsubs_change.png" alt="Figure" style="width:450px; height:auto; display:block; margin:0 auto;" />

    * The auto-calibration routine adjusted the CIC2 filter settings after the software reset occurred. The change to the settings increased the maximum possible raw counts.

    | Parameter | Default (N-subs = 8) | After Change (N-subs = 10) |
    | --------- | -------------------- | -------------------------- |
    | N-subs | 8 | 10 |
    | Sense clock divider | 16 | 16 |
    | Maxcount | 1764 | 2809 |
    | Rawcount | 1505 | 2389 |
    | Rawcount % of Maxcount | 85.31% | 85.04% |
    | Decimation Rate | 42 | 53 |

    * Use the following equations to confirm the decimation rate and max count and find the conversion gain.

    From [AN85951, Section 3.4.4 **Ratiometric sensing technology**](https://www.infineon.com/assets/row/public/documents/30/42/infineon-an85951-psoc-4-psoc-6-capsense-design-guide-applicationnotes-en.pdf?fileId=8ac78c8c7cdc391c017d0723535d4661#page=59), the CSD-RM dual-CDAC rawcount relationship is:

    $$
    \mathrm{RawCount} = \mathrm{MaxCount} \cdot \frac{C_S - 2\cdot\left(\frac{\mathrm{SnsClkDiv}}{\mathrm{CompClkDiv}}\right)\cdot C_{\mathrm{comp}}}{\mathrm{SnsClkDiv}\cdot C_{\mathrm{ref}}}
    $$

    With CIC2 enabled:

    $$
    \mathrm{MaxCount} = (\mathrm{DecimationRate})^2 \cdot K
    $$

    $$
    \mathrm{DecimationRate} = \frac{\mathrm{SnsClkDiv} \cdot N_{\mathrm{sub}}}{3}
    $$

    Rearranging the raw-count equation to an equivalent conversion-gain form:

    $$
    G_{\mathrm{CSD-RM}} = \frac{\mathrm{RawCount}}{C_S - 2\cdot\left(\frac{\mathrm{SnsClkDiv}}{\mathrm{CompClkDiv}}\right)\cdot C_{\mathrm{comp}}} = \frac{\mathrm{MaxCount}}{\mathrm{SnsClkDiv}\cdot C_{\mathrm{ref}}}
    $$

    The $C_S$ axis intercept is the capacitance where raw count is zero:

    $$
    C_S\ \text{axis intercept} = \frac{2\cdot C_{\mathrm{comp}}\cdot\mathrm{SnsClkDiv}}{\mathrm{CompClkDiv}}
    $$


    | Parameter | Default (N-subs = 8) | After Change (N-subs = 10) |
    | --------- | -------------------- | -------------------------- |
    | K | 1.0000 | 1.0000 |
    | Maxcount calculated | 1764 | 2809 |
    | Decimation rate | 42 | 53 |
    | Conversion gain | 3.8017 | 6.0539 |
    | Cs axis intercept | 32 | 32 |

8. Compare the conversion gain when you switch between 8 and 10 sub-conversions, and then observe the sensor DiffCount in the graph window. During a touch event, the DiffCount should be approximately 180 with 8 sub-conversions and approximately 330 with 10 sub-conversions

9. Adjust the number of sub-conversions until the decimation rate achieved is 255. What is the minimum number of sub-conversions needed to hit this number?

### Shield study

1. Disconnect from the device and close the CAPSENSE&trade; tuner

2. In VS Code, open the CAPSENSE&trade; configurator from the ModusToolbox&trade; for VS Code extension quick panel

<img src="assets/images/launching_capsense_configurator_from_modustoolbox_vscode_extension.png" alt="Figure" style="width:800px; height:auto; display:block; margin:0 auto;" />

3. Navigate to **Advanced** > **General**, and then select **Enable self-test library**

<img src="assets/images/self-test-enable.png" alt="Figure" style="width:800px; height:auto; display:block; margin:0 auto;" />

4. Save and close the CAPSENSE&trade; configurator
5. After initializing CAPSENSE&trade;, copy the following function into **main.c** to run the self-test function and measure the parasitic capacitance of the sensors

```c

/* Initialize MSC CAPSENSE */
initialize_capsense();

/* Run the available capsense self-test */
Cy_CapSense_RunSelfTest(CY_CAPSENSE_BIST_RUN_AVAILABLE_SELF_TEST_MASK,
                        &cy_capsense_context);
```

6. Program the device, and then reopen the CAPSENSE&trade; tuner

7. Reconnect to the device, begin streaming, and then observe the sensor capacitance

<img src="assets/images/tuner_sensor_capacitance.png" alt="Figure" style="width:600px; height:auto; display:block; margin:0 auto;" />

8. Disconnect from the device and close the CAPSENSE&trade; tuner

9. In VS Code, open the **CAPSENSE&trade; configurator** from the **ModusToolbox&trade; for VS Code extension**
10. Navigate to **Advanced** > **CSD Settings**, and then disable the shields
    
<img src="assets/images/configurator_disable_shield.png" alt="Figure" style="width:600px; height:auto; display:block; margin:0 auto;" />

11. Save and close the CAPSENSE&trade; configurator
12. Program the device, and then reopen the CAPSENSE&trade; tuner
13. Observe the sensor capacitance once again. What impact will this change have on overall performance?

### Things to try

Now you have experimented with how both the number of sub-conversions and the shield settings will impact sensor performance. Sub-conversions work together with the sense clock divider and decimation rate to control the overall gain of the conversion. The shield can dramatically reduce sensor parasitics, minimizing the need for gain (and power) increases. It can also provide liquid tolerance.

Use the calculator below to compare the default values observed in the lab with your adjusted values. Refine the pre-filled default values for the unit under test, and then enter values in the **Adjusted value** column to calculate the resulting parameters. The decimation rate is limited to the CIC2 hardware maximum of 255.

For the Markdown version of this manual, use the equivalent Excel solution workbook below to enter values and calculate the conversion parameters.

The equivalent Excel solution workbook is available for offline reference: [CSD-RM CAPSENSE&trade; conversion calculator solution](https://github.com/Infineon/mtb-training-psoc-4-msclp-capsense-deep-dive/blob/main/Lab%20Solutions/CSD-RM%CAPSENSE%20conversion%20calculator%20solution.xlsx).

1. Adjust the number of sub-conversions until the decimation rate is 255, and record the corresponding conversion gain

2. Compare your result with the values in the CAPSENSE&trade; tuner

### Conclusion

When tuning a self-capacitive sensor for a production-ready unit, consider the following:

* **Shielding**
    * If liquid tolerance is required, consider using shielding techniques to improve robustness.
    * Shielding also minimizes parasitic capacitance.
* **Gain tuning**
    * Carefully selecting the number of sub-conversions can have an outsized improvement in gain and SNR.

## CSX sensor tuning for production

### Objective

In this lab, you will use the MSCLP Low Power CSX Button example to tune the sensor for production and evaluate the effect of the Tx clock divider.

### Project creation

1. Launch **Project Creator**, and then select the **CY8CPROTO-041TP** BSP under the PSOC 4 BSPs, and then click **Next**

<img src="assets/images/project_creator_cy8proto041tp_bsp_selection.png" alt="Project Creator BSP Selection" style="width:800px; height:auto; display:block; margin:0 auto;" />

2. Click **Next** to proceed to the application selection menu. Select the **MSCLP Low Power CSX Button** under the Sensing section by clicking the **checkbox** near the application, and then click **Create**

<img src="assets/images/csx_project_creator_example_code_project_creation.png" alt="Project Creator CSX example code creation" style="width:800px; height:auto; display:block; margin:0 auto;" />

3. When you click **Create**, a new project is created. The project location is under the **Application root path**, in a folder with the given project name. Navigate to the project directory, find the **.code-workspace** file, and open it with Microsoft Visual Studio Code

<img src="assets/images/csx_vscode_workspace_file.png" alt="VS Code workspace file after CSX project creation" style="width:800px; height:auto; display:block; margin:0 auto;" />

4. Once the project is opened in Microsoft Visual Studio Code, make sure you have the **ModusToolbox&trade; for VS Code** extension installed. Once the extension is running, you will see it in the main panel

<img src="assets/images/csx_vsocde_modustoolbox_extension.png" alt="ModusToolbox for VS Code extension after CSX project creation" style="width:1200px; height:auto; display:block; margin:0 auto;" />

<br>

> **Note:** VS Code may launch the workspace in **Restricted Mode**. If this happens, locate the blue ribbon under the taskbar indicating **Restricted Mode** and select **Manage**. A **Workspace Trust** window will pop up. Select **Trust** and close the window. The workspace will refresh and the ModusToolbox&trade; for VS Code extension will display after a brief delay.

<img src="assets/images/restricted_mode.png" alt="VS Code extension prompting to fix tasks and settings" style="width:1000px; height:auto; display:block; margin:0 auto;" />

> **Note:** The ModusToolbox&trade; for VS Code extension may display buttons indicating that the VS Code tasks and settings need to be updated. Simply click the buttons to correct the issues. This is a minor version mismatch between the ModusToolbox&trade; tools and the VS Code extension and does not affect functionality.

<img src="assets/images/vscode_fix_tasks_settings_prompt.png" alt="VS Code extension prompting to fix tasks and settings" style="width:800px; height:auto; display:block; margin:0 auto;" />

### CSX-RM Tx Clock Divider and Cm Mismatch

1. Open the CAPSENSE&trade; configurator from the ModusToolbox&trade; for VS Code extension quick panel

<img src="assets/images/launching_capsense_configurator_from_modustoolbox_vscode_extension.png" alt="Figure" style="width:800px; height:auto; display:block; margin:0 auto;" />

2. Navigate to **Advanced** > **General**, and then select **Enable self-test library**

<img src="assets/images/csx_self_test_enable.png" alt="Figure" style="width:800px; height:auto; display:block; margin:0 auto;" />

3. Save and close the CAPSENSE&trade; configurator
4. After initializing CAPSENSE&trade;, copy the following function into **main.c** to run the self-test function and measure the parasitic capacitance of the sensors

```c

/* Initialize MSC CAPSENSE */
initialize_capsense();

/* Run the available capsense self-test */
Cy_CapSense_RunSelfTest(CY_CAPSENSE_BIST_RUN_AVAILABLE_SELF_TEST_MASK,
                        &cy_capsense_context);
```

5. Program the device, and then reopen the CAPSENSE&trade; tuner

6. Reconnect to the device, begin streaming, and then observe the sensor capacitance

<img src="assets/images/tuner_sensor_capacitance_csx.png" alt="Figure" style="width:400px; height:auto; display:block; margin:0 auto;" />

See the following guidance for selecting a Tx clock divider for a CSX-RM sensor:

Use the actual CAPSENSE IMO frequency, $F_{\mathrm{mod}}$, in the following relationship. The CAPSENSE IMO supports 46 MHz, 38 MHz, and 24 MHz. The selected frequency can be divided by the configured modulator-clock divider:

$$
\mathrm{TxClkDiv} = F_{\mathrm{mod}}\cdot5\cdot\mathrm{R}\cdot C
$$

For the default modulator frequency:

$$
F_{\mathrm{mod}} = 46\ \mathrm{MHz}
$$

If the modulator clock is divided, use the resulting frequency instead (for example, $F_{\mathrm{mod}} = 46\ \mathrm{MHz}/N$):

$$
\mathrm{TxClkDiv} = \left(\frac{46\ \mathrm{MHz}}{N}\right)\cdot5\cdot\mathrm{R}\cdot C
$$

7. Calculate an acceptable Tx clock divider for each capacitance value. Record the calculated value and the value measured in the CAPSENSE&trade; tuner

For the Markdown version of this manual, use the equivalent Excel solution workbook below to calculate the Tx clock divider values.

The calculator uses MHz, Ohm, and fF units. It converts capacitance from fF using $1\ \mathrm{fF} = 10^{-15}\ \mathrm{F}$. The recommended divider is constrained to an even value from 4 through 4094. Its equivalent Excel solution workbook is available for offline reference: [CSX-RM Tx clock divider calculator solution](https://github.com/Infineon/mtb-training-psoc-4-msclp-capsense-deep-dive/blob/main/Lab%20Solutions/CSX-RM%20Tx%20clock%20divider%20calculator%20solution.xlsx).
      
8. Consider the below equation to answer the following question. The CDAC auto-calibration routine attempts to keep the same RawCount value by controlling the CDACs. What happens to the CDACs when you set TxClkDiv for $C_M$ and for $C_{\mathrm{Tx}}$?

$$
\mathrm{RawCount} = \mathrm{MaxCount} \cdot \frac{C_M}{2\cdot\mathrm{TxClkDiv}\cdot C_{\mathrm{ref}}}
$$

9. Now consider that in many designs, $C_{\mathrm{Tx}}$ is much larger, and $C_M$ is much smaller - what is required to make these designs work?

### Things to try

In the CAPSENSE&trade; configurator, record the **Reference CDAC value**, **Number of sub-conversions**, **Tx clock divider**, **Compensation CDAC value**, and **Compensation CDAC divider** for the CSX widget. In the CAPSENSE&trade; tuner, record the raw count before and during a touch.

The CSX-RM converter supports single-CDAC and dual-CDAC operation. In single-CDAC mode, the reference CDAC is active and the compensation CDAC is off. In dual-CDAC mode, the compensation CDAC removes part of the sensor mutual capacitance before the reference CDAC conversion. The calculator uses the CIC2 filter-enabled conversion model.

From [AN85951, Section 3.5.1 **Ratiometric sensing technology**](https://www.infineon.com/assets/row/public/documents/30/42/infineon-an85951-psoc-4-psoc-6-capsense-design-guide-applicationnotes-en.pdf?fileId=8ac78c8c7cdc391c017d0723535d4661#page=65), the CSX-RM CIC2-enabled single-CDAC raw-count relationship is:

$$
\mathrm{RawCount} = \mathrm{MaxCount} \cdot \frac{C_M}{2\cdot\mathrm{TxClkDiv}\cdot C_{\mathrm{ref}}}
$$

For CIC2-enabled dual-CDAC operation, the relationship is:

$$
\mathrm{RawCount} = \mathrm{MaxCount} \cdot \frac{C_M - \left(\frac{\mathrm{TxClkDiv}}{\mathrm{CompClkDiv}}\right)\cdot C_{\mathrm{comp}}}{2\cdot\mathrm{TxClkDiv}\cdot C_{\mathrm{ref}}}
$$

The CIC2 decimation rate and maxcount equations:

$$
\mathrm{MaxCount} = (\mathrm{DecimationRate})^2\cdot K
$$

$$
\mathrm{DecimationRate} = \frac{\mathrm{SnsClkDiv} \cdot N_{\mathrm{sub}}}{3}
$$

Rearranging the raw-count equation to an equivalent conversion-gain form:

$$
G_{\mathrm{CSX}} = \frac{\mathrm{MaxCount}}{2\cdot C_{\mathrm{ref}}\cdot\mathrm{TxClkDiv}}
$$

The $C_M$ axis intercept is the mutual capacitance where the raw count is zero:

$$
C_M\ \text{axis intercept} = \frac{\mathrm{TxClkDiv}\cdot C_{\mathrm{comp}}}{\mathrm{CompClkDiv}}
$$

When CDAC codes are used directly, the common CDAC LSB factor cancels in the gain and intercept calculations. The chart uses the firmware-reported rawcount component, so it descends as mutual capacitance increases. Use the calculator below to compare the default values observed in the lab with adjusted values.

For the Markdown version of this manual, use the equivalent Excel solution workbook below to enter values and calculate the conversion parameters.

The equivalent Excel solution workbook is available for offline reference: [CSX-RM CAPSENSE&trade; conversion calculator solution](https://github.com/Infineon/mtb-training-psoc-4-msclp-capsense-deep-dive/blob/main/Lab%20Solutions/CSX-RM%CAPSENSE%20conversion%20calculator%20solution.xlsx).

1. Adjust the number of sub-conversions until the decimation rate is 255, and record the corresponding conversion gain

2. Compare your result with the values in the CAPSENSE&trade; tuner

3. Why is the CSX rawcount vs. sensor capacitance plot a descending line instead of ascending like the CSD plot? 

### Conclusion

You compared CSD and CSX sensor tuning workflows and identified how the available conversion parameters affect sensor performance.

## References

* [PSOC&trade; 4 and PSOC&trade; 6 MCU CAPSENSE&trade; design guide](https://www.infineon.com/assets/row/public/documents/30/42/infineon-an85951-psoc-4-psoc-6-capsense-design-guide-applicationnotes-en.pdf)

## Revision history

Document title: *xxxxxx* - *PSOC&trade; 4 CAPSENSE&trade; deep dive into the MSCLP ratio-metric converter*

 Version | Description of change
 ------- | ---------------------
 **   | Initial release<br>
<br>


## Disclaimer
All referenced product or service names and trademarks are the property of their respective owners.

The Bluetooth&reg; word mark and logos are registered trademarks owned by Bluetooth SIG, Inc., and any use of such marks by Infineon is under license.

PSOC&trade;, formerly known as PSoC&trade;, is a trademark of Infineon Technologies. Any references to PSoC&trade; in this document or others shall be deemed to refer to PSOC&trade;.

---------------------------------------------------------

© Cypress Semiconductor Corporation, 2023-2025. This document is the property of Cypress Semiconductor Corporation, an Infineon Technologies company, and its affiliates ("Cypress").  This document, including any software or firmware included or referenced in this document ("Software"), is owned by Cypress under the intellectual property laws and treaties of the United States and other countries worldwide.  Cypress reserves all rights under such laws and treaties and does not, except as specifically stated in this paragraph, grant any license under its patents, copyrights, trademarks, or other intellectual property rights.  If the Software is not accompanied by a license agreement and you do not otherwise have a written agreement with Cypress governing the use of the Software, then Cypress hereby grants you a personal, non-exclusive, nontransferable license (without the right to sublicense) (1) under its copyright rights in the Software (a) for Software provided in source code form, to modify and reproduce the Software solely for use with Cypress hardware products, only internally within your organization, and (b) to distribute the Software in binary code form externally to end users (either directly or indirectly through resellers and distributors), solely for use on Cypress hardware product units, and (2) under those claims of Cypress's patents that are infringed by the Software (as provided by Cypress, unmodified) to make, use, distribute, and import the Software solely for use with Cypress hardware products.  Any other use, reproduction, modification, translation, or compilation of the Software is prohibited.
<br>
TO THE EXTENT PERMITTED BY APPLICABLE LAW, CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH REGARD TO THIS DOCUMENT OR ANY SOFTWARE OR ACCOMPANYING HARDWARE, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  No computing device can be absolutely secure.  Therefore, despite security measures implemented in Cypress hardware or software products, Cypress shall have no liability arising out of any security breach, such as unauthorized access to or use of a Cypress product. CYPRESS DOES NOT REPRESENT, WARRANT, OR GUARANTEE THAT CYPRESS PRODUCTS, OR SYSTEMS CREATED USING CYPRESS PRODUCTS, WILL BE FREE FROM CORRUPTION, ATTACK, VIRUSES, INTERFERENCE, HACKING, DATA LOSS OR THEFT, OR OTHER SECURITY INTRUSION (collectively, "Security Breach").  Cypress disclaims any liability relating to any Security Breach, and you shall and hereby do release Cypress from any claim, damage, or other liability arising from any Security Breach.  In addition, the products described in these materials may contain design defects or errors known as errata which may cause the product to deviate from published specifications. To the extent permitted by applicable law, Cypress reserves the right to make changes to this document without further notice. Cypress does not assume any liability arising out of the application or use of any product or circuit described in this document. Any information provided in this document, including any sample design information or programming code, is provided only for reference purposes.  It is the responsibility of the user of this document to properly design, program, and test the functionality and safety of any application made of this information and any resulting product.  "High-Risk Device" means any device or system whose failure could cause personal injury, death, or property damage.  Examples of High-Risk Devices are weapons, nuclear installations, surgical implants, and other medical devices.  "Critical Component" means any component of a High-Risk Device whose failure to perform can be reasonably expected to cause, directly or indirectly, the failure of the High-Risk Device, or to affect its safety or effectiveness.  Cypress is not liable, in whole or in part, and you shall and hereby do release Cypress from any claim, damage, or other liability arising from any use of a Cypress product as a Critical Component in a High-Risk Device. You shall indemnify and hold Cypress, including its affiliates, and its directors, officers, employees, agents, distributors, and assigns harmless from and against all claims, costs, damages, and expenses, arising out of any claim, including claims for product liability, personal injury or death, or property damage arising from any use of a Cypress product as a Critical Component in a High-Risk Device. Cypress products are not intended or authorized for use as a Critical Component in any High-Risk Device except to the limited extent that (i) Cypress's published data sheet for the product explicitly states Cypress has qualified the product for use in a specific High-Risk Device, or (ii) Cypress has given you advance written authorization to use the product as a Critical Component in the specific High-Risk Device and you have signed a separate indemnification agreement.
<br>
Cypress, the Cypress logo, and combinations thereof, ModusToolbox, PSOC, CAPSENSE, EZ-USB, F-RAM, and TRAVEO are trademarks or registered trademarks of Cypress or a subsidiary of Cypress in the United States or in other countries. For a more complete list of Cypress trademarks, visit www.infineon.com. Other names and brands may be claimed as property of their respective owners.
