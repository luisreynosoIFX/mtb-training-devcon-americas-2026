document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-tx-divider-calculator]").forEach((calculator) => {
    const inputs = Object.fromEntries(
      Array.from(calculator.querySelectorAll("[data-tx-divider-input]")).map((input) => [input.dataset.txDividerInput, input])
    );
    const capacitances = Object.fromEntries(
      Array.from(calculator.querySelectorAll("[data-capacitance-input]")).map((input) => [input.dataset.capacitanceInput, input])
    );
    const results = Object.fromEntries(
      Array.from(calculator.querySelectorAll("[data-divider-output]")).map((output) => [output.dataset.dividerOutput, output])
    );
    const error = calculator.querySelector("[data-divider-error]");
    const supportedFrequencies = new Set([46, 38, 24]);

    const readNumber = (input) => Number(input.value);
    const formatDivider = (value) => value.toLocaleString("en-US", {
      minimumFractionDigits: 3,
      maximumFractionDigits: 3
    });

    const update = () => {
      const modulatorFrequency = readNumber(inputs.modulatorFrequency);
      const modulatorClockDivider = readNumber(inputs.modulatorClockDivider);
      const resistance = readNumber(inputs.resistance);
      const validSharedInputs = [modulatorFrequency, modulatorClockDivider, resistance].every(Number.isFinite) &&
        supportedFrequencies.has(modulatorFrequency) && modulatorClockDivider > 0 && resistance > 0;
      const calculated = {};

      Object.entries(capacitances).forEach(([name, input]) => {
        const capacitance = readNumber(input);
        const value = validSharedInputs && Number.isFinite(capacitance) && capacitance > 0
          ? (modulatorFrequency / modulatorClockDivider) * 5 * resistance * capacitance * 1e-9
          : undefined;
        calculated[name] = value;
        results[`${name}Calculated`].textContent = value === undefined ? "--" : formatDivider(value);
        if (value === undefined) {
          results[`${name}Recommended`].textContent = "--";
        } else {
          const recommended = Math.min(4094, Math.max(4, Math.ceil(value)));
          results[`${name}Recommended`].textContent = (recommended % 2 === 0 ? recommended : recommended + 1).toLocaleString("en-US");
        }
      });

      error.hidden = validSharedInputs && Object.values(calculated).every(Number.isFinite);
      if (!error.hidden) {
        error.textContent = "Select 46, 38, or 24 MHz for Fmod, then enter positive values for the modulator-clock divider, R, and both capacitances.";
      }
    };

    [...Object.values(inputs), ...Object.values(capacitances)].forEach((input) => input.addEventListener("input", update));
    update();
  });
});