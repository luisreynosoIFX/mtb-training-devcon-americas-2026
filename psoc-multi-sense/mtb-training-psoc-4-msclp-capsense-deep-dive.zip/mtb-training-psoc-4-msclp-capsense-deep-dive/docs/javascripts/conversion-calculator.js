document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-conversion-calculator]").forEach((calculator) => {
    const mode = calculator.dataset.conversionMode || "csd-rm";
    const defaultInputs = Object.fromEntries(
      Array.from(calculator.querySelectorAll("[data-default-field]")).map((input) => [input.dataset.defaultField, input])
    );
    const adjustedInputs = Object.fromEntries(
      Array.from(calculator.querySelectorAll("[data-adjusted-field]")).map((input) => [input.dataset.adjustedField, input])
    );
    const defaultOutputs = Object.fromEntries(
      Array.from(calculator.querySelectorAll("[data-default-output]")).map((output) => [output.dataset.defaultOutput, output])
    );
    const adjustedOutputs = Object.fromEntries(
      Array.from(calculator.querySelectorAll("[data-adjusted-output]")).map((output) => [output.dataset.adjustedOutput, output])
    );
    const error = calculator.querySelector("[data-error]");
    const chart = calculator.querySelector("[data-gain-chart]");
    const initialAdjustedValues = Object.fromEntries(
      Object.entries(adjustedInputs).map(([field, input]) => [field, input.value])
    );

    const createSvgElement = (name, attributes) => {
      const element = document.createElementNS("http://www.w3.org/2000/svg", name);
      Object.entries(attributes).forEach(([attribute, value]) => element.setAttribute(attribute, value));
      return element;
    };

    const renderChart = (defaultSeries, adjustedSeries) => {
      const series = [defaultSeries, adjustedSeries].filter(Boolean);
      const isCsx = mode === "csx";
      const chartRawcount = (_item, rawcount) => rawcount;
      if (series.length === 0) {
        chart.replaceChildren();
        return;
      }
      const fullScaleCapacitance = (item) => item.intercept + (item.maxcount / item.gain);
      const rawcountMarkers = [
        ...(defaultSeries ? [
          { series: defaultSeries, rawcount: chartRawcount(defaultSeries, defaultSeries.rawcount), type: "baseline", label: isCsx ? "Cm" : "Cp" },
          ...(Number.isFinite(defaultSeries.touchRawcount) ? [{ series: defaultSeries, rawcount: chartRawcount(defaultSeries, defaultSeries.touchRawcount), type: "touch", label: isCsx ? "Cm + Cf" : "Cp + Cf" }] : [])
        ] : []),
        ...(adjustedSeries ? [
          { series: adjustedSeries, rawcount: chartRawcount(adjustedSeries, adjustedSeries.rawcount), type: "baseline", label: isCsx ? "Cm" : "Cp" },
          ...(Number.isFinite(adjustedSeries.touchRawcount) ? [{ series: adjustedSeries, rawcount: chartRawcount(adjustedSeries, adjustedSeries.touchRawcount), type: "touch", label: isCsx ? "Cm + Cf" : "Cp + Cf" }] : [])
        ] : [])
      ];
      const markerCapacitance = (marker) => marker.series.intercept + (isCsx
        ? (marker.series.maxcount - marker.rawcount) / marker.series.gain
        : marker.rawcount / marker.series.gain);
      const xMaximum = Math.max(
        ...series.map(fullScaleCapacitance),
        ...rawcountMarkers.map(markerCapacitance)
      ) * 1.08;
      const yMaximum = Math.max(
        ...series.map((item) => item.maxcount),
        ...rawcountMarkers.map((marker) => marker.rawcount)
      ) * 1.12;
      const dimensions = { width: 680, height: 300, left: 72, right: 24, top: 28, bottom: 52 };
      const plotWidth = dimensions.width - dimensions.left - dimensions.right;
      const plotHeight = dimensions.height - dimensions.top - dimensions.bottom;
      const xPosition = (value) => dimensions.left + ((value / xMaximum) * plotWidth);
      const yPosition = (value) => dimensions.height - dimensions.bottom - ((value / yMaximum) * plotHeight);

      chart.replaceChildren();
      chart.append(
        createSvgElement("line", { x1: dimensions.left, y1: dimensions.top, x2: dimensions.left, y2: dimensions.height - dimensions.bottom, class: "conversion-gain-chart__axis" }),
        createSvgElement("line", { x1: dimensions.left, y1: dimensions.height - dimensions.bottom, x2: dimensions.width - dimensions.right, y2: dimensions.height - dimensions.bottom, class: "conversion-gain-chart__axis" })
      );

      for (let index = 0; index <= 4; index += 1) {
        const value = (yMaximum * index) / 4;
        const y = yPosition(value);
        chart.append(
          createSvgElement("line", { x1: dimensions.left, y1: y, x2: dimensions.width - dimensions.right, y2: y, class: "conversion-gain-chart__grid" }),
          createSvgElement("text", { x: dimensions.left - 10, y: y + 4, class: "conversion-gain-chart__label", "text-anchor": "end" })
        );
        chart.lastChild.textContent = Math.round(value).toLocaleString("en-US");
      }

      chart.append(
        createSvgElement("text", { x: dimensions.left + (plotWidth / 2), y: dimensions.height - 12, class: "conversion-gain-chart__label", "text-anchor": "middle" }),
        createSvgElement("text", { x: 17, y: dimensions.top + (plotHeight / 2), class: "conversion-gain-chart__label", transform: `rotate(-90 17 ${dimensions.top + (plotHeight / 2)})`, "text-anchor": "middle" })
      );
      chart.children[chart.children.length - 2].textContent = "Sensor capacitance";
      chart.lastChild.textContent = isCsx ? "Rawcount component" : "Rawcount";

      series.forEach((item) => {
        const endpoint = fullScaleCapacitance(item);
        const lineStartRawcount = isCsx ? item.maxcount : 0;
        const lineEndRawcount = isCsx ? 0 : item.maxcount;
        chart.append(
          createSvgElement("path", { d: `M ${xPosition(item.intercept)} ${yPosition(lineStartRawcount)} L ${xPosition(endpoint)} ${yPosition(lineEndRawcount)}`, stroke: item.color, class: "conversion-gain-chart__line" })
        );
      });

      rawcountMarkers.forEach((marker) => {
        const x = xPosition(markerCapacitance(marker));
        const y = yPosition(marker.rawcount);
        if (marker.type === "baseline") {
          chart.append(createSvgElement("circle", {
            cx: x, cy: y, r: 6, fill: marker.series.color, stroke: "#FFFEFF", "stroke-width": 2
          }));
        } else {
          const radius = 7;
          chart.append(createSvgElement("path", {
            d: `M ${x} ${y - radius} L ${x + radius} ${y} L ${x} ${y + radius} L ${x - radius} ${y} Z`,
            fill: marker.series.color, stroke: "#FFFEFF", "stroke-width": 2
          }));
        }
        const labelY = marker.type === "baseline" ? y + 20 : y - (isCsx ? 20 : 27);
        const label = createSvgElement("text", {
          x, y: labelY, class: "conversion-gain-chart__marker-label", fill: marker.series.color,
          "text-anchor": "middle"
        });
        label.textContent = marker.label;
        chart.append(label);
      });
    };

    const readValues = (inputs) => Object.fromEntries(
      Object.entries(inputs).map(([field, input]) => [field, Number(input.value)])
    );

    const hasBlankRequiredValue = (inputs) => Object.entries(inputs).some(
      ([field, input]) => field !== "touchRawcount" && input.value.trim() === ""
    );

    const hasTouchRawcount = (inputs) => inputs.touchRawcount.value.trim() !== "";

    const exceedsCic2AccumulatorLimit = (values, clockField = "senseClockDivider") => {
      const conversionClocks = values[clockField] * values.subConversions;
      if (!Number.isFinite(conversionClocks) || conversionClocks <= 0) {
        return false;
      }
      const decimationRate = Math.min(Math.floor(conversionClocks / 3), 255);
      if (decimationRate < 255) {
        return false;
      }
      const cic2Samples = Math.floor(conversionClocks / decimationRate) - 1;
      const cic2AccumulatorSizeMax = (2 ** 25) - 1;
      return cic2Samples * (decimationRate ** 2) > cic2AccumulatorSizeMax;
    };

    const isCsxValid = (values, hasTouch) => [
      values.referenceCdac, values.subConversions, values.txClockDivider, values.ccomp,
      values.compClkDiv, values.rawcount
    ].every(Number.isFinite) &&
      Number.isInteger(values.referenceCdac) && values.referenceCdac >= 1 && values.referenceCdac <= 255 &&
      Number.isInteger(values.subConversions) && values.subConversions >= 1 && values.subConversions <= 16383 &&
      Number.isInteger(values.txClockDivider) && values.txClockDivider >= 1 && values.txClockDivider <= 4095 &&
      Number.isInteger(values.ccomp) && values.ccomp >= 0 && values.ccomp <= 255 &&
      Number.isInteger(values.compClkDiv) && values.compClkDiv >= 1 && values.compClkDiv <= 4095 &&
      values.compClkDiv <= values.txClockDivider && values.rawcount >= 0 &&
      (!hasTouch || (Number.isFinite(values.touchRawcount) && values.touchRawcount >= 0)) &&
      Math.floor((values.txClockDivider * values.subConversions) / 3) > 0 &&
      !exceedsCic2AccumulatorLimit(values, "txClockDivider");

    const isValid = (values, hasTouch) => [
      values.referenceCdac, values.subConversions, values.senseClockDivider, values.ccomp,
      values.compClkDiv, values.rawcount
    ].every(Number.isFinite) &&
      Number.isInteger(values.referenceCdac) && values.referenceCdac >= 0 && values.referenceCdac <= 255 &&
      Number.isInteger(values.subConversions) &&
      values.subConversions >= 1 && values.subConversions <= 16383 && Number.isInteger(values.senseClockDivider) &&
      values.senseClockDivider >= 8 && values.senseClockDivider <= 4095 &&
      Number.isInteger(values.ccomp) && values.ccomp >= 0 && values.ccomp <= 255 && Number.isInteger(values.compClkDiv) &&
      values.compClkDiv >= 2 && values.compClkDiv <= 4095 && values.rawcount >= 0 &&
      (!hasTouch || (Number.isFinite(values.touchRawcount) && values.touchRawcount >= 0)) &&
      Math.floor((values.senseClockDivider * values.subConversions) / 3) > 0 &&
      !exceedsCic2AccumulatorLimit(values);

    const calculate = (values, hasTouch) => {
      if (mode === "csx") {
        const decimationRate = Math.min(
          Math.floor((values.txClockDivider * values.subConversions) / 3),
          255
        );
        const cic2Samples = Math.floor(
          (values.txClockDivider * values.subConversions) / decimationRate
        ) - 1;
        const cic2HardwareShift = Math.ceil(Math.log2(cic2Samples));
        const cic2HardwareDivider = 2 ** cic2HardwareShift;
        const k = cic2Samples / cic2HardwareDivider;
        const maxcount = Math.round((decimationRate ** 2) * k);
        const conversionGain = maxcount / (2 * values.referenceCdac * values.txClockDivider);
        return {
          decimationRate,
          k,
          maxcount,
          rawcountPercent: maxcount === 0 ? 0 : values.rawcount / maxcount,
          conversionGain,
          csAxisIntercept: (values.txClockDivider * values.ccomp) / values.compClkDiv,
          rawcount: values.rawcount,
          touchRawcount: hasTouch ? values.touchRawcount : undefined
        };
      }
      const decimationRate = Math.min(
        Math.floor((values.senseClockDivider * values.subConversions) / 3),
        255
      );
      const cic2Samples = Math.floor(
        (values.senseClockDivider * values.subConversions) / decimationRate
      ) - 1;
      const cic2HardwareShift = Math.ceil(Math.log2(cic2Samples));
      const cic2HardwareDivider = 2 ** cic2HardwareShift;
      const k = cic2Samples / cic2HardwareDivider;
      const maxcount = Math.round((decimationRate ** 2) * k);
      return {
        decimationRate,
        k,
        maxcount,
        rawcountPercent: maxcount === 0 ? 0 : values.rawcount / maxcount,
        conversionGain: maxcount / (values.senseClockDivider * values.referenceCdac),
        csAxisIntercept: (2 * values.ccomp * values.senseClockDivider) / values.compClkDiv,
        rawcount: values.rawcount,
        touchRawcount: hasTouch ? values.touchRawcount : undefined
      };
    };

    const updateOutputs = (outputs, results) => {
      if (!results) {
        Object.values(outputs).forEach((output) => { output.textContent = "--"; });
        return;
      }
      outputs.maxcount.textContent = results.maxcount.toLocaleString("en-US");
      outputs.rawcountPercent.textContent = results.rawcountPercent.toLocaleString("en-US", {
        style: "percent", minimumFractionDigits: 2, maximumFractionDigits: 2
      });
      if (outputs.k) {
        outputs.k.textContent = results.k.toLocaleString("en-US", {
          minimumFractionDigits: 4, maximumFractionDigits: 4
        });
      }
      if (outputs.decimationRate) {
        outputs.decimationRate.textContent = results.decimationRate.toLocaleString("en-US");
      }
      outputs.conversionGain.textContent = results.conversionGain.toLocaleString("en-US", {
        minimumFractionDigits: 3, maximumFractionDigits: 3
      });
      outputs.csAxisIntercept.textContent = results.csAxisIntercept.toLocaleString("en-US");
    };

    const update = () => {
      const defaultValues = readValues(defaultInputs);
      const adjustedValues = readValues(adjustedInputs);
      const defaultHasBlankValue = hasBlankRequiredValue(defaultInputs);
      const adjustedHasBlankValue = hasBlankRequiredValue(adjustedInputs);
      const adjustedHasAnyValue = Object.values(adjustedInputs).some((input) => input.value.trim() !== "");
      const clockField = mode === "csx" ? "txClockDivider" : "senseClockDivider";
      const defaultExceedsCic2AccumulatorLimit = exceedsCic2AccumulatorLimit(defaultValues, clockField);
      const adjustedExceedsCic2AccumulatorLimit = exceedsCic2AccumulatorLimit(adjustedValues, clockField);
      const defaultIsValid = !defaultHasBlankValue && (mode === "csx"
        ? isCsxValid(defaultValues, hasTouchRawcount(defaultInputs))
        : isValid(defaultValues, hasTouchRawcount(defaultInputs)));
      const adjustedIsValid = !adjustedHasBlankValue && (mode === "csx"
        ? isCsxValid(adjustedValues, hasTouchRawcount(adjustedInputs))
        : isValid(adjustedValues, hasTouchRawcount(adjustedInputs)));
      const defaultResults = defaultIsValid ? calculate(defaultValues, hasTouchRawcount(defaultInputs)) : undefined;
      const adjustedResults = adjustedHasAnyValue && adjustedIsValid
        ? calculate(adjustedValues, hasTouchRawcount(adjustedInputs))
        : undefined;

      updateOutputs(defaultOutputs, defaultResults);
      updateOutputs(adjustedOutputs, adjustedResults);
      error.hidden = defaultIsValid && (!adjustedHasAnyValue || adjustedIsValid);
      if (!error.hidden) {
        error.textContent = (defaultExceedsCic2AccumulatorLimit ||
          (adjustedHasAnyValue && adjustedExceedsCic2AccumulatorLimit)
          ) ? "These values exceed the CIC2 accumulator limit at a decimation rate of 255."
          : "Enter valid values for every required field.";
      }
      renderChart(
        defaultResults && { label: "Default", color: "#0A8276", gain: defaultResults.conversionGain,
          intercept: defaultResults.csAxisIntercept, maxcount: defaultResults.maxcount,
          rawcount: defaultResults.rawcount, touchRawcount: defaultResults.touchRawcount },
        adjustedResults && { label: "Adjusted", color: "#D55E00", gain: adjustedResults.conversionGain,
          intercept: adjustedResults.csAxisIntercept, maxcount: adjustedResults.maxcount,
          rawcount: adjustedResults.rawcount, touchRawcount: adjustedResults.touchRawcount }
      );
    };

    [...Object.values(defaultInputs), ...Object.values(adjustedInputs)].forEach((input) => input.addEventListener("input", update));
    calculator.querySelector("[data-reset]").addEventListener("click", () => {
      Object.entries(adjustedInputs).forEach(([field, input]) => { input.value = initialAdjustedValues[field]; });
      update();
    });
    update();
  });
});