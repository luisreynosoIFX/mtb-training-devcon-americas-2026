# Lab 3 answer key: Configuring firmware for wear detection

Instructor reference for the questions and optional challenges in **Lab 3** of the PSOC™ 4 Advanced CAPSENSE™ Widgets Training Manual.

All answers refer to the reference implementation in this folder:

- `capsense_wear_detect.c` / `capsense_wear_detect.h`
- `eeprom.c` / `eeprom.h`
- `power_on_wear_detect_only_main_source_file/main.c`
- `final_main_source_file/main.c`

---

## Add calibration value storage

### What is the purpose of the factory calibration values stored in EEPROM?

They provide an absolute, known-good reference captured while the device is **not** being worn.

The power-on wear decision cannot use a normal CAPSENSE™ baseline. At startup the baseline is initialized from whatever the sensor currently reads, so if the device boots while already being worn, the baseline absorbs the wear condition and the wear becomes invisible. An external, persistent anchor is required instead.

The record stores two values:

- `wear_detect_cap_fF` — the un-worn absolute capacitance of **WearSensor0**. This is the anchor the DON/DOFF thresholds are built on.
- `reference_cap_fF` — the un-worn absolute capacitance of **RefSensor0**. This is the anchor for the `RSCp-ratio`, allowing environmental drift accumulated since calibration to be divided out.

### Why are the values captured with the self-test (BIST) measurement instead of a normal CAPSENSE™ scan?

A normal scan produces **raw counts**, which are only meaningful relative to a running baseline. That baseline continuously re-centers itself, so a raw count recorded at the factory would not be comparable to one recorded months later.

`Cy_CapSense_MeasureCapacitanceSlotSensors_V3Lp()` returns the **absolute** sensor parasitic capacitance in femtofarads. An absolute measurement is independent of any baseline, so it remains directly comparable across resets, across time, and across temperature. That is the only kind of measurement that can support a decision made in the first moments after power-on.

This is also why the self-test library had to be enabled in the **CAPSENSE™ Configurator** in the earlier step.

### Why must `capsense_wear_detect_init_calibration_values()` run after `initialize_capsense()` but before the scan state machine starts?

**After `initialize_capsense()`** because the BIST APIs depend on an initialized CAPSENSE™ context and configured hardware. The generated slot IDs such as `CY_CAPSENSE_WEARDETECTSENSOR0_FIRST_SLOT_ID` are only valid once the middleware is up, and the function guards on `Cy_CapSense_IsBusy()`, which requires a valid context.

**Before the state machine** for three reasons:

- The result selects the initial application state, `WOT_MODE` or `POWER_ON_WEAR`.
- It selects which MSCLP timer is configured before entering the main loop.
- Most importantly, the normal scan loop must not be allowed to initialize the active baselines first. Doing so would bake a wear condition into the baseline and permanently destroy the evidence the startup decision depends on.

### How does the firmware decide whether to measure new values or read stored ones, and what happens on reprogramming?

The decision is made by the **USER BTN** state at startup. `capsense_wear_detect_init_calibration_values()` reconfigures the button pin as GPIO with a pull-up, waits 100 ms to settle, and reads it:

| Button at startup | Behavior |
| --- | --- |
| Pressed | Take a fresh BIST measurement of both sensors and write it with `eeprom_write_calibration()` |
| Not pressed | Read the stored record with `eeprom_read_calibration()` |

The read is accepted when the status is `CY_EM_EEPROM_SUCCESS` or `CY_EM_EEPROM_REDUNDANT_COPY_USED`, the latter meaning the primary copy was corrupted and the redundant copy was used. The record is also validated against a stored version number and checksum.

If the read fails validation, the firmware falls back to measuring the sensors live so the device still runs. Note that this fallback calibrates against whatever state the board happens to be in, so it is a graceful degradation rather than a correct calibration.

**On reprogramming:** the backing store is declared as `const uint8_t eeprom_storage[]`, which places it in application flash. Programming the device erases that region along with the rest of the application, so the calibration is lost. The trainee must recapture it after every programming step by holding the reset button and **USER BTN**, then releasing reset.

---

## Guided questions: power on wear detection

### 1. Which function calculates the `RSCp-ratio`, and why does it differ from the active-mode `Ktemp-ratio`?

`capsense_wear_detect_reference_cp_ratio()` calculates the `RSCp-ratio`. The two differ in every input:

| | `RSCp-ratio` (startup) | `Ktemp-ratio` (active mode) |
| --- | --- | --- |
| Function | `capsense_wear_detect_reference_cp_ratio()` | `capsense_wear_detect_reference_ktemp_ratio()` |
| Domain | Absolute capacitance in fF | Raw counts |
| Source of current value | BIST measurement | Live scan result |
| Source of reference value | Factory value from EEPROM | Live CAPSENSE™ baseline |
| Coefficient | `WEAR_DETECTION_TCCF_CP` | `WEAR_DETECTION_TCCF` |

The reason for two implementations is the availability of a trustworthy baseline. At power-on there is none, so the calculation must work in absolute units against the stored factory calibration. Once the device has entered active operation the baselines are established and valid, and raw counts become the natural and far cheaper domain to work in.

### 2. Why does the startup logic stay in `POWER_ON_WEAR` until the measurement clears the threshold?

Because the active baselines cannot be safely initialized while a wear condition is present.

If the firmware initialized the baselines during a wear condition, the baseline algorithm would treat the worn state as normal. The wear would never be reported, and later *removal* of the wear would appear as a large negative-going deviation. The sensor would be inverted for the rest of the session.

So the firmware parks in `POWER_ON_WEAR`, keeps taking absolute BIST measurements, and only once the compensated value clears the detection threshold does it call `capsense_wear_detect_initialize_active_baselines_after_scan()` and transition to `ACTIVE_MODE`. This guarantees the baseline is always established from a known un-worn state.

### 3. What happens if the reference sensor drifts but the wear sensor does not?

The `RSCp-ratio` moves away from 1.0 and scales the wear sensor's absolute capacitance so the common-mode drift is divided out. No false DON is produced.

This works because both electrodes sit on the same board and stackup and therefore see the same ambient temperature and humidity. The reference is a live proxy for the common-mode component of the measurement. Compensating against a *measured* reference is more robust than assuming a fixed drift coefficient, because it adapts to the actual conditions and to per-unit variation.

The limitation worth drawing out in discussion: the compensation assumes the reference only ever sees common-mode change. If something couples to the reference electrode specifically, the correction misfires and corrupts a perfectly good wear measurement. That is exactly the failure mode the **CSB2** disturbance in *Optional challenge: measure the compensation* demonstrates.

### 4. Why does the Tuner show adjusted capacitance, baseline capacitance, and diff count instead of raw uncorrected values?

During `POWER_ON_WEAR` the normal scan and processing pipeline is not running at all. The firmware is performing BIST absolute measurements, so the Tuner data structures would otherwise contain stale or meaningless values.

The module therefore populates them directly, writing `..._RAW0_VALUE`, `..._BSLN0_VALUE`, `..._DIFF0_VALUE`, and `..._STATUS0_VALUE` for both widgets and incrementing `cy_capsense_tuner.commonContext.scanCounter` so the Tuner recognizes fresh data.

The three values are chosen to mirror the comparison the firmware is actually making:

- **Adjusted capacitance** is the compensated number the decision is made on.
- **Baseline capacitance** is the stored factory calibration value it is compared against.
- **Diff count** is the amount by which the threshold was exceeded.

Displaying the uncorrected raw measurement would hide the compensation entirely and would not correspond to the comparison being performed, making the observed DON/DOFF behavior look arbitrary.

---

## Optional challenge: power-on wear decision

Expected trends. Exact fF values vary by board, electrode, and finger coupling, so focus on the direction of the change and the reasoning behind it rather than on specific numbers. The transitions are far easier to follow with the **CAPSENSE™ Tuner** streaming, since `POWER_ON_WEAR` publishes the adjusted capacitance, calibration baseline, and difference count directly.

| Trial | Parameter | Change to try | What to observe | Expected behavior |
| --- | --- | --- | --- | --- |
| 1 | `WEAR_DETECTION_TCCF_CP` | Set to `0.0f` | DON at reset, then the DOFF transition | `RSCp-ratio` is pinned to 1.0, so no reference compensation is applied and the decision follows the measured wear Cp directly. Any reference shift accumulated since calibration now passes straight through into the decision. With the reference undisturbed this looks almost identical to the default, which is itself the lesson: the coefficient only ever acts on a reference *deviation*. |
| 2 | `WEAR_DETECTION_TCCF_CP` | Set to `-1.0f` | DON at reset, then the DOFF transition | Four times the default correction. A 1 % rise in reference Cp now scales the wear capacitance down by a full 1 %. With any meaningful reference deviation this over-corrects heavily and can pull the adjusted value below the DON threshold, so a genuine wear condition fails to latch at reset. Too much compensation is as damaging as none. |
| 3 | `WEAR_DETECTION_THRESHOLD_MARGIN_FF` | Increase in steps | The value at which DON stops being detected | The DON threshold is `cal + margin * (1 + ratio)`, which at the default ratio is `cal + margin * 1.10`. DON stops latching once that threshold exceeds the capacitance a finger actually adds to **CSB1**. The value found is effectively a direct measurement of the wear signal magnitude on this electrode, and it is board- and finger-dependent. A usable margin sits well below that number but above normal ambient variation. |
| 4 | `WEAR_DETECTION_HYSTERESIS_RATIO` | Increase in steps | How much of the wear must be removed before clearing to DOFF | The DOFF threshold is `cal + margin * (1 - ratio)`. Raising the ratio lowers it, so the adjusted capacitance must fall further before the condition clears. At `1.0f` the threshold collapses onto `cal` itself, and above that it drops below `cal`. Since the un-worn adjusted capacitance sits at roughly `cal`, the device then never clears: it stays latched in `POWER_ON_WEAR` with the LED on even with nothing near the electrode. |

Key points worth drawing out in the discussion:

- The two `WEAR_DETECTION_TCCF_CP` trials only show a visible effect if the **RefSensor0** capacitance at reset differs from the value stored during calibration. Because the calibration is recaptured immediately after programming, `ref_current` is normally very close to `ref_cal`, the `RSCp-ratio` sits at roughly 1.0, and the coefficient has almost nothing to act on. To make these trials meaningful, the reference electrode must be in a different state at reset than it was at calibration, for example by holding a hand near **CSB2** through the reset.
- The margin and the hysteresis are **not** independent. Because `hysteresis = WEAR_DETECTION_THRESHOLD_MARGIN_FF * WEAR_DETECTION_HYSTERESIS_RATIO`, changing the margin shifts both decision points *and* rescales their separation. Only the ratio changes the separation on its own.
- `POWER_ON_WEAR` is entered only at startup and never re-entered, so each reset yields exactly one DON decision and one DOFF transition. There is no oscillation to observe.
- A hysteresis ratio of `1.0f` or greater is a hard failure point rather than just an aggressive setting. The DOFF threshold falls to or below the calibration value, which the un-worn sensor never goes below, so the device latches in `POWER_ON_WEAR` permanently. Trainees who increase the ratio far enough will find this, and it is worth confirming they understand *why* rather than assuming the board has hung.
- The calibration must be recaptured after each reprogramming, otherwise the trial is measured against an invalid or fallback baseline and the results are meaningless.

---

## Guided questions: temperature reference compensation

### 1. Why is `WEAR_DETECTION_TCCF` negative? What if it were positive?

Because the correction must oppose the drift, not follow it.

The reference and wear sensors drift in the **same** direction under a shared environmental change. When the reference raw count rises above its baseline, the wear sensor's deviation has been inflated by that same effect. To cancel it, the wear deviation must be scaled **down**, which requires a ratio below 1.0:

$$
\mathrm{Ktemp\text{-}ratio} = 1.0 + \mathrm{tccf} \times \frac{\mathrm{ref\_raw} - \mathrm{ref\_bsln}}{\mathrm{ref\_bsln}}
$$

With a positive reference deviation, only a negative `tccf` produces a ratio below 1.0.

If `tccf` were positive, the ratio would exceed 1.0 and the firmware would **amplify** the very drift it is supposed to remove, roughly doubling the error instead of cancelling it. The `+0.25f` trial in *Optional challenge: measure the compensation* demonstrates this directly.

### 2. Why does the compensation multiply the wear sensor's deviation `(raw - baseline)` by a ratio built from the reference sensor's own deviation, rather than multiplying the two raw counts directly?

The wear raw count *is* the value being adjusted. `CY_CAPSENSE_WEARDETECTSENSOR0_SNS0_RAW0_VALUE` is overwritten with the compensated result, and everything downstream consumes it. The question is about which quantities the arithmetic operates on. Expanding the ratio shows that **both** sensors contribute a deviation, not a raw count:

$$
\mathrm{Adjusted\ Raw} = \mathrm{bsln} + (\mathrm{raw} - \mathrm{bsln}) \times \left( 1.0 + \mathrm{tccf} \times \frac{\mathrm{ref\_raw} - \mathrm{ref\_bsln}}{\mathrm{ref\_bsln}} \right)
$$

Each deviation is there for a different reason.

**The wear sensor's deviation, `raw - bsln`.** Only this term carries signal and drift. The baseline is a large DC operating point, typically tens of thousands of counts, representing the sensor's resting state, and it must stay fixed. Multiplying the raw count directly would scale that entire DC value: a ratio of 0.99 applied to a raw count of 30000 shifts the result by 300 counts of pure artifact, dwarfing the real signal and quickly saturating or zeroing the sensor.

**The reference sensor's deviation, `(ref_raw - ref_bsln) / ref_bsln`.** This is divided by the reference baseline, making it a dimensionless *fractional* change rather than an absolute count. That is what allows `tccf` to be a single unitless coefficient: it does not have to be re-derived for the absolute count magnitude of either sensor, and it stays valid if the two sensors have very different raw count ranges. Feeding in `ref_raw` directly would produce an enormous, meaningless ratio.

Working in deviations also gives the correct degenerate behavior at both ends. If the reference has not moved, the fraction is zero, the ratio is exactly 1.0, and the wear raw count passes through untouched for any coefficient. If the wear sensor is at rest, `raw - bsln` is zero and the correction term vanishes regardless of what the reference is doing. Neither sensor can perturb the result unless there is something real to correct.

**A point trainees reliably trip over.** The application note writes the same correction as equation (2):

$$
\mathrm{Adjusted\ SensRC} = \mathrm{SensDiffCnt} \times \mathrm{Ktemp\text{-}ratio}
$$

That form has no baseline term, which makes the firmware look wrong by comparison. It is not. Equation (2) operates in the **difference-count** domain: `SensDiffCnt` is already `raw - bsln`, so it consumes a difference count and returns a difference count. The firmware operates in the **raw-count** domain, because the correction is injected before the baseline and difference-count stages have run, so no difference count exists yet. It must hand back a raw count, which means adding the baseline again after scaling.

Both express the same correction. If a trainee proposes removing the `bsln` term to match the application note, the consequence is worth working through: a raw count of tens of thousands would be replaced by a difference of a few hundred, and the baseline algorithm would interpret that as the signal collapsing.

### 3. Why a multiplicative ratio instead of a fixed offset?

Because the magnitude of environmental drift scales with the sensor's own signal magnitude. The same temperature change produces a proportionally larger count shift on a sensor with larger raw counts or higher Cp.

A fixed offset would only be correct at exactly one operating point, one temperature, and one unit's parasitic capacitance. It would under-correct in some conditions and over-correct in others, and it would need re-deriving for every design change.

A ratio derived from the *measured* reference deviation self-scales with the actual conditions, with the severity of the drift, and with unit-to-unit variation, using a single dimensionless coefficient.

### 4. Why must `process_active_widgets_with_ktemp()` replace `Cy_CapSense_ProcessAllWidgets()` rather than run alongside it?

Because the compensation has to be injected **into the middle** of the processing pipeline, and `Cy_CapSense_ProcessAllWidgets()` runs that pipeline end to end in a single call.

The correction must happen after filtering, so it operates on a clean raw value, but before baseline update, difference counts, and status, so those are all derived from the compensated number. The module therefore decomposes the pipeline:

1. `Cy_CapSense_PreProcessWidget()` for both widgets.
2. `Cy_CapSense_ProcessSensorExt(..., CY_CAPSENSE_PROCESS_FILTER, ...)` for both.
3. Apply `Ktemp-ratio` to the wear sensor's raw count and clamp it.
4. `Cy_CapSense_ProcessSensorExt(..., CY_CAPSENSE_PROCESS_BASELINE | CY_CAPSENSE_PROCESS_DIFFCOUNTS, ...)`.
5. `Cy_CapSense_ProcessWidgetExt(..., CY_CAPSENSE_PROCESS_STATUS, ...)`.

Leaving `Cy_CapSense_ProcessAllWidgets()` in place would compute baseline, difference counts, and widget status from the **uncompensated** raw count. The later correction would arrive too late to influence any of them: the reported status would be wrong, and the baseline would have already absorbed uncompensated drift, carrying the error forward into subsequent scans. Running both would additionally process every widget twice.

### 5. Why is the adjusted raw count clamped before baseline and difference counts are processed?

`adjusted_raw` is computed as a `float`, but the raw count field is a `uint16_t`. A large reference deviation combined with a large coefficient can drive the result below zero or above `CY_CAPSENSE_WEARDETECTSENSOR0_MAX_RAW_COUNT_VALUE`.

Writing an out-of-range value back would wrap or truncate in the `uint16_t` conversion, turning a small negative number into a very large positive raw count. The baseline and difference-count algorithms would then consume that corrupted value and propagate it, poisoning the baseline for many subsequent scans.

Clamping first keeps the value physically meaningful and bounded before any downstream stage observes it.

---

## Optional challenge: measure the compensation

Expected results. Absolute counts depend on the board and on how strongly the reference electrode is disturbed, so focus on the ratios and the direction of the change rather than on absolute values.

| Trial | `WEAR_DETECTION_TCCF` | Change from default | Expected behavior |
| --- | --- | --- | --- |
| 1 | `0.0f` | Remove compensation entirely | `Ktemp-ratio` is exactly 1.0, so `adjusted = bsln + (raw - bsln) = raw`. No compensation at all. The wear raw count moves by the full uncompensated amount. This is the control measurement every other trial is compared against. |
| 2 | `-0.10f` | Reduce magnitude | Roughly 40 % of the default correction. Part of the disturbance is removed. |
| 3 | `-0.25f` | Project default, no change | Most of the reference-induced movement is removed. |
| 4 | `-0.50f` | Increase magnitude | Twice the default correction. Can visibly over-correct, pushing the wear raw count in the opposite direction from the disturbance. |
| 5 | `+0.25f` | Invert the sign | Wrong sign. The disturbance is amplified by about the same magnitude the default would have removed. |

### With `0.0f`, how much does the wear raw count move when only the reference is disturbed?

It moves by the entire uncompensated amount of cross-coupling and shared environmental response. This is the baseline error the compensation exists to remove, and every other trial should be quoted as a fraction of it.

### How does the change scale with the magnitude of the coefficient?

Linearly, in both the coefficient and the reference deviation. The correction applied to the deviation is:

$$
(\mathrm{raw} - \mathrm{bsln}) \times \mathrm{tccf} \times \frac{\mathrm{ref\_raw} - \mathrm{ref\_bsln}}{\mathrm{ref\_bsln}}
$$

Doubling `tccf` from `-0.25f` to `-0.50f` doubles the correction. Doubling the reference deviation does the same. Trainees should be able to predict the `-0.50f` result from the `-0.25f` measurement before running it, then confirm the measurement matches.

### With the sign inverted, is the disturbance cancelled or amplified?

Amplified. Disturbing the reference electrode drives `ref_raw` above `ref_bsln`, making the deviation positive. With `tccf = +0.25f` the ratio becomes greater than 1.0, so the wear sensor's deviation is scaled **up** and moves further in the same direction as the disturbance.

This confirms the sign rule from the first question: the coefficient must oppose the direction of the common-mode shift. The magnitude sets *how much* is corrected; the sign decides whether you are correcting at all or making it worse.

> **Note:** If a trial shows no change for any coefficient, the reference deviation was zero. When `ref_raw == ref_bsln` the ratio is exactly 1.0 and the raw count passes through untouched regardless of `tccf`. The reference electrode must be disturbed while the measurement is recorded.
