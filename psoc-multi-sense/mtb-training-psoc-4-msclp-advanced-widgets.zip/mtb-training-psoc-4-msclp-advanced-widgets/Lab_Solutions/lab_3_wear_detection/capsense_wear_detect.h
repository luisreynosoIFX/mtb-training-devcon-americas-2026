/******************************************************************************
 * File: capsense_wear_detect.h
 * Description: Reusable wear-detection and temperature-compensation helpers.
 ******************************************************************************/

#ifndef CAPSENSE_WEAR_DETECT_H
#define CAPSENSE_WEAR_DETECT_H

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
* MACROS
*******************************************************************************/

/* tccf_cp in equation (3) of AN241228: power-on RSCp-ratio compensation factor */
#define WEAR_DETECTION_TCCF_CP          (-0.25f)

/* fF added to the calibrated wear capacitance to set the power-on DON threshold */
#define WEAR_DETECTION_THRESHOLD_MARGIN_FF (100.0f)

/* Fraction of the margin used as +/- hysteresis around the DON/DOFF threshold */
#define WEAR_DETECTION_HYSTERESIS_RATIO (0.10f)

/* tccf in equation (1) of AN241228: active-mode Ktemp-ratio compensation factor */
#define WEAR_DETECTION_TCCF             (-0.25f)

/* Widget status value reported by CAPSENSE for a touch (wear) condition */
#define WEAR_DETECT_TOUCH_STATE         (3u)

/* Widget status value reported by CAPSENSE for a proximity condition */
#define WEAR_DETECT_PROX_STATE          (1u)

/*******************************************************************************
* Function Prototypes
*******************************************************************************/

bool capsense_wear_detect_measure_active_sensor_capacitance(
        uint32_t *wear_detect_cap_fF,
        uint32_t *reference_cap_fF);

bool capsense_wear_detect_init_calibration_values(
        uint32_t *wear_detect_cap_fF,
        uint32_t *reference_cap_fF);

float capsense_wear_detect_reference_cp_ratio(
        uint32_t reference_sns_current_cap_fF,
        uint32_t reference_cap_fF);

float capsense_wear_detect_adjusted_wear_capacitance(
        uint32_t wear_sns_current_cap_fF,
        float reference_ratio);

bool capsense_wear_detect_is_wear_detected(
        float adjusted_wear_cap_fF,
        uint32_t wear_detect_cap_fF,
        bool wear_detected);

uint16_t capsense_wear_detect_clamp_to_tuner_value(uint32_t capacitance_fF);

void capsense_wear_detect_initialize_active_baselines_after_scan(void);

bool capsense_wear_detect_power_on_wear_detection(
        uint32_t wear_detect_cap_fF,
        uint32_t reference_cap_fF,
        bool *wear_detected);

float capsense_wear_detect_reference_ktemp_ratio(void);

void capsense_wear_detect_process_active_widgets_with_ktemp(void);

#ifdef __cplusplus
}
#endif

#endif
