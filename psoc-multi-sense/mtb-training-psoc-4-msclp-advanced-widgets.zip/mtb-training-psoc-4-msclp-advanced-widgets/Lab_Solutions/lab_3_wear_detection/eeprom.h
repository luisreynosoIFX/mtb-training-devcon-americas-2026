/******************************************************************************
 * File: eeprom.h
 * Description: Persistent CAPSENSE calibration record storage.
 ******************************************************************************/

#ifndef EEPROM_H
#define EEPROM_H

#include <stdbool.h>
#include <stdint.h>

#include "cy_pdl.h"
#include "cy_em_eeprom.h"

/*******************************************************************************
* MACROS
*******************************************************************************/

/* Bumped whenever the stored record layout changes, to reject stale records */
#define CAPSENSE_CALIBRATION_VERSION (1u)

typedef struct
{
    uint16_t version;
    uint32_t wear_detect_cap_fF;
    uint32_t reference_cap_fF;
    uint32_t checksum;
} capsense_calibration_record_t;

/*******************************************************************************
* Function Prototypes
*******************************************************************************/

cy_en_em_eeprom_status_t eeprom_initialize(void);

cy_en_em_eeprom_status_t eeprom_write_calibration(
        uint32_t wear_detect_cap_fF,
        uint32_t reference_cap_fF);

cy_en_em_eeprom_status_t eeprom_read_calibration(
        capsense_calibration_record_t *record);

#endif