/******************************************************************************
 * File: capsense_wear_detect.c
 * Description: Reusable wear-detection and temperature-compensation helpers.
 ******************************************************************************/

#include "capsense_wear_detect.h"

#include "cy_pdl.h"
#include "cycfg_capsense.h"
#include "cybsp.h"
#include "eeprom.h"

/*******************************************************************************
* Global variables
*******************************************************************************/

static uint16_t ktemp_baseline_cached;
static float ktemp_inv_baseline;

/*******************************************************************************
* Functions
*******************************************************************************/

/**
 * @brief Measures the absolute parasitic capacitance (Cp) of the wear-detection
 * and reference sensors using the CAPSENSE&trade; self-test (BIST) API.
 *
 * @param[out] wear_detect_cap_fF Measured WearDetectSensor0 capacitance, in fF.
 * @param[out] reference_cap_fF Measured RefSensor0 capacitance, in fF.
 *
 * @return true if both BIST measurements completed successfully.
 *
 * @note Supplies the WearSensCap and ref_cp_value terms used in equations (3)
 * and (4) of AN241228, "Wear Detection with PSOC&trade; 4 CAPSENSE&trade;".
 */
bool capsense_wear_detect_measure_active_sensor_capacitance(
        uint32_t *wear_detect_cap_fF,
        uint32_t *reference_cap_fF)
{
    cy_en_capsense_bist_status_t status;

    if (Cy_CapSense_IsBusy(&cy_capsense_context))
    {
        return false;
    }

    status = Cy_CapSense_MeasureCapacitanceSlotSensors_V3Lp(
        CY_CAPSENSE_WEARDETECTSENSOR0_FIRST_SLOT_ID,
        0u,
        &cy_capsense_context);
    if (status != CY_CAPSENSE_BIST_SUCCESS_E)
    {
        return false;
    }
    *wear_detect_cap_fF = CY_CAPSENSE_BIST_WEARDETECTSENSOR0_ROW0_COL0_SNS_CAP_VALUE;

    if (Cy_CapSense_IsBusy(&cy_capsense_context))
    {
        return false;
    }

    status = Cy_CapSense_MeasureCapacitanceSlotSensors_V3Lp(
        CY_CAPSENSE_REFSENSOR0_FIRST_SLOT_ID,
        0u,
        &cy_capsense_context);
    if (status != CY_CAPSENSE_BIST_SUCCESS_E)
    {
        return false;
    }
    *reference_cap_fF = CY_CAPSENSE_BIST_REFSENSOR0_ROW0_COL0_SNS_CAP_VALUE;

    return true;
}

/**
 * @brief Loads or captures the factory-calibration capacitance values that
 * anchor the power-on wear decision.
 *
 * @param[out] wear_detect_cap_fF Un-worn WearDetectSensor0 capacitance, in fF.
 * @param[out] reference_cap_fF Un-worn RefSensor0 capacitance, in fF.
 *
 * @return true if a valid calibration record was obtained, either measured
 * live or read back from EEPROM.
 *
 * @note Supplies the ref_base_cp_val reference term used in equation (3) of
 * AN241228.
 */
bool capsense_wear_detect_init_calibration_values(
        uint32_t *wear_detect_cap_fF,
        uint32_t *reference_cap_fF)
{
    Cy_GPIO_SetHSIOM(CYBSP_USER_BTN_PORT, CYBSP_USER_BTN_PIN, HSIOM_SEL_GPIO);
    Cy_GPIO_SetDrivemode(CYBSP_USER_BTN_PORT, CYBSP_USER_BTN_PIN, CY_GPIO_DM_PULLUP);
    Cy_SysLib_Delay(100);

    bool button_pressed = (Cy_GPIO_Read(CYBSP_USER_BTN_PORT, CYBSP_USER_BTN_PIN) == CYBSP_BTN_PRESSED);

    if (eeprom_initialize() != CY_EM_EEPROM_SUCCESS)
    {
        return false;
    }

    if (button_pressed)
    {
        uint32_t wear_detect_cap_fF_new;
        uint32_t reference_cap_fF_new;

        if (!capsense_wear_detect_measure_active_sensor_capacitance(
                &wear_detect_cap_fF_new,
                &reference_cap_fF_new))
        {
            return false;
        }

        if (eeprom_write_calibration(wear_detect_cap_fF_new, reference_cap_fF_new) !=
            CY_EM_EEPROM_SUCCESS)
        {
            return false;
        }

        *wear_detect_cap_fF = wear_detect_cap_fF_new;
        *reference_cap_fF = reference_cap_fF_new;
    }
    else
    {
        cy_en_em_eeprom_status_t eeprom_status;
        capsense_calibration_record_t record;

        eeprom_status = eeprom_read_calibration(&record);
        if ((eeprom_status != CY_EM_EEPROM_SUCCESS) &&
            (eeprom_status != CY_EM_EEPROM_REDUNDANT_COPY_USED))
        {
            return capsense_wear_detect_measure_active_sensor_capacitance(
                    wear_detect_cap_fF,
                    reference_cap_fF);
        }

        *wear_detect_cap_fF = record.wear_detect_cap_fF;
        *reference_cap_fF = record.reference_cap_fF;
    }

    return true;
}

/**
 * @brief Calculates the reference-sensor capacitance compensation ratio used
 * to correct the power-on wear decision for temperature and common-mode drift.
 *
 * @param reference_sns_current_cap_fF Current RefSensor0 capacitance, in fF
 * (ref_cp_value).
 * @param reference_cap_fF Factory-calibrated RefSensor0 capacitance, in fF
 * (ref_base_cp_val).
 *
 * @return The RSCp-ratio.
 *
 * @note Implements equation (3) of AN241228:
 * RSCp-ratio = 1.0 + tccf_cp * (ref_cp_value - ref_base_cp_val) / ref_base_cp_val.
 */
float capsense_wear_detect_reference_cp_ratio(
        uint32_t reference_sns_current_cap_fF,
        uint32_t reference_cap_fF)
{
    return 1.0f + (WEAR_DETECTION_TCCF_CP *
            ((float)reference_sns_current_cap_fF - (float)reference_cap_fF) /
            (float)reference_cap_fF);
}

/**
 * @brief Applies the RSCp-ratio to compensate the wear sensor's measured
 * capacitance.
 *
 * @param wear_sns_current_cap_fF Current WearDetectSensor0 capacitance, in fF
 * (WearSensCap).
 * @param reference_ratio RSCp-ratio returned by
 * capsense_wear_detect_reference_cp_ratio().
 *
 * @return The compensated wear-sensor capacitance, in fF.
 *
 * @note Implements equation (4) of AN241228:
 * Adjusted WearSensCap = WearSensCap * RSCp-ratio.
 */
float capsense_wear_detect_adjusted_wear_capacitance(
        uint32_t wear_sns_current_cap_fF,
        float reference_ratio)
{
    return (float)wear_sns_current_cap_fF * reference_ratio;
}

/**
 * @brief Compares the compensated wear-sensor capacitance against the
 * calibrated threshold, with hysteresis, to make the DON/DOFF decision.
 *
 * @param adjusted_wear_cap_fF Compensated wear capacitance from
 * capsense_wear_detect_adjusted_wear_capacitance(), in fF.
 * @param wear_detect_cap_fF Factory-calibrated, un-worn WearDetectSensor0
 * capacitance, in fF.
 * @param wear_detected Current wear state, selects the DON or DOFF threshold.
 *
 * @return true if wear (DON) is detected, false otherwise (DOFF).
 *
 * @note Applies the power-on wear threshold and hysteresis margin described in
 * the "Power on wear detection" section of AN241228 to the capacitance
 * compensated by equation (4).
 */
bool capsense_wear_detect_is_wear_detected(
        float adjusted_wear_cap_fF,
        uint32_t wear_detect_cap_fF,
        bool wear_detected)
{
    float finger_threshold = (float)wear_detect_cap_fF +
        WEAR_DETECTION_THRESHOLD_MARGIN_FF;
    float hysteresis = WEAR_DETECTION_THRESHOLD_MARGIN_FF *
        WEAR_DETECTION_HYSTERESIS_RATIO;

    if (wear_detected)
    {
        return (adjusted_wear_cap_fF > (finger_threshold - hysteresis));
    }

    return (adjusted_wear_cap_fF > (finger_threshold + hysteresis));
}

/**
 * @brief Saturates a 32-bit capacitance/count value to the 16-bit range used
 * by the CAPSENSE&trade; Tuner raw/baseline/diff fields.
 *
 * @param capacitance_fF Value to clamp.
 *
 * @return capacitance_fF clamped to the range [0, 0xFFFF].
 */
uint16_t capsense_wear_detect_clamp_to_tuner_value(uint32_t capacitance_fF)
{
    return (capacitance_fF > 0xFFFFu) ? 0xFFFFu : (uint16_t)capacitance_fF;
}

/**
 * @brief Scans all slots and (re)initializes the WearDetectSensor0 and
 * RefSensor0 baselines from a confirmed un-worn state.
 *
 * @note Must only be called once the power-on wear decision has cleared to
 * DOFF. AN241228 notes that the active-mode baseline must never be
 * established while a wear condition is present, or the wear condition is
 * absorbed into the baseline and becomes undetectable.
 */
void capsense_wear_detect_initialize_active_baselines_after_scan(void)
{
    uint32_t interrupt_status;

    Cy_CapSense_ScanAllSlots(&cy_capsense_context);
    interrupt_status = Cy_SysLib_EnterCriticalSection();

    while (Cy_CapSense_IsBusy(&cy_capsense_context))
    {
        Cy_SysPm_CpuEnterSleep();
        Cy_SysLib_ExitCriticalSection(interrupt_status);
        interrupt_status = Cy_SysLib_EnterCriticalSection();
    }

    Cy_SysLib_ExitCriticalSection(interrupt_status);

    Cy_CapSense_InitializeWidgetBaseline(
            CY_CAPSENSE_WEARDETECTSENSOR0_WDGT_ID,
            &cy_capsense_context);
    Cy_CapSense_InitializeWidgetBaseline(
            CY_CAPSENSE_REFSENSOR0_WDGT_ID,
            &cy_capsense_context);
}

/**
 * @brief Performs one power-on wear-decision cycle: measures both sensors,
 * compensates the wear capacitance, evaluates DON/DOFF, and publishes the
 * result to the CAPSENSE&trade; Tuner.
 *
 * @param wear_detect_cap_fF Factory-calibrated, un-worn WearDetectSensor0
 * capacitance, in fF.
 * @param reference_cap_fF Factory-calibrated RefSensor0 capacitance, in fF
 * (ref_base_cp_val).
 * @param[in,out] wear_detected Current wear state on entry, updated DON/DOFF
 * result on return.
 *
 * @return true if the measurement and decision completed successfully.
 *
 * @note Chains equations (3) and (4) of AN241228 -
 * capsense_wear_detect_reference_cp_ratio() then
 * capsense_wear_detect_adjusted_wear_capacitance() - before applying the
 * threshold in capsense_wear_detect_is_wear_detected().
 */
bool capsense_wear_detect_power_on_wear_detection(
        uint32_t wear_detect_cap_fF,
        uint32_t reference_cap_fF,
        bool *wear_detected)
{
    uint32_t wear_sns_current_cap_fF;
    uint32_t reference_sns_current_cap_fF;
    float adjusted_wear_cap_fF;

    if ((wear_detected == NULL) || (reference_cap_fF == 0u))
    {
        return false;
    }

    if (!capsense_wear_detect_measure_active_sensor_capacitance(
            &wear_sns_current_cap_fF,
            &reference_sns_current_cap_fF))
    {
        return false;
    }

    adjusted_wear_cap_fF = capsense_wear_detect_adjusted_wear_capacitance(
            wear_sns_current_cap_fF,
            capsense_wear_detect_reference_cp_ratio(
                reference_sns_current_cap_fF,
                reference_cap_fF));

    *wear_detected = capsense_wear_detect_is_wear_detected(
            adjusted_wear_cap_fF,
            wear_detect_cap_fF,
            *wear_detected);

    CY_CAPSENSE_WEARDETECTSENSOR0_SNS0_RAW0_VALUE =
        (adjusted_wear_cap_fF > 0.0f)
            ? capsense_wear_detect_clamp_to_tuner_value((uint32_t)adjusted_wear_cap_fF)
            : 0u;
    CY_CAPSENSE_WEARDETECTSENSOR0_SNS0_BSLN0_VALUE =
        capsense_wear_detect_clamp_to_tuner_value(wear_detect_cap_fF);
    CY_CAPSENSE_WEARDETECTSENSOR0_SNS0_DIFF0_VALUE =
        (adjusted_wear_cap_fF > (float)wear_detect_cap_fF)
            ? capsense_wear_detect_clamp_to_tuner_value(
                  (uint32_t)(adjusted_wear_cap_fF - (float)wear_detect_cap_fF))
            : 0u;
    CY_CAPSENSE_WEARDETECTSENSOR0_SNS0_STATUS0_VALUE =
        (*wear_detected) ? WEAR_DETECT_TOUCH_STATE : 0u;

    CY_CAPSENSE_REFSENSOR0_SNS0_RAW0_VALUE =
        capsense_wear_detect_clamp_to_tuner_value(reference_sns_current_cap_fF);
    CY_CAPSENSE_REFSENSOR0_SNS0_BSLN0_VALUE =
        capsense_wear_detect_clamp_to_tuner_value(reference_cap_fF);
    CY_CAPSENSE_REFSENSOR0_SNS0_DIFF0_VALUE =
        (reference_sns_current_cap_fF > reference_cap_fF)
            ? capsense_wear_detect_clamp_to_tuner_value(reference_sns_current_cap_fF - reference_cap_fF)
            : 0u;

    cy_capsense_tuner.commonContext.scanCounter++;

    return true;
}

/**
 * @brief Calculates the active-mode temperature/common-mode compensation
 * ratio from the reference sensor's raw-count deviation.
 *
 * @return The Ktemp-ratio.
 *
 * @note Implements equation (1) of AN241228:
 * Ktemp-ratio = 1.0 + tccf * (ref_rawcounts - ref_bsln) / ref_bsln.
 */
float capsense_wear_detect_reference_ktemp_ratio(void)
{
    uint16_t reference_baseline = CY_CAPSENSE_REFSENSOR0_SNS0_BSLN0_VALUE;

    if (reference_baseline == 0u)
    {
        return 1.0f;
    }

    if (reference_baseline != ktemp_baseline_cached)
    {
        ktemp_baseline_cached = reference_baseline;
        ktemp_inv_baseline = 1.0f / (float)reference_baseline;
    }

    return 1.0f + (WEAR_DETECTION_TCCF *
            ((float)CY_CAPSENSE_REFSENSOR0_SNS0_RAW0_VALUE -
             (float)reference_baseline) * ktemp_inv_baseline);
}

/**
 * @brief Replaces Cy_CapSense_ProcessAllWidgets() for the wear-detection and
 * reference widgets, injecting the Ktemp-ratio compensation between the
 * filter and baseline/diff-count processing stages.
 *
 * @note Equation (2) of AN241228 defines the correction in the
 * difference-count domain: Adjusted SensRC = SensDiffCnt * Ktemp-ratio. This
 * function runs before the difference count is calculated, so it applies the
 * equivalent raw-count form instead:
 * Adjusted Raw = bsln + (raw - bsln) * Ktemp-ratio.
 */
void capsense_wear_detect_process_active_widgets_with_ktemp(void)
{
    float ktemp_ratio;
    float adjusted_raw;
    uint16_t wear_baseline;
    uint16_t max_raw_count;

    Cy_CapSense_PreProcessWidget(
            CY_CAPSENSE_WEARDETECTSENSOR0_WDGT_ID, &cy_capsense_context);
    Cy_CapSense_PreProcessWidget(
            CY_CAPSENSE_REFSENSOR0_WDGT_ID, &cy_capsense_context);

    (void)Cy_CapSense_ProcessSensorExt(
            CY_CAPSENSE_WEARDETECTSENSOR0_WDGT_ID,
            CY_CAPSENSE_WEARDETECTSENSOR0_SNS0_ID,
            CY_CAPSENSE_PROCESS_FILTER,
            &cy_capsense_context);
    (void)Cy_CapSense_ProcessSensorExt(
            CY_CAPSENSE_REFSENSOR0_WDGT_ID,
            CY_CAPSENSE_REFSENSOR0_SNS0_ID,
            CY_CAPSENSE_PROCESS_FILTER,
            &cy_capsense_context);

    ktemp_ratio = capsense_wear_detect_reference_ktemp_ratio();

    wear_baseline = CY_CAPSENSE_WEARDETECTSENSOR0_SNS0_BSLN0_VALUE;
    max_raw_count = CY_CAPSENSE_WEARDETECTSENSOR0_MAX_RAW_COUNT_VALUE;
    adjusted_raw = (float)wear_baseline +
            (((float)CY_CAPSENSE_WEARDETECTSENSOR0_SNS0_RAW0_VALUE -
              (float)wear_baseline) * ktemp_ratio);

    if (adjusted_raw < 0.0f)
    {
        CY_CAPSENSE_WEARDETECTSENSOR0_SNS0_RAW0_VALUE = 0u;
    }
    else if (adjusted_raw > (float)max_raw_count)
    {
        CY_CAPSENSE_WEARDETECTSENSOR0_SNS0_RAW0_VALUE = max_raw_count;
    }
    else
    {
        CY_CAPSENSE_WEARDETECTSENSOR0_SNS0_RAW0_VALUE = (uint16_t)adjusted_raw;
    }

    (void)Cy_CapSense_ProcessSensorExt(
            CY_CAPSENSE_WEARDETECTSENSOR0_WDGT_ID,
            CY_CAPSENSE_WEARDETECTSENSOR0_SNS0_ID,
            CY_CAPSENSE_PROCESS_BASELINE | CY_CAPSENSE_PROCESS_DIFFCOUNTS,
            &cy_capsense_context);
    (void)Cy_CapSense_ProcessSensorExt(
            CY_CAPSENSE_REFSENSOR0_WDGT_ID,
            CY_CAPSENSE_REFSENSOR0_SNS0_ID,
            CY_CAPSENSE_PROCESS_BASELINE | CY_CAPSENSE_PROCESS_DIFFCOUNTS,
            &cy_capsense_context);

    (void)Cy_CapSense_ProcessWidgetExt(
            CY_CAPSENSE_WEARDETECTSENSOR0_WDGT_ID,
            CY_CAPSENSE_PROCESS_STATUS,
            &cy_capsense_context);
    (void)Cy_CapSense_ProcessWidgetExt(
            CY_CAPSENSE_REFSENSOR0_WDGT_ID,
            CY_CAPSENSE_PROCESS_STATUS,
            &cy_capsense_context);
}
