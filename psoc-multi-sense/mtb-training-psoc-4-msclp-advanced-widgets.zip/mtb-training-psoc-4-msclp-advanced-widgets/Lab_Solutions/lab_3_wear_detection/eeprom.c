/******************************************************************************
 * File: eeprom.c
 * Description: Persistent CAPSENSE calibration record storage.
 ******************************************************************************/

#include "eeprom.h"

#include "cy_utils.h"

/*******************************************************************************
* MACROS
*******************************************************************************/

#define EEPROM_DATA_SIZE       (sizeof(capsense_calibration_record_t))

/* emEEPROM simple mode disabled, so wear leveling and redundant copy apply */
#define EEPROM_SIMPLE_MODE     (0u)

/* Number of flash rows the record is rotated across to limit write wear */
#define EEPROM_WEAR_LEVELING   (2u)

/* Store a redundant copy of the record to survive a corrupted primary copy */
#define EEPROM_REDUNDANT_COPY  (1u)

/* Cy_Em_EEPROM_Write() blocks until the flash write completes */
#define EEPROM_BLOCKING_WRITE  (1u)

/* Logical emEEPROM address of the single calibration record */
#define EEPROM_RECORD_ADDRESS  (0u)

/*******************************************************************************
* Global variables
*******************************************************************************/

CY_ALIGN(CY_EM_EEPROM_FLASH_SIZEOF_ROW)
const uint8_t eeprom_storage[CY_EM_EEPROM_GET_PHYSICAL_SIZE(
        EEPROM_DATA_SIZE,
        EEPROM_SIMPLE_MODE,
        EEPROM_WEAR_LEVELING,
        EEPROM_REDUNDANT_COPY)] = {0u};

static cy_stc_eeprom_context_t eeprom_context;
static bool eeprom_is_initialized;

/*******************************************************************************
* Functions
*******************************************************************************/

static uint32_t eeprom_checksum(const capsense_calibration_record_t *record)
{
    uint32_t checksum = 2166136261u;
    uint32_t values[3] =
    {
        (uint32_t)record->version,
        record->wear_detect_cap_fF,
        record->reference_cap_fF
    };

    for (uint32_t value_index = 0u; value_index < 3u; value_index++)
    {
        for (uint32_t byte_index = 0u; byte_index < sizeof(uint32_t); byte_index++)
        {
            checksum ^= (values[value_index] >> (byte_index * 8u)) & 0xffu;
            checksum *= 16777619u;
        }
    }

    return checksum;
}

static bool eeprom_status_is_readable(cy_en_em_eeprom_status_t status)
{
    return (status == CY_EM_EEPROM_SUCCESS) ||
           (status == CY_EM_EEPROM_REDUNDANT_COPY_USED);
}

/**
 * @brief Initialize the emEEPROM context used by this module.
 * @return The emEEPROM initialization status.
 */
cy_en_em_eeprom_status_t eeprom_initialize(void)
{
    const cy_stc_eeprom_config_t config =
    {
        .eepromSize = EEPROM_DATA_SIZE,
        .simpleMode = EEPROM_SIMPLE_MODE,
        .wearLevelingFactor = EEPROM_WEAR_LEVELING,
        .redundantCopy = EEPROM_REDUNDANT_COPY,
        .blockingWrite = EEPROM_BLOCKING_WRITE,
        .userFlashStartAddr = (uint32_t)&eeprom_storage[0u]
    };
    cy_en_em_eeprom_status_t status =
        Cy_Em_EEPROM_Init(&config, &eeprom_context);

    eeprom_is_initialized = (status == CY_EM_EEPROM_SUCCESS);
    return status;
}

/**
 * @brief Write one complete CAPSENSE calibration record.
 * @param[in] wear_detect_cap_fF Absolute WearDetectSensor0 capacitance in fF.
 * @param[in] reference_cap_fF Absolute RefSensor0 capacitance in fF.
 * @return The emEEPROM write status.
 */
cy_en_em_eeprom_status_t eeprom_write_calibration(
        uint32_t wear_detect_cap_fF,
        uint32_t reference_cap_fF)
{
    capsense_calibration_record_t record =
    {
        .version = CAPSENSE_CALIBRATION_VERSION,
        .wear_detect_cap_fF = wear_detect_cap_fF,
        .reference_cap_fF = reference_cap_fF,
        .checksum = 0u
    };

    if (!eeprom_is_initialized)
    {
        return CY_EM_EEPROM_BAD_PARAM;
    }

    record.checksum = eeprom_checksum(&record);

    return Cy_Em_EEPROM_Write(
            EEPROM_RECORD_ADDRESS,
            &record,
            sizeof(record),
            &eeprom_context);
}

/**
 * @brief Read and validate the stored CAPSENSE calibration record.
 * @param[out] record Destination for the validated record.
 * @return The read status, or a validation error status.
 */
cy_en_em_eeprom_status_t eeprom_read_calibration(
        capsense_calibration_record_t *record)
{
    cy_en_em_eeprom_status_t status;

    if ((!eeprom_is_initialized) || (record == NULL))
    {
        return CY_EM_EEPROM_BAD_PARAM;
    }

    status = Cy_Em_EEPROM_Read(
            EEPROM_RECORD_ADDRESS,
            record,
            sizeof(*record),
            &eeprom_context);

    if (!eeprom_status_is_readable(status))
    {
        return status;
    }

    if (record->checksum != eeprom_checksum(record))
    {
        return CY_EM_EEPROM_BAD_CHECKSUM;
    }

    if (record->version != CAPSENSE_CALIBRATION_VERSION)
    {
        return CY_EM_EEPROM_BAD_DATA;
    }

    return status;
}