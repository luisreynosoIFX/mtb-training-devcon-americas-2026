# PSOC&trade; 4 Advanced CAPSENSE&trade; widgets training manual

## About this document

### Scope and purpose

This manual provides instructions for the advanced CAPSENSE&trade; widgets on PSOC&trade; 4 labs.

### Intended audience

This manual is intended for design engineers, technicians, and developers of electronic systems. 

## Table of contents

* [About this document](#about-this-document)
* [Introduction](#introduction)
* [Required development tools and prerequisites](#required-development-tools-and-prerequisites)
* [Lab 1: CAPSENSE sliders with gesture tuning](#lab-1-capsense-sliders-with-gesture-tuning)
* [Lab 2: Enabling gestures on touchpads](#lab-2-enabling-gestures-on-touchpads)
* [Lab 3: Configuring firmware for wear detection](#lab-3-configuring-firmware-for-wear-detection)
* [References](#references)
* [Revision History](#revision-history)
* [Disclaimer](#disclaimer)

## Introduction

This manual provides hands-on firmware labs for advanced CAPSENSE&trade; widgets on PSOC&trade; 4 kits:

1. Tune gestures on a CAPSENSE&trade; slider.
2. Enable and tune gestures on a touchpad.
3. Configure firmware for wear detection.

---

## Required development tools and prerequisites

### Tools

* **ModusToolbox&trade; software** v3.9 or later (Recommended installation via [ModusToolbox&trade; Setup tool](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup))
* [**Microsoft Visual Studio Code**](https://code.visualstudio.com/) with the [**ModusToolbox&trade; for VS Code**](https://marketplace.visualstudio.com/items?itemName=InfineonAG.modustoolbox-for-vscode) extension installed
* **ModusToolbox&trade; Programming Tools** v1.9.0 or later (Installed by [ModusToolbox&trade; Setup tool](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup) as a dependency to ModusToolbox&trade; v3.9)
* **ModusToolbox&trade; CAPSENSE&trade; and Multi-Sense Pack** v1.6.0 or later (Recommended installation via [ModusToolbox&trade; Setup tool](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup))
* **PSOC&trade; 4000T Prototyping Kit** ([CY8CPROTO-040T](https://www.infineon.com/evaluation-board/CY8CPROTO-040T))

<img src="assets/images/cy8cproto_040t.png" alt="CY8CPROTO-040T" style="width:400px; height:auto; display:block; margin:0 auto;" />

* **PSOC&trade; 4100T Plus Prototyping Kit** ([CY8CPROTO-041TP](https://www.infineon.com/evaluation-board/CY8CPROTO-041TP))

<img src="assets/images/cy8cproto_041tp.png" alt="CY8CPROTO-041TP" style="width:400px; height:auto; display:block; margin:0 auto;" />

### Prerequisites
Install the software and obtain the hardware listed in the Required development tools section.

This manual does not cover the basic concepts of ModusToolbox&trade; or the PSOC&trade; 4000T and PSOC&trade; 4100T Plus devices.

* For an introduction to PSOC&trade;, including a getting started guide to ModusToolbox&trade;, visit: [PSOC&trade; Developer](https://www.infineon.com/product-information/psocdeveloper)
* For the PSOC&trade; 4 CAPSENSE&trade; using PSOC&trade; 4000T and PSOC&trade; 4100T Plus training, visit: [PSOC&trade; 4 CAPSENSE&trade; Training Manual](https://github.com/Infineon/mtb-training-psoc-4-msclp-capsense)

---

## Lab 1: CAPSENSE sliders with gesture tuning

### Objective

In this lab, you will enable and tune gestures on the CSD CAPSENSE&trade; slider on the PSOC&trade; 4000T prototyping kit. The CAPSENSE&trade; Configurator [user guide](https://www.infineon.com/assets/row/public/documents/30/44/infineon-modustoolbox-capsense-configurator-user-guide-usermanual-en.pdf?fileId=8ac78c8c8e7ead30018ea595528d128a) describes how CAPSENSE&trade; gestures are implemented in section 7.5.11.

For more detailed information on the tuning procedure for a CAPSENSE&trade; slider, see [README](https://github.com/Infineon/mtb-example-psoc4-msclp-low-power-csd-slider) **Tuning procedure**.

Reference implementation: [**main.c: Lab 1 slider with gestures**](../Lab_Solutions/lab_1_slider_with_gestures/main.c)

### Project creation

1. <span id="step1-workspace-creation"></span>Open **ModusToolbox&trade;** from the **Windows Start** menu

> **Note:** If you have not installed ModusToolbox&trade;, see the [Required development tools](#required-development-tools-and-prerequisites) section.

<img src="assets/images/opening_modustoolbox_from_windows_11_start.png" alt="Running ModusToolbox Dashboard" style="width:427px; height:auto; display:block; margin:0 auto;" />

2. <span id="step2-directory-selection"></span>Select **Microsoft Visual Studio Code** as your **Target IDE**, and then click **Launch Project Creator**

<img src="assets/images/launch_project_creator.png" alt="Launching Project Creator" style="width:1200px; height:auto; display:block; margin:0 auto;" />

3. The **Project Creator** tool prompts you to choose a **BSP** (Board Support Package)

> **Note:** BSPs are aligned with development and evaluation kits; they provide files for basic device functionality. A BSP typically has a `design.modus` file that configures clocks and other board-specific capabilities. That file is used by the ModusToolbox&trade; configurators. A BSP also includes the required device support code for the device on the board. You can modify the configuration to suit your application.

4. Select the **CY8CPROTO-040T** BSP under the PSOC 4 BSPs, and then click **Next**

<img src="assets/images/selecting_the_psoc_4000t_bsp.png" alt="Project Creator BSP Selection" style="width:800px; height:auto; display:block; margin:0 auto;" />

5. Click **Next** to proceed to the application selection menu. Under **Sensing**, select the **MSCLP Low Power CSD Slider** application, and then click **Create**

<img src="assets/images/select_the_msclp_low_power_csd_slider_application.png" alt="Project Creator example code creation" style="width:800px; height:auto; display:block; margin:0 auto;" />

6. When you click **Create**, a new project is created under the **Application root path**, in a folder with the given project name. Navigate to the project directory, find the `.code-workspace` file, and open it with Microsoft Visual Studio Code

<img src="assets/images/csd_slider_vscode_workspace_file.png" alt="VSCODE workspace file after project creation" style="width:700px; height:auto; display:block; margin:0 auto;" />

7. In Microsoft Visual Studio Code, make sure the **ModusToolbox&trade; for VS Code** extension is installed and running. Once the extension is running, you will see it in the main panel

<img src="assets/images/csd_slider_vscode_modustoolbox_extension.png" alt="ModusToolbox for VS Code extension panel in the project workspace" style="width:1200px; height:auto; display:block; margin:0 auto;" />

<br>

> **Note:** VS Code may launch the workspace in **Restricted Mode**. If this happens, locate the blue ribbon under the taskbar indicating **Restricted Mode** and select **Manage**. A **Workspace Trust** window will pop up. Select **Trust** and close the window. The workspace will refresh and the ModusToolbox&trade; for VS Code extension will display after a brief delay.

<img src="assets/images/restricted_mode.png" alt="VS Code extension prompting to fix tasks and settings" style="width:1000px; height:auto; display:block; margin:0 auto;" />

> **Note:** The ModusToolbox&trade; for VS Code extension may display buttons indicating that the VS Code tasks and settings need to be updated. Simply click the buttons to correct the issues. This is a minor version mismatch between the ModusToolbox&trade; tools and the VS Code extension and does not affect functionality.

<img src="assets/images/vscode_fix_tasks_settings_prompt.png" alt="VS Code extension prompting to fix tasks and settings" style="width:800px; height:auto; display:block; margin:0 auto;" />


---

### Enable gestures 

1. Open the **CAPSENSE&trade; Configurator** from the **ModusToolbox&trade; for VS Code** extension

<img src="assets/images/launching_capsense_configurator_from_modustoolbox_vscode_extension.png" alt="Launching the CAPSENSE Configurator from the ModusToolbox for VS Code extension" style="width:800px; height:auto; display:block; margin:0 auto;">

2. Navigate to the **Advanced** > **Widget Details** tab, click the **LinearSlider0** widget, find the **Gesture parameters**, and then enable the desired gestures. Leave the gesture settings at their default values; you will tune them later

<img src="assets/images/csd_slider_enable_gestures.png" alt="CAPSENSE Configurator gesture parameters for the LinearSlider0 widget" style="width:800px; height:auto; display:block; margin:0 auto;">

> **Note:** You may need to disable touchpad gestures depending on the version of the code example used at the time of the training. Click the tool icon for each notice, and then disable the indicated gesture

<img src="assets/images/csd_slider_disable_touchpad_gestures.png" alt="CAPSENSE Configurator notices for disabling touchpad gestures" style="width:600px; height:auto; display:block; margin:0 auto;">

3. Save and close the **CAPSENSE Configurator**

4. Open the `main.c` file

5. Add the gesture timestamp interval macro

```c
/*******************************************************************************
 * User configurable Macros
 ********************************************************************************/
#ifdef CY_CAPSENSE_GESTURE_EN
#define TIMESTAMP_INTERVAL_IN_MILSEC    (50u)
#endif 
```

6. Update the definitions for the **SysTick** interval. Replace the existing definitions just before the finite state machine enumeration definition

```c
#if (ENABLE_RUN_TIME_MEASUREMENT)
#define SYS_TICK_INTERVAL           (0x00FFFFFF)
#define TIME_PER_TICK_IN_US         ((float)1/CY_CAPSENSE_CPU_CLK)*TIME_IN_US
#elif(CY_CAPSENSE_GESTURE_EN)
#define TIME_PER_TICK_IN_US         ((float)1/CY_CAPSENSE_CPU_CLK)*TIME_IN_US
#define SYS_TICK_INTERVAL           (TIMESTAMP_INTERVAL_IN_MILSEC*1000/(TIME_PER_TICK_IN_US))
#endif
```


7. Enable the **SysTick** function prototypes when gestures are enabled. Replace the existing prototypes just below the function prototypes for the CAPSENSE initialization and ISR

```c
#if (ENABLE_RUN_TIME_MEASUREMENT || CY_CAPSENSE_GESTURE_EN)
static void init_sys_tick(void);
#endif

#if ENABLE_RUN_TIME_MEASUREMENT
static void start_runtime_measurement();
static uint32_t stop_runtime_measurement();
#endif
```

8. Enable the **SysTick** functions when gestures are enabled. These should be near the bottom of the file between the ezi2c ISR and the LED control function

```c
/*******************************************************************************
 * Function Name: SysTickCallback
 ********************************************************************************
 * Summary:
 * Wrapper function for incrementing gesture timestamp and handling LED on time
 *
 *******************************************************************************/
#if (CY_CAPSENSE_GESTURE_EN)
void SysTickCallback(void)
{
    Cy_CapSense_IncrementGestureTimestamp(&cy_capsense_context);
}
#endif

#if (ENABLE_RUN_TIME_MEASUREMENT || CY_CAPSENSE_GESTURE_EN)
/*******************************************************************************
 * Function Name: init_sys_tick
 ********************************************************************************
 * Summary:
 *  initializes the system tick with highest possible value to start counting down.
 *
 *******************************************************************************/
static void init_sys_tick(void)
{
    Cy_SysTick_Init (CY_SYSTICK_CLOCK_SOURCE_CLK_CPU ,SYS_TICK_INTERVAL );
    cy_capsense_context.ptrCommonContext->timestampInterval = TIMESTAMP_INTERVAL_IN_MILSEC;
    #if (CY_CAPSENSE_GESTURE_EN)
    Cy_SysTick_SetCallback(0u,SysTickCallback);
    #endif
}
#endif
```

9. In the top of the main function, just below the CYBSP init function, modify the conditional enabling the **SysTick** init function when gestures are enabled

```c
#if (ENABLE_RUN_TIME_MEASUREMENT || CY_CAPSENSE_GESTURE_EN)
init_sys_tick();
#endif
```

10. Run widget decoder. This is in the **ACTIVE_MODE** case after the active slots are scanned

```c
Cy_CapSense_ProcessAllWidgets(&cy_capsense_context);

#if (CY_CAPSENSE_GESTURE_EN)
/*decode all the gestures*/
Cy_CapSense_DecodeWidgetGestures(CY_CAPSENSE_LINEARSLIDER0_WDGT_ID, &cy_capsense_context);
#endif
```

### Validate and tune the gesture parameters

The slider maximum position is 100 and the board slider is 37 mm long, so 1 position is approximately 0.37 mm. Gesture parameter distance values are coordinate units, not millimeters. Timeout values are milliseconds when the 50 ms SysTick timestamp interval is used. The values in the **Starting value** column are recommended starting points for this slider design; validate them experimentally.

1. Program the device

<img src="assets/images/programming_device_from_modustoolbox_vscode_extension.png" alt="ModusToolbox for VS Code panel for programming the device" style="width:800px; height:auto; display:block; margin:0 auto;">

2. Open the **CAPSENSE Tuner** from the **ModusToolbox&trade; for VS Code** extension

<img src="assets/images/launching_capsense_tuner_from_modustoolbox_vscode_extension.png" alt="Launching the CAPSENSE Tuner from the ModusToolbox for VS Code extension" style="width:800px; height:auto; display:block; margin:0 auto;">

3. Ensure SW2 is set up for I2C, and then confirm the communication settings

<img src="assets/images/csd_slider_tuner_com_settings.png" alt="tuner settings" style="width:800px; height:auto; display:block; margin:0 auto;">

4. Connect to the device and begin streaming, and then enable the slider widget

<img src="assets/images/csd_slider_tuner_connect_and_stream.png" alt="CSD slider tuner connect and stream" style="width:400px; height:auto; display:block; margin:0 auto;">


5. Open the **View** menu in the **CAPSENSE Tuner**, and then select **Gesture Event History** and **Gesture Monitor**. 

<img src="assets/images/gesture_monitor_and_event_views.png" alt="Gesture monitor and event views" style="width:400px; height:auto; display:block; margin:0 auto;">

6. Start the gesture event history log

<img src="assets/images/starting_gesture_event_history_log.png" alt="Starting the gesture event history log" style="width:400px; height:auto; display:block; margin:0 auto;">

> **Note:** The gesture event history logs all events. You should see a **Touch Down**, followed by the detected gesture, and then a **Lift Off** event

<img src="assets/images/gesture_event_history_scroll_and_flick.png" alt="gesture event history log" style="width:400px; height:auto; display:block; margin:0 auto;">

7. You can also view the **Gesture Monitor** window for real-time gesture indication

<img src="assets/gifs/gesture_monitor_scroll_right.gif" alt="Gesture Monitor scrolling right" style="width:800px; height:auto; display:block; margin:0 auto;">

> **Note:** In the **Graph View** tab, select the **Position** graph to view the positions reported by the slider during the gesture. Use the graph to identify the last valid position before lift-off, because the event logger does not report a position for any event that is detected on lift-off.



8. Apply the starting value suggestions from the table below, test each enabled gesture on the slider, and observe the displayed gesture result

Use the gesture results to evaluate the current settings before tuning the parameters in the following table.

| Parameter | Description | Starting value |
| --- | --- | --- |
| Click timeout maximum | Maximum duration of a click. | 300 ms |
| Click timeout minimum | Minimum duration of a click. | 50 ms |
| Click distance maximum | Maximum movement allowed for a click. | 3 positions (about 1.11 mm) |
| Second-click interval maximum | Maximum interval between clicks for a double click. | 300 ms |
| Second-click interval minimum | Minimum interval between clicks for a double click. | 100 ms |
| Second-click distance maximum | Maximum movement allowed between clicks. | 5 positions (about 1.85 mm) |
| Long-press timeout minimum | Minimum hold time for a long press. | 750 ms |
| Long-press distance maximum | Maximum movement allowed during a long press. | 5 positions (about 1.85 mm) |
| Scroll debounce | Number of consecutive scans used to debounce scrolling. | 2 scans |
| Scroll distance minimum | Minimum movement required to recognize scrolling. | 2 positions (about 0.74 mm) |
| Flick timeout maximum | Maximum duration of a flick. | 250 ms |
| Flick distance minimum | Minimum movement required to recognize a flick. | 25 positions (about 9.25 mm) |

### Example calculation from the gesture event history

The event history in the preceding image shows a **Touch Down** at position 17 at 09:59:13.656, followed by scroll positions 50, 73, and 90 at 09:59:13.695, 09:59:13.716, and 09:59:13.735. The log then reports a **One-finger Flick** and **Lift Off** at 09:59:13.774.

Use the position and timestamp values to compare this gesture with the recommended parameters:

1. The position changes between consecutive scroll events are:

    ```text
    50 - 17 = 33 positions
    73 - 50 = 23 positions
    90 - 73 = 17 positions
    ```

    Each change is greater than the recommended **Scroll distance minimum** of 5 positions. The total reported movement from touchdown to the last scroll position is 73 positions, or approximately 27.01 mm using 0.37 mm per position.

2. The elapsed time from touchdown to the first scroll event is:

    ```text
    09:59:13.695 - 09:59:13.656 = 39 ms
    ```

    The subsequent scroll updates occur 21 ms and 19 ms apart. These repeated position changes over multiple scans are consistent with a scrolling gesture and can be evaluated against the **Scroll debounce** setting of 2 scans.

3. The elapsed time from touchdown to the reported flick and lift-off is:

    ```text
    09:59:13.774 - 09:59:13.656 = 118 ms
    ```

    This is less than the recommended **Flick timeout maximum** of 250 ms. The last valid position before lift-off is 90, which is 73 positions from touchdown. This exceeds the **Flick distance minimum** of 25 positions (about 9.25 mm):

    ```text
    90 - 17 = 73 positions
    73 positions x 0.37 mm/position = 27.01 mm
    ```

    The event logger does not report a position for the flick because the flick is recognized at lift-off, and the lift-off position is not considered valid. Use the last valid position in the event history or the **Position** graph as the tuning evidence. In this example, 73 positions and 118 ms show that the gesture is comfortably above the recommended 25-position distance and below the 250-ms timeout. To tune the parameters, repeat the gesture with intentionally shorter and slower movements, record the last valid position and touchdown-to-lift-off time, and adjust one threshold at a time. For example, increase **Flick distance minimum** until an unintended short swipe no longer produces a flick, then verify that the intended gesture still exceeds the selected distance and remains within **Flick timeout maximum**.


<img src="assets/images/csd_slider_updating_gesture_parameters.png" alt="Updating gesture parameters" style="width:400px; height:auto; display:block; margin:0 auto;">

9. Choose one gesture and adjust one related parameter at a time. Record the parameter value, the gesture you performed, the reported touchdown and lift-off positions, the timestamp, and the detected gesture. Repeat each test several times, including intentional gestures and borderline movements, and use the observations to select values for your application rather than copying the project values unchanged


> **Note:** Using the **Gesture Event History** view is especially helpful for determining the position change and timing for a gesture. 

During the investigation, look for these behaviors:

* False positives: increase the relevant distance or timeout threshold only when it prevents an unintended classification; increase debounce or a minimum distance when noise is being recognized as movement.
* Missed gestures: relax the relevant minimum distance or timeout, or reduce debounce, while checking that the change does not create false positives.
* Low-power and Wake On Touch behavior: compare gesture results before and after entering Wake On Touch mode. Fast gestures, such as a click or double click, may be missed because the low-power WOT sensor and debounce settings delay or filter the touch. Adjust the WOT threshold and debounce, then verify detection reliability and power-state transitions together.

Define a final parameter set and explain the tradeoffs between responsiveness, false-positive rejection, gesture separation, slider resolution, and low-power behavior. Test the final settings with different gesture speeds and positions on the slider to check that the result is repeatable.

## Lab 2: Enabling gestures on touchpads

### Objective

In this lab, you will enable and tune gestures on the CSX CAPSENSE&trade; touchpad on the PSOC&trade; 4100T Plus prototyping kit

Reference configuration: [**Lab 2 touchpad with gestures**](../Lab_Solutions/lab_2_touchpad_with_gestures/bsps/TARGET_APP_CY8CPROTO-041TP/config/)

### Project creation

1. <span id="step1-workspace-creation"></span>Launch the **Project Creator** from the **ModusToolbox Dashboard**

2. Select the **CY8CPROTO-041TP** BSP under the PSOC 4 BSPs, and then click **Next**

<img src="assets/images/selecting_the_psoc_4100tp_bsp.png" alt="Project Creator BSP Selection" style="width:800px; height:auto; display:block; margin:0 auto;" />

3. Click **Next** to proceed to the application selection menu. Under **Sensing**, select the **MSCLP low-power multitouch mutual-capacitance touchpad** application, and then click **Create**

<img src="assets/images/select_msclp_csx_touchpad_application.png" alt="Project Creator example code creation" style="width:800px; height:auto; display:block; margin:0 auto;" />

4. When you click **Create**, a new project is created under the **Application root path**, in a folder with the given project name. Navigate to the project directory, find the `.code-workspace` file, and open it with Microsoft Visual Studio Code

<img src="assets/images/csx_touchpad_vscode_workspace_file.png" alt="VSCODE workspace file after project creation" style="width:700px; height:auto; display:block; margin:0 auto;" />

5. In Microsoft Visual Studio Code, make sure the **ModusToolbox&trade; for VS Code** extension is installed and running. Once the extension is running, you will see it in the main panel

<img src="assets/images/csx_touchpad_vscode_modustoolbox_extension.png" alt="ModusToolbox for VS Code extension panel in the project workspace" style="width:1200px; height:auto; display:block; margin:0 auto;" />

<br>

> **Note:** VS Code may launch the workspace in **Restricted Mode**. If this happens, locate the blue ribbon under the taskbar indicating **Restricted Mode** and select **Manage**. A **Workspace Trust** window will pop up. Select **Trust** and close the window. The workspace will refresh and the ModusToolbox&trade; for VS Code extension will display after a brief delay.

<img src="assets/images/restricted_mode.png" alt="VS Code extension prompting to fix tasks and settings" style="width:1000px; height:auto; display:block; margin:0 auto;" />

> **Note:** The ModusToolbox&trade; for VS Code extension may display buttons indicating that the VS Code tasks and settings need to be updated. Simply click the buttons to correct the issues. This is a minor version mismatch between the ModusToolbox&trade; tools and the VS Code extension and does not affect functionality.

<img src="assets/images/vscode_fix_tasks_settings_prompt.png" alt="VS Code extension prompting to fix tasks and settings" style="width:800px; height:auto; display:block; margin:0 auto;" />

### Enable and tune the one-finger edge swipe gesture

This project has already enabled some typical touchpad gestures. In this lab, you will enable the **One-finger edge swipe** gesture to demonstrate how to enable and tune a new gesture

1. Open the **CAPSENSE&trade; Configurator** from the **ModusToolbox&trade; for VS Code** extension

<img src="assets/images/launching_capsense_configurator_from_modustoolbox_vscode_extension.png" alt="Launching the CAPSENSE Configurator from the ModusToolbox for VS Code extension" style="width:1200px; height:auto; display:block; margin:0 auto;" />


2. Navigate to the **Advanced** > **Widget Details** tab, and then click the **Touchpad** widget. Open the **Gesture parameters** dropdown and observe the enabled gestures and their parameters. This project has pre-tuned gestures, but enable the **one-finger edge swipe** gesture. Save and close the **CAPSENSE&trade; Configurator**

<img src="assets/images/enable_one_finger_edge_swipe_gestures.png" alt="Enabling one-finger edge swipe gestures" style="width:1200px; height:auto; display:block; margin:0 auto;" />


3. Program the device

<img src="assets/images/csx_touchpad_programming_device_from_modustoolbox_vscode_extension.png" alt="ModusToolbox for VS Code panel for programming the CSX touchpad device" style="width:800px; height:auto; display:block; margin:0 auto;">

4. Open the **CAPSENSE Tuner** from the **ModusToolbox&trade; for VS Code** extension

<img src="assets/images/launching_capsense_tuner_from_modustoolbox_vscode_extension.png" alt="Launching the CAPSENSE Tuner from the ModusToolbox for VS Code extension" style="width:800px; height:auto; display:block; margin:0 auto;">

5. Confirm the communication settings

<img src="assets/images/csx_touchpad_tuner_com_settings.png" alt="tuner settings" style="width:800px; height:auto; display:block; margin:0 auto;">

6. Connect to the device and begin streaming, and then enable the touchpad widget

<img src="assets/images/csx_touchpad_tuner_connect_and_stream.png" alt="CAPSENSE Tuner controls for connecting to the CSX touchpad and streaming data" style="width:400px; height:auto; display:block; margin:0 auto;">



7. Open the **Graph View** tab and expand the **Position** graph. Generate edge swipes by starting a touchdown event near the edge of the touchpad and swiping toward the center before lifting off

8. Halt the tuner by pressing **Stop**

<img src="assets/images/halt_tuner_comms.png" alt="CAPSENSE Tuner control for stopping communication with the CSX touchpad" style="width:400px; height:auto; display:block; margin:0 auto;">


9. Adjust the view of the position graph so that it is easier to see the position data. You can zoom using the mouse scroll wheel, then disable the **Auto scale Y** feature, and then set the **Range: from** 0 to 260

<img src="assets/images/csx_touchpad_position_graph.png" alt="CAPSENSE Tuner Position graph showing CSX touchpad coordinates" style="width:1200px; height:auto; display:block; margin:0 auto;">

10. You should be able to see the X and Y positions reported so that you can compute the **Edge size** and **Minimum edge distance** parameters. The previous image shows a touchdown at coordinates (118, 249) and a lift-off at (127, 86). An **Edge size** of 7 would have worked here, but use an **Edge size** of 20 for a conservative setting. The distance traveled in the Y direction was 163, so set the **Minimum edge distance** to 75

<img src="assets/images/setting_edge_swipe_parameters.png" alt="CAPSENSE Configurator fields for setting edge-swipe parameters" style="width:400px; height:auto; display:block; margin:0 auto;">


11. Open the **View** menu in the **CAPSENSE Tuner**, and then select **Gesture Event History** and **Gesture Monitor**

12. Start the **Gesture Event History**, generate an edge swipe gesture, and then observe the log

<img src="assets/images/edge_swipe_gesture_event_history_log.png" alt="CAPSENSE Tuner gesture event history showing an edge swipe" style="width:400px; height:auto; display:block; margin:0 auto;">

13. You can also observe the gestures live in the **Gesture Monitor**

<img src="assets/gifs/gesture_monitor_edge_swipe.gif" alt="Gesture Monitor scrolling right" style="width:800px; height:auto; display:block; margin:0 auto;">

---

### Expected results

The one-finger edge swipe gesture should be reported by the CAPSENSE Tuner and visible in the Gesture Monitor. Use the position graph and Gesture Event History to verify the result rather than relying only on the live touch indicator.

The example interaction provides the following tuning evidence:

* Touchdown: approximately `(118, 249)`.
* Lift-off: approximately `(127, 86)`.
* Distance from the bottom edge: approximately 7 coordinate units.
* Inward movement: `249 - 86 = 163` coordinate units.
* Edge angle: $\tan^{-1}(9 / 163) \approx 3.2$ degrees, measured from the inward direction.

The resulting starting parameter set is:

| Parameter | Starting value | Reasoning |
| --- | --- | --- |
| Edge size | 20 coordinate units | Includes the example touchdown with margin while limiting accidental edge activation. |
| Minimum edge distance | 75 coordinate units | The example travels 163 units, providing more than a two-to-one movement margin. |
| Maximum edge angle | 45 degrees | Accepts the approximately 3.2-degree example while allowing a moderate diagonal swipe. |

Repeat the gesture from all four edges and at different speeds. During tuning, look for these behaviors:

* False positives: reduce **Edge size** or increase **Minimum edge distance** when ordinary touches near an edge are classified as swipes.
* Missed edge swipes: increase **Edge size**, reduce **Minimum edge distance**, or increase **Maximum edge angle** when an intentional swipe is not reported.
* Poor direction selectivity: reduce **Maximum edge angle** when diagonal movement is incorrectly accepted as an edge swipe.
* Wake On Touch behavior: compare edge-swipe detection in active mode and WOT mode. Quick gestures may be missed when the low-power widget, scan interval, threshold, or debounce settings delay the first valid touch or filter the movement.

Define the final touchpad parameter set from repeated results rather than from one interaction. Tune the low-power widget and WOT settings together, then verify that edge swipes remain responsive without creating unintended wake events. Test short, long, diagonal, and slow swipes near each edge to confirm the balance between responsiveness, false-positive rejection, direction selectivity, and low-power behavior.



## Lab 3: Configuring firmware for wear detection

### Objective

In this lab, you will modify the firmware on the PSOC&trade; 4000T prototyping kit to enable power-on touch detection and temperature compensation. These firmware-based algorithms are critical for reliable wear-detection applications

### CAPSENSE&trade; wear detection

Wear detection allows users to interact with various wearable electronic devices and enables devices to detect the presence of human body with or without physical contact. It can be used to switch the mode of the device based on whether or not the user is currently wearing the device. This makes wear detection an attractive feature for wearable applications such as over-ear headphones, on-ear headphones, in-ear headphones,smart watches, fitness bands, smart glasses, smart rings, and so on.

There are many things to consider when designing a CAPSENSE&trade; wear detection sensor. Strict layout and design rules should be followed to maximize the available signal. In this lab, you will focus on two primary aspects of wearable design: power-on wear detection and temperature compensation

### Project creation

1. <span id="step1-workspace-creation"></span>Launch the **Project Creator** from the **ModusToolbox Dashboard** 

2. Select the **CY8CPROTO-040T** BSP under the PSOC 4 BSPs, and then click **Next**

<img src="assets/images/selecting_the_psoc_4000t_bsp.png" alt="Project Creator BSP Selection" style="width:800px; height:auto; display:block; margin:0 auto;" />

3. Click **Next** to proceed to the application selection menu. Select the **MSCLP Low Power Proximity** under the Sensing section by clicking the **checkbox** near the application, and then click **Create**

<img src="assets/images/select_the_msclp_low_power_proximity_application.png" alt="Project Creator example code creation" style="width:800px; height:auto; display:block; margin:0 auto;" />

4. When you click **Create**, a new project is created. The project location is under the **Application root path**, in a folder with the given project name. Navigate to the project directory, and find the **.code-workspace** file and open it with Microsoft Visual Studio Code. 


<img src="assets/images/proximity_vscode_workspace_file.png" alt="VSCODE workspace file after project creation" style="width:700px; height:auto; display:block; margin:0 auto;" />

5. Once opened in Microsoft Visual Studio Code, make sure you have the **ModusToolbox&trade; for VS Code** extension installed. Once the extension is running, you will see the extension in the main panel

<img src="assets/images/proximity_vscode_modustoolbox_extension.png" alt="ModusToolbox for VS Code extension panel in the project workspace" style="width:1200px; height:auto; display:block; margin:0 auto;" />

<br>

> **Note:** VS Code may launch the workspace in **Restricted Mode**. If this happens, locate the blue ribbon under the taskbar indicating **Restricted Mode** and select **Manage**. A **Workspace Trust** window will pop up. Select **Trust** and close the window. The workspace will refresh and the ModusToolbox&trade; for VS Code extension will display after a brief delay.

<img src="assets/images/restricted_mode.png" alt="VS Code extension prompting to fix tasks and settings" style="width:1000px; height:auto; display:block; margin:0 auto;" />

> **Note:** The ModusToolbox&trade; for VS Code extension may display buttons indicating that the VS Code tasks and settings need to be updated. Simply click the buttons to correct the issues. This is a minor version mismatch between the ModusToolbox&trade; tools and the VS Code extension and does not affect functionality.

<img src="assets/images/vscode_fix_tasks_settings_prompt.png" alt="VS Code extension prompting to fix tasks and settings" style="width:800px; height:auto; display:block; margin:0 auto;" />

---

### Enable the reference sensor

This lab reuses the temperature reference sensor (TRS) as a power-on wear detection (POWD) reference, so the same reference sensor supports both temperature compensation and power-on wear detection. Use the **CAPSENSE&trade; Configurator** to add the reference sensor and configure it for low-power wear detection.

1. From the **ModusToolbox&trade; for VS Code** extension panel, launch the **CAPSENSE&trade; Configurator**

<img src="assets/images/launching_capsense_configurator_from_modustoolbox_vscode_extension.png" alt="Launching CAPSENSE Configurator from ModusToolbox for VS Code extension" style="width:800px; height:auto; display:block; margin:0 auto;" />

2. In the **Basic** tab, under **CSD Settings** > **Widgets**, add a new **Proximity** widget to represent the reference sensor. Assign it a distinct name, such as `RefSensor0`, so it is not confused with the wear-detect sensor widget. Rename the initial proximity sensor to `WearDetectSensor0` so that its name aligns with the naming convention

<img src="assets/images/adding_reference_sensor.png" alt="CAPSENSE Configurator dialog for adding a reference Proximity widget" style="width:200px; height:auto; display:block; margin:0 auto;" />

<br/>

<img src="assets/images/naming_wear_and_reference_sensor.png" alt="CAPSENSE Configurator showing the WearDetectSensor0 and RefSensor0 widget names" style="width:800px; height:auto; display:block; margin:0 auto;" />

3. In the **Advanced** > **CSD Settings** tab, reduce the **Total shield count** from 10 to 9. This project sets all unused CAPSENSE&trade; pins to shield by default. You will use one of the CSX button electrodes as a reference sensor, so update the pin mapping next

<img src="assets/images/reducing_shield_count.png" alt="CAPSENSE Configurator CSD settings with the total shield count reduced to 9" style="width:800px; height:auto; display:block; margin:0 auto;" />

4. In the **Scan Configuration**, change both widget pin assignments from the default large loop electrode. Assign `WearDetectSensor0` to P4.0, the EVK CSD button pin, and `RefSensor0` to P2.1, a separate reference-sensor pin. The **Shield2** through **Shield8** pins will also need to be updated

<img src="assets/images/wear_detect_pin_map_update.png" alt="CAPSENSE Configurator scan configuration showing the wear and reference sensor pin assignments" style="width:800px; height:auto; display:block; margin:0 auto;" />


5. Navigate to the **Advanced** > **Widget Details** tab and update the reference sensor widget's **Sense clock divider** and **Number of sub-conversions** to match the wear sensor settings

<img src="assets/images/set_reference_sensor_settings.png" alt="CAPSENSE Configurator widget details for matching reference sensor settings" style="width:800px; height:auto; display:block; margin:0 auto;" />

6. In the same tab, set the **Proximity touch threshold** and **Proximity threshold** to 65535 so that the baseline always tracks the raw counts and a proximity or touch is never reported

<img src="assets/images/setting_reference_sensor_thresholds.png" alt="CAPSENSE Configurator showing the reference sensor threshold values set to 65535" style="width:800px; height:auto; display:block; margin:0 auto;" />

7. In the **Advanced** > **General** tab, enable the self-test library so that you can measure the absolute capacitance of each sensor

<img src="assets/images/enabling_self_test_library.png" alt="CAPSENSE Configurator General settings with the self-test library enabled" style="width:800px; height:auto; display:block; margin:0 auto;" />

8. Click **Save**, and then close the **CAPSENSE&trade; Configurator** to regenerate the `cycfg_capsense` configuration files

### Add calibration value storage

During factory calibration, measure the absolute capacitance of the wear-detection and reference sensors and store the results in non-volatile memory. These values are the baseline inputs for power-on wear detection and temperature compensation.

1. Launch the **Library Manager** from the **ModusToolbox&trade; for VS Code extension** by clicking on the **Configure Middleware** button

<img src="assets/images/launch_library_manager.png" alt="ModusToolbox for VS Code panel showing the Configure Middleware button" style="width:800px; height:auto; display:block; margin:0 auto;" />

2. Click **Add Library**

<img src="assets/images/library_manager_add_library.png" alt="Library Manager window with the Add Library button" style="width:800px; height:auto; display:block; margin:0 auto;" />

3. Search for **eeprom**, select the library, and then click **OK**

<img src="assets/images/enabling_eeprom_library.png" alt="Library Manager search results for the eeprom library" style="width:800px; height:auto; display:block; margin:0 auto;" />

4. Click **Update** to update the project libraries. Once the update is complete, close the **Library Manager**

<img src="assets/images/library_manager_update.png" alt="Library Manager window for updating project libraries" style="width:800px; height:auto; display:block; margin:0 auto;" />

5. Add the **eeprom.c** and **eeprom.h** source files from the [**Lab_Solutions/lab_3_wear_detection**](../Lab_Solutions/lab_3_wear_detection) folder

6. Add the **EM_EEPROM** component to the makefile

```bash
COMPONENTS=APP EM_EEPROM
```

7. Include the header file in the main source file

```c
#include "eeprom.h"
```

8. Add the reusable wear-detect helper module

A reusable `capsense_wear_detect` module is provided in the lab solution so that you can focus on the firmware behavior instead of copying and pasting a long block of helper functions into `main.c`. Add the module files from the [**Lab_Solutions/lab_3_wear_detection**](../Lab_Solutions/lab_3_wear_detection) folder:

* `capsense_wear_detect.h`
* `capsense_wear_detect.c`

Then include the header in the project source:

```c
#include "capsense_wear_detect.h"
```

> **Note:** The module contains the BIST measurement, calibration initialization, power-on wear decision, and the temperature-reference compensation helpers that were previously embedded directly in `main.c`.

9. Add the calibration variables to the `main` function and initialize them after CAPSENSE is set up

```c
int main(void)
{
    cy_rslt_t result;
    uint32_t capsense_state_timeout;
    uint32_t interruptStatus;

    uint32_t wear_detect_cap_fF = 0u;
    uint32_t reference_cap_fF = 0u;

    bool wear_detected = false;
    bool wear_detection_valid;
```

```c
    /* Initialize MSC CAPSENSE */
    initialize_capsense();

    /* Capture calibration before entering the normal scan state machine. */
    wear_detection_valid = capsense_wear_detect_init_calibration_values(
        &wear_detect_cap_fF,
        &reference_cap_fF);
```

10. Review the module API and answer the following questions:

* What is the purpose of the factory calibration values stored in EEPROM?
* Why are the wear and reference capacitance values captured with the self-test (BIST) measurement instead of a normal CAPSENSE&trade; scan?
* Why must `capsense_wear_detect_init_calibration_values()` run after `initialize_capsense()` but before the scan state machine starts?
* How does the firmware decide whether to measure new calibration values or read the previously stored ones, and what happens to those stored values when the device is reprogrammed?

### Add power-on wear detection

At startup, load the factory calibration values, measure the current sensor capacitance, compensate the wear-sensor value using the reference sensor, and determine whether the device is already being worn.

The following formulas calculate the `RSCp-ratio`, compensated `SenseCap_Cur`, and its associated variable. The `Ktemp-ratio` in the firmware implementation of the TRS algorithm is calculated using raw count values. In this context, the `RSCp-ratio` is based on reference sensor capacitance (`Cp`) measurements.

$$
\mathrm{RSCp\text{-}ratio} = 1.0 + \mathrm{tccf\_cp} \times \frac{\mathrm{ref\_cp\_value} - \mathrm{ref\_base\_cp\_val}}{\mathrm{ref\_base\_cp\_val}}
\quad (3)
$$

$$
\mathrm{Adjusted\ WearSensCap} = \mathrm{WearSensCap} \times \mathrm{RSCp\text{-}ratio}
\quad (4)
$$

* `tccf_cp`: Temperature compensation correction factor for Cp compensation.
* `ref_cp_value`: Reference sensor capacitance (Cp).
* `ref_base_cp_val`: Reference sensor baseline capacitance (Cp).
* `WearSensCap`: Sensor capacitance (Cp).
* `RSCp-ratio`: Temperature reference sensor Cp ratio.


> **Implementation note:** The firmware recalculates `RSCp-ratio` after every reference-sensor BIST measurement while in the `POWER_ON_WEAR` state, using the current and factory-calibrated reference-sensor capacitance values with `WEAR_DETECTION_TCCF_CP`. This compensates the power-on wear decision for temperature and common-mode drift. Active-mode scans use `reference_ktemp_ratio()` instead. No fixed `rscp_ratio` training default is used.

The recommended approach is to use the reusable `capsense_wear_detect` module for the low-level helper functions and keep the lab focused on the application-level integration in `main.c`.


1. Add the `POWER_ON_WEAR` application state and the startup wear flag

```c
/*****************************************************************************
 * Finite state machine states for device operating states
 *****************************************************************************/

typedef enum
{
    ACTIVE_MODE = 0x01u,    /* Active mode - All the sensors are scanned in this state
     * with highest refresh rate */
    ALR_MODE = 0x02u,       /* Active-Low Refresh Rate (ALR) mode - All the sensors are
     * scanned in this state with low refresh rate */
    WOT_MODE = 0x03u,        /* Wake on Touch (WoT) mode - Low Power sensors are scanned
     * in this state with lowest refresh rate */
    POWER_ON_WEAR = 0x04u   /* Power-on wear decision and continuous compensation */
} APPLICATION_STATE;
```

2. After CAPSENSE&trade; initialization completes, evaluate the startup wear condition

```c
wear_detection_valid = capsense_wear_detect_init_calibration_values(
    &wear_detect_cap_fF,
    &reference_cap_fF);

if (wear_detection_valid)
{
    wear_detection_valid = capsense_wear_detect_power_on_wear_detection(
        wear_detect_cap_fF,
        reference_cap_fF,
        &wear_detected);
}

if (wear_detection_valid && !wear_detected)
{
    capsense_state = WOT_MODE;
    capsense_state_timeout = ALR_MODE_TIMEOUT;
    capsense_wear_detect_initialize_active_baselines_after_scan();
}
else
{
    capsense_state = POWER_ON_WEAR;
}

#if ENABLE_PWM_LED
led_control();
#endif
```

3. Configure the MSCLP timer for the selected initial state. This should replace the **Cy_CapSense_ConfigureMsclpTimer** API call just before entering the infinite for loop

```c
if (capsense_state == WOT_MODE)
{
    Cy_CapSense_ConfigureMsclpTimer(ALR_MODE_TIMER, &cy_capsense_context);
}
else
{
    Cy_CapSense_ConfigureMsclpTimer(ACTIVE_MODE_TIMER, &cy_capsense_context);
}
```

4. Update the state machine so that the `POWER_ON_WEAR` path continues to re-check the compensated wear condition until it clears

```c
case POWER_ON_WEAR:
    wear_detection_valid = capsense_wear_detect_power_on_wear_detection(
        wear_detect_cap_fF,
        reference_cap_fF,
        &wear_detected);

    if (wear_detection_valid && !wear_detected)
    {
        capsense_wear_detect_initialize_active_baselines_after_scan();
        capsense_state = ACTIVE_MODE;
        capsense_state_timeout = ACTIVE_MODE_TIMEOUT;
    }

    #if ENABLE_PWM_LED
    led_control();
    #endif
    break;
```

5. Update the LED behavior so the LED remains on while the startup wear condition is active

```c
/*******************************************************************************
 * Function Name: led_control
 ********************************************************************************
 * Summary:
 *  Control LED2(CYBSP_USER_LED) in the kit to show the touch status
 *  LED2 turns ON when a touch is detected
 *******************************************************************************/
void led_control()
{

    if (POWER_ON_WEAR == capsense_state)
    {
        Cy_GPIO_Write(CYBSP_USER_LED_PORT, CYBSP_USER_LED_NUM, CYBSP_LED_ON);
    }
    else if (TOUCH_STATE == Cy_CapSense_IsProximitySensorActive(
                                CY_CAPSENSE_WEARDETECTSENSOR0_WDGT_ID,
                                CY_CAPSENSE_WEARDETECTSENSOR0_SNS0_ID,
                                &cy_capsense_context))
    {
        Cy_GPIO_Write(CYBSP_USER_LED_PORT, CYBSP_USER_LED_NUM, CYBSP_LED_ON);
    }
    else
    {
        Cy_GPIO_Write(CYBSP_USER_LED_PORT, CYBSP_USER_LED_NUM, CYBSP_LED_OFF);
    }
}
```

6. Program the device from the **ModusToolbox&trade; for VS Code extension**

<img src="assets/images/wear_detect_programming.png" alt="ModusToolbox for VS Code panel for programming the wear-detection device" style="width:800px; height:auto; display:block; margin:0 auto;" />

7. Make sure that **J6** is in the **USER BTN** configuration. Once the programming step has completed, hold both the reset button and the **USER BTN** down, and then release the reset button to force the calibration

8. Generate a touch on the **CSB1** electrode and observe that **LED3** is illuminated. Continue generating the touch while pressing and releasing the reset button. **LED3** will turn off briefly while the device resets, but will turn back on as long as a touch (wear) is detected on the **CSB1** sensor

<img src="assets/images/cy8cproto_040t_led_3.png" alt="LED 3 on the CY8CPROTO-040T kit" style="width:800px; height:auto; display:block; margin:0 auto;" />

9. Open the **CAPSENSE&trade; Tuner** from the **ModusToolbox&trade; for VS Code extension**

<img src="assets/images/launching_capsense_tuner_from_modustoolbox_vscode_extension.png" alt="ModusToolbox for VS Code panel for launching the CAPSENSE Tuner" style="width:800px; height:auto; display:block; margin:0 auto;" />

10. Confirm the communication settings

<img src="assets/images/wear_detect_tuner_com_settings.png" alt="tuner settings" style="width:800px; height:auto; display:block; margin:0 auto;">

11. If you generate the wear condition (**DON**) during a board reset, then connect to the device and begin streaming, you will observe that the reported **raw count** corresponds to the measured capacitance. Once you remove the wear condition (**DOFF**), the device will switch to normal **raw count** reporting

<img src="assets/images/power_on_wear_detection_in_tuner.png" alt="CAPSENSE Tuner showing power-on wear detection measurements" style="width:1200px; height:auto; display:block; margin:0 auto;" />

Reference implementation: [**main.c: power-on wear detection**](../Lab_Solutions/lab_3_wear_detection/power_on_wear_detect_only_main_source_file/main.c)

### Guided questions

Use the module API to answer these questions before moving to the final temperature-compensation step:

1. Which function calculates the `RSCp-ratio` and why is it different from the active-mode `Ktemp-ratio` calculation?
2. Why does the startup logic use `POWER_ON_WEAR` until the compensated wear measurement clears the detection threshold?
3. What happens if the reference sensor drifts but the wear sensor does not? Why is the module compensating with the reference value?
4. Why do the Tuner values show the adjusted capacitance, baseline capacitance, and diff count instead of the raw uncorrected values during the startup decision?

### Optional challenge

> **Challenge:** Experiment with the power-on wear decision in the provided `capsense_wear_detect` module. At this point in the lab only the startup path is implemented, so every observation is made by creating a wear condition on **CSB1** and then resetting the device with the reset button. Change one parameter at a time, repeat the reset test, and record when the device reports **DON** at power-on and when it later clears to **DOFF**.
>
> The module makes the startup decision with two thresholds:
>
> - **DON** at power-on when the adjusted capacitance exceeds `wear_detect_cap_fF + WEAR_DETECTION_THRESHOLD_MARGIN_FF + hysteresis`
> - **DOFF** afterwards when the adjusted capacitance falls below `wear_detect_cap_fF + WEAR_DETECTION_THRESHOLD_MARGIN_FF - hysteresis`
>
> where `hysteresis` is `WEAR_DETECTION_THRESHOLD_MARGIN_FF * WEAR_DETECTION_HYSTERESIS_RATIO`. With the default values the hysteresis is 10 fF, so **DON** is evaluated at `wear_detect_cap_fF + 110` and **DOFF** at `wear_detect_cap_fF + 90`.
>
> > **Note:** The hysteresis is derived from the margin, so changing `WEAR_DETECTION_THRESHOLD_MARGIN_FF` shifts both decision points and rescales the hysteresis at the same time. Only `WEAR_DETECTION_HYSTERESIS_RATIO` changes the separation between the two thresholds on its own.
>
> > **Note:** The startup wear behavior can only be observed by holding a wear condition on **CSB1** while pressing and releasing the reset button. There is no way to observe the power-on reference compensation without forcing that wear state during reset. Remember that the calibration values must be recaptured after every programming step.
>
> > **Note:** `POWER_ON_WEAR` is entered only at startup. Once the condition clears, the firmware moves to `ACTIVE_MODE` and does not return, so each reset gives you exactly one **DON** decision and one **DOFF** transition to observe.
>
> Your goal is not to find a single perfect value, but to observe how each parameter shifts the **DON** and **DOFF** decision points and to draw a conclusion from the trend.

| Trial | Parameter changed | Initial value | Change to try | What to observe | Observed result | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | `WEAR_DETECTION_TCCF_CP` | `-0.25f` | Set to `0.0f` | DON at reset, then the DOFF transition |  |  |
| 2 | `WEAR_DETECTION_TCCF_CP` | `-0.25f` | Set to `-1.0f` | DON at reset, then the DOFF transition |  |  |
| 3 | `WEAR_DETECTION_THRESHOLD_MARGIN_FF` | `100.0f` | Increase in steps | The value at which DON is no longer detected at reset |  |  |
| 4 | `WEAR_DETECTION_HYSTERESIS_RATIO` | `0.10f` | Increase in steps | How much of the wear must be removed before the device clears to DOFF |  |  |

For trials 3 and 4, work upward in steps rather than jumping straight to a large value. The value at which the behavior changes is itself the measurement you are after.

> **Note:** The **LED3** only reports the final DON/DOFF result. Connecting the **CAPSENSE&trade; Tuner** and streaming makes every trial much easier to interpret, because during `POWER_ON_WEAR` the wear sensor reports the adjusted capacitance, the calibration baseline, and the difference count. You can watch how close each measurement sits to the threshold instead of inferring it from the LED alone.

Use the table to compare how each value shifts the startup decision. Add a short conclusion describing which direction made the power-on wear condition easier to latch at reset and which made it harder to clear afterwards.

This challenge is intended to make the trainee reason about the power-on wear decision and the effect of parameter changes instead of simply calling a finished library function.

### Add temperature reference compensation

The following formulas calculate the `Ktemp-ratio`, adjusted `SensRC`, and their associated variables.

$$
\mathrm{Ktemp\text{-}ratio} = 1.0 + \mathrm{tccf} \times \frac{\mathrm{ref\_rawcounts} - \mathrm{ref\_bsln}}{\mathrm{ref\_bsln}}
\quad (1)
$$

$$
\mathrm{Adjusted\ SensRC} = \mathrm{SensDiffCnt} \times \mathrm{Ktemp\text{-}ratio}
\quad (2)
$$

* `tccf`: Temperature compensation correction factor.
* `ref_rawcounts`: Reference sensor raw counts.
* `ref_bsln`: Reference sensor baseline.
* `SensDiffCnt`: Sensor difference count.


> **Implementation note:** Equation (2) is written in the **difference-count** domain. `SensDiffCnt` is already `raw - bsln`, so the equation consumes a difference count and returns a difference count. The firmware works in the **raw-count** domain instead, because the correction is injected into the middle of the processing pipeline, before the baseline and difference counts have been calculated. `process_active_widgets_with_ktemp()` therefore scales the deviation and adds the baseline back, so that a valid raw count can be written into `CY_CAPSENSE_WEARDETECTSENSOR0_SNS0_RAW0_VALUE` for the remaining pipeline stages to consume:
>
> $$
> \mathrm{Adjusted\ Raw} = \mathrm{bsln} + (\mathrm{raw} - \mathrm{bsln}) \times \mathrm{Ktemp\text{-}ratio}
> $$
>
> The two forms express the same correction and differ only in which quantity they return. Dropping the `bsln` term here would overwrite a raw count of tens of thousands with a difference of a few hundred, which the baseline algorithm would then read as a collapse of the signal.

The recommended approach is to reuse the same `capsense_wear_detect` module for the temperature-compensation helper functions and keep the exercise focused on the application call sites in `main.c`.

1. In the active and ALR scan path, call the compensation helper after the scan completes and before widget status is checked. Make sure that you delete the Cy_CapSense_ProcessAllWidgets API

```c
capsense_wear_detect_process_active_widgets_with_ktemp();

if (Cy_CapSense_IsAnyWidgetActive(&cy_capsense_context))
{
    capsense_state_timeout = ACTIVE_MODE_TIMEOUT;

```

2. Program the device

3. Make sure that **J6** is in the **USER BTN** configuration. Once the programming step has completed, hold both the reset button and the **USER BTN** down, and then release the reset button to force the calibration

> **Note:** Repeat this step any time the device is reprogrammed because the emulated EEPROM is erased during programming.

4. Generate a touch on the **CSB1** electrode and observe that the **LED3** is illuminated. Continue generating the touch while pressing and releasing the reset button. The **LED3** will turn off briefly while the device resets, but will turn back on as long as a touch (wear) is detected on the **CSB1** sensor

5. Open the **CAPSENSE&trade; Tuner** from the **ModusToolbox&trade; for VS Code extension**

<img src="assets/images/launching_capsense_tuner_from_modustoolbox_vscode_extension.png" alt="ModusToolbox for VS Code panel for launching the CAPSENSE Tuner" style="width:800px; height:auto; display:block; margin:0 auto;" />

6. Connect and begin streaming data from the device. You can generate a wear condition on the **CSB1** electrode, then touch the **CSB2** widget to observe the raw count on the **WearDetectSensor0** changing

<img src="assets/images/compensation_adjustment_in_tuner.png" alt="CAPSENSE Tuner showing temperature compensation adjustment measurements" style="width:1200px; height:auto; display:block; margin:0 auto;" />


7. Answer the guiding questions before proceeding:

* Why is `WEAR_DETECTION_TCCF` a negative value? What would happen to the compensated raw count if it were positive?
* Why does the compensation multiply the wear sensor's deviation `(raw - baseline)` by a ratio built from the reference sensor's own deviation, rather than multiplying the two raw counts directly?
* Why is the reference deviation applied as a multiplicative ratio instead of subtracting a fixed offset from the wear-sensor raw count?
* Why must `process_active_widgets_with_ktemp()` replace `Cy_CapSense_ProcessAllWidgets()` rather than run alongside it?
* Why is the adjusted raw count clamped to the valid sensor range before the baseline and difference counts are processed?

Reference implementation: [**main.c: final project**](../Lab_Solutions/lab_3_wear_detection/final_main_source_file/main.c)

### Optional challenge: measure the compensation

> **Challenge:** Measure how much the compensation actually moves the wear-sensor raw count. Unlike the power-on wear challenge, this one runs in normal operation, so you can watch the effect live in the **CAPSENSE&trade; Tuner** without resetting the device.
>
> The active-mode correction is:
>
> $$
> \mathrm{Adjusted\ Raw} = \mathrm{bsln} + (\mathrm{raw} - \mathrm{bsln}) \times \mathrm{Ktemp\text{-}ratio}
> $$
>
> $$
> \mathrm{Ktemp\text{-}ratio} = 1.0 + \mathrm{tccf} \times \frac{\mathrm{ref\_raw} - \mathrm{ref\_bsln}}{\mathrm{ref\_bsln}}
> $$
>
> For each trial, change `WEAR_DETECTION_TCCF`, reprogram, and stream in the Tuner. Record the **RefSensor0** raw count and baseline, then disturb the **CSB2** reference electrode and record how far the **WearDetectSensor0** raw count moves.

| Trial | `WEAR_DETECTION_TCCF` | Change from default | RefSensor0 deviation (`ref_raw - ref_bsln`) | WearDetectSensor0 raw before disturbing CSB2 | WearDetectSensor0 raw while disturbing CSB2 | Change in raw count | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | `0.0f` | Remove compensation entirely |  |  |  |  |  |
| 2 | `-0.10f` | Reduce magnitude |  |  |  |  |  |
| 3 | `-0.25f` | Project default, no change |  |  |  |  |  |
| 4 | `-0.50f` | Increase magnitude |  |  |  |  |  |
| 5 | `+0.25f` | Invert the sign |  |  |  |  |  |

Compare the measured change against the value predicted by the two equations above. Then answer:

* With `0.0f`, how much does the wear-sensor raw count move when only the reference electrode is disturbed?
* How does the measured change scale as the magnitude of the coefficient increases?
* With the sign inverted, does the reference disturbance get cancelled or amplified? Explain the result using the sign of the reference deviation.

> **Note:** A reference deviation is required for the compensation to do anything. If `ref_raw` equals `ref_bsln`, the ratio is exactly 1.0 and the raw count passes through unchanged regardless of the coefficient. Disturb **CSB2** while recording so that there is a deviation to compensate.

### Expected results

After programming the device, generate a wear condition on **CSB1**, begin streaming in the **CAPSENSE&trade; Tuner**, and touch the **CSB2** widget. Observe the **WearDetectSensor0** raw count while the reference sensor tracks the environmental change.

The power-on wear detection flow should produce the following results:

* When the reset button and **USER BTN** are held during reset, the firmware measures the **WearSensor0** and **RefSensor0** capacitance values and stores them as the calibration values in emulated EEPROM.
* On a subsequent startup, the firmware measures both sensors again, calculates the `RSCp-ratio` from the reference sensor, and applies it to the wear-sensor capacitance before making the wear decision.
* When the compensated wear-sensor capacitance is at or below the calibrated wear value plus the detection margin, the device proceeds to the low-power WOT state. After the initial baseline scan, it can enter normal active operation.
* When the compensated wear-sensor capacitance is above the calibrated wear value plus the detection margin, the device enters the `POWER_ON_WEAR` state. The **LED3** remains illuminated while the wear condition is detected.
* In the **CAPSENSE&trade; Tuner**, the wear sensor displays the adjusted capacitance, calibration baseline, and difference count. The reference sensor displays its current capacitance, calibrated baseline, and reference deviation.

The temperature reference compensation flow should produce the following results:

* During each active or ALR scan, the firmware reads the **RefSensor0** raw count and baseline before the reference-sensor baseline is updated.
* The firmware calculates `Ktemp-ratio` from the reference-sensor deviation and applies it to the **WearDetectSensor0** raw count relative to its baseline. The compensated raw count is clamped to the valid sensor range before difference counts and widget status are processed.
* When temperature or humidity changes affect both sensors, the reference sensor tracks the environmental change and the compensated wear-sensor difference count remains closer to its baseline. This reduces false DON and DOFF conditions caused by environmental drift.
* When you generate a wear condition on **CSB1**, the compensated **WearDetectSensor0** result still exceeds the configured detection threshold and the **LED3** illuminates.
* In the **CAPSENSE&trade; Tuner**, the **WearDetectSensor0** raw count, baseline, and difference count update as expected while the compensation is applied. The reference sensor values show the environmental deviation used to calculate `Ktemp-ratio`.

Reference implementation: [**main.c: final project**](../Lab_Solutions/lab_3_wear_detection/final_main_source_file/main.c)

## References

* [PSOC&trade; 4 and PSOC&trade; 6 MCU CAPSENSE&trade; design guide](https://www.infineon.com/assets/row/public/documents/30/42/infineon-an85951-psoc-4-psoc-6-capsense-design-guide-applicationnotes-en.pdf)
* [Wear Detection with PSOC&trade; 4 CAPSENSE&trade;](https://www.infineon.com/assets/row/public/documents/30/42/infineon-an241228-wear-detection-with-psoc-4-capsense-applicationnotes-en.pdf?fileId=8ac78c8c960edfb5019613297dbc231b)

## Revision History

| Date | Version | Description |
| --- | --- | --- |
|  |  | |

## Disclaimer

All referenced product or service names and trademarks are the property of their respective owners.

The Bluetooth&reg; word mark and logos are registered trademarks owned by Bluetooth SIG, Inc., and any use of such marks by Infineon is under license.

PSOC&trade;, formerly known as PSoC&trade;, is a trademark of Infineon Technologies. Any references to PSoC&trade; in this document or others shall be deemed to refer to PSOC&trade;.

---------------------------------------------------------

© Cypress Semiconductor Corporation, 2023-2026. This document is the property of Cypress Semiconductor Corporation, an Infineon Technologies company, and its affiliates ("Cypress").  This document, including any software or firmware included or referenced in this document ("Software"), is owned by Cypress under the intellectual property laws and treaties of the United States and other countries worldwide.  Cypress reserves all rights under such laws and treaties and does not, except as specifically stated in this paragraph, grant any license under its patents, copyrights, trademarks, or other intellectual property rights.  If the Software is not accompanied by a license agreement and you do not otherwise have a written agreement with Cypress governing the use of the Software, then Cypress hereby grants you a personal, non-exclusive, nontransferable license (without the right to sublicense) (1) under its copyright rights in the Software (a) for Software provided in source code form, to modify and reproduce the Software solely for use with Cypress hardware products, only internally within your organization, and (b) to distribute the Software in binary code form externally to end users (either directly or indirectly through resellers and distributors), solely for use on Cypress hardware product units, and (2) under those claims of Cypress's patents that are infringed by the Software (as provided by Cypress, unmodified) to make, use, distribute, and import the Software solely for use with Cypress hardware products.  Any other use, reproduction, modification, translation, or compilation of the Software is prohibited.
<br>
TO THE EXTENT PERMITTED BY APPLICABLE LAW, CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH REGARD TO THIS DOCUMENT OR ANY SOFTWARE OR ACCOMPANYING HARDWARE, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  No computing device can be absolutely secure.  Therefore, despite security measures implemented in Cypress hardware or software products, Cypress shall have no liability arising out of any security breach, such as unauthorized access to or use of a Cypress product. CYPRESS DOES NOT REPRESENT, WARRANT, OR GUARANTEE THAT CYPRESS PRODUCTS, OR SYSTEMS CREATED USING CYPRESS PRODUCTS, WILL BE FREE FROM CORRUPTION, ATTACK, VIRUSES, INTERFERENCE, HACKING, DATA LOSS OR THEFT, OR OTHER SECURITY INTRUSION (collectively, "Security Breach").  Cypress disclaims any liability relating to any Security Breach, and you shall and hereby do release Cypress from any claim, damage, or other liability arising from any Security Breach.  In addition, the products described in these materials may contain design defects or errors known as errata which may cause the product to deviate from published specifications. To the extent permitted by applicable law, Cypress reserves the right to make changes to this document without further notice. Cypress does not assume any liability arising out of the application or use of any product or circuit described in this document. Any information provided in this document, including any sample design information or programming code, is provided only for reference purposes.  It is the responsibility of the user of this document to properly design, program, and test the functionality and safety of any application made of this information and any resulting product.  "High-Risk Device" means any device or system whose failure could cause personal injury, death, or property damage.  Examples of High-Risk Devices are weapons, nuclear installations, surgical implants, and other medical devices.  "Critical Component" means any component of a High-Risk Device whose failure to perform can be reasonably expected to cause, directly or indirectly, the failure of the High-Risk Device, or to affect its safety or effectiveness.  Cypress is not liable, in whole or in part, and you shall and hereby do release Cypress from any claim, damage, or other liability arising from any use of a Cypress product as a Critical Component in a High-Risk Device. You shall indemnify and hold Cypress, including its affiliates, and its directors, officers, employees, agents, distributors, and assigns harmless from and against all claims, costs, damages, and expenses, arising out of any claim, including claims for product liability, personal injury or death, or property damage arising from any use of a Cypress product as a Critical Component in a High-Risk Device. Cypress products are not intended or authorized for use as a Critical Component in any High-Risk Device except to the limited extent that (i) Cypress's published data sheet for the product explicitly states Cypress has qualified the product for use in a specific High-Risk Device, or (ii) Cypress has given you advance written authorization to use the product as a Critical Component in the specific High-Risk Device and you have signed a separate indemnification agreement.
<br>
Cypress, the Cypress logo, and combinations thereof, ModusToolbox, PSoC, CAPSENSE, EZ-USB, F-RAM, and TRAVEO are trademarks or registered trademarks of Cypress or a subsidiary of Cypress in the United States or in other countries. For a more complete list of Cypress trademarks, visit www.infineon.com. Other names and brands may be claimed as property of their respective owners.




