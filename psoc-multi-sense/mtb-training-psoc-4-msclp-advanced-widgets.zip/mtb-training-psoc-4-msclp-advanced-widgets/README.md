# PSOC™ 4 E3 training - advanced CAPSENSE™ widgets

This training provides a deep dive into advanced widget tuning for PSOC™ 4 CAPSENSE™ designs.
The training includes hands-on labs, providing a great starting point to getting 
familiar with using these tests.

## Device family
- [PSOC™ 4](https://www.infineon.com/products/microcontroller/32-bit-psoc-arm-cortex/psoc-4-mcu)

## How to use this training?
1. Download the training [content](#content).
2. Review the presentation at your own pace.
3. Follow the step-by-step instructions in the training manual during the hands-on sections.
4. Use the provided source files if needed to verify the solution. 

## Training level
- E3: Advanced

## Pre-requisites 

### Training
- [PSOC™ 4 CAPSENSE™ using PSOC™ 4000T and PSOC™ 4100T Plus training](https://github.com/Infineon/mtb-training-psoc-4-msclp-capsense)

### Tools (see [training manual](#content) for versions and installation instructions)
- [ModusToolbox™ with Eclipse IDE](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup)
- [ModusToolbox™ Programming tools](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup)
- [ModusToolbox™ CAPSENSE™ and Multi-Sense Pack](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup)

See [training content](#content) for versions and instructions.

## Hardware
- [CY8CPROTO-040T](https://www.infineon.com/evaluation-board/CY8CPROTO-040T)
- [CY8CPROTO-041TP](https://www.infineon.com/evaluation-board/CY8CPROTO-041TP)

## Duration
- ~90 min video with hands-on labs

## Agenda
1. Deep-Dive into CAPSENSE™ sliders
2. Introduction to gestures on CAPSENSE™ sliders and touchpads
3. Lab 1: CAPSENSE™ sliders with gesture tuning
4. Lab 2: Enabling gestures on touchpads
5. Introduction to wear detection using CAPSENSE™
6. Lab 3: Configuring firmware for power on wear detection

## Expected outcome
- Get hands-on experience with the gestures on CAPSENSE™ sliders and touchpads
- Understand complexities of wear detection
- Dive deeper with challenges included for all labs

## Content
- [Presentation](./Presentation/PSOC(TM)%204%20CAPSENSE(TM)%20advanced%20widgets.pdf)
- [Training manual](./Manual/PSOC(TM)_4_advanced_CAPSENSE_widgets_training_manual.md)
- [Solution to labs](./Lab_Solutions/)

## References and resources
- [ModusToolbox™](https://www.cypress.com/products/modustoolbox)
- [PSOC™ 4 MCUs](https://www.infineon.com/products/microcontroller/32-bit-psoc-arm-cortex/psoc-4-mcu)
- [Introduction to PSOC™ MCUs and ModusToolbox™](https://www.infineon.com/product-information/psocdeveloper)
- [PSOC™ 4 and PSOC™ 6 MCU CAPSENSE™ design guide](https://www.infineon.com/assets/row/public/documents/30/42/infineon-an85951-psoc-4-psoc-6-capsense-design-guide-applicationnotes-en.pdf?fileId=8ac78c8c7cdc391c017d0723535d4661)
