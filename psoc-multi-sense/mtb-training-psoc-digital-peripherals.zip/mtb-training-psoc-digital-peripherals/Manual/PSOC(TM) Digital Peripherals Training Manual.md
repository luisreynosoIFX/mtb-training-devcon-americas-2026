# PSOC&trade; Digital Peripherals Training Manual

## About this document

This training manual covers the labs for the introduction to common peripherals available on PSOC&trade; 4,   
PSOC&trade; 6, and PSOC&trade; Edge microcontrollers.

## Scope and purpose

The training will cover project creation, GPIO control, UART and retarget-IO, SCBs, TCPWMs, interrupts, Systick, and WDT control using ModusToolbox&trade; and the device peripheral driver library (PDL).

## Intended audience

The intended audiences for this document are design engineers, technicians, and developers of electronic systems.

## Table of contents

* [Introduction](#introduction)
* [Required development tools and prerequisites](#required-development-tools-and-prerequisites)
* [Empty project creation and GPIO control](#empty-project-creation-and-gpio-control)
* [Serial Communication Block with UART](#serial-communication-block-with-uart)
* [Timer-counter PWMs](#timer-counter-pwms)
* [Use the EZI2C driver to communicate with an I2C host](#use-the-ezi2c-driver-to-communicate-with-an-i2c-host)
* [Serial Communication Block with SPI](#serial-communication-block-with-spi)
* [Watchdog timer](#watchdog-timer)
* [Appendix](#appendix)
* [References](#references)
* [Revision history](#revision-history)
* [Disclaimer](#disclaimer)

## Introduction

This manual provides instructions to create an empty project for PSOC&trade; devices. It will cover adding peripherals such as GPIOs, SCBs, TCPWMs, and WDT. It will also cover the use of peripheral driver libraries (PDL) and libraries like retarget-IO, which is used for debug print statements.

## Required development tools and prerequisites

### Tools

* **ModusToolbox™ software** v3.9 or later (Recommended installation via [ModusToolbox™ Setup tool](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup))
* [**Microsoft Visual Studio Code**](https://code.visualstudio.com/) with the [**ModusToolbox™ for VS Code**](https://marketplace.visualstudio.com/items?itemName=InfineonAG.modustoolbox-for-vscode) extension installed
* **ModusToolbox™ Programming Tools** v1.9.0 or later (Installed by [ModusToolbox™ Setup tool](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup) as a dependency to ModusToolbox™ v3.9)
* [**Serial Monitor for VS Code**](https://marketplace.visualstudio.com/items?itemName=ms-vscode.vscode-serial-monitor) extension installation is recommended to use serial terminal 
* [**PSoC&trade; Programmer**](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.psocprogrammer) for the **Bridge Control Panel**
* Supported evaluation kits:
	* [CY8CPROTO-040T-MS](https://www.infineon.com/evaluation-board/cy8cproto-040t-ms), the PSOC&trade; 4000T Multi-Sense Prototyping Kit
	* [CY8CPROTO-041TP](https://www.infineon.com/evaluation-board/CY8CPROTO-041TP), the PSOC&trade; 4100T Plus Prototyping Kit
	* [CY8CKIT-041S-MAX](https://www.infineon.com/evaluation-board/CY8CKIT-041S-MAX), the PSOC&trade; 4100S Max Pioneer Kit
	* [CY8CKIT-062S2-43012](https://www.infineon.com/evaluation-board/CY8CKIT-062S2-43012), the PSOC&trade; 6 Wi-Fi BT Pioneer Kit
	* [KIT\_PSE84\_EVAL](https://www.infineon.com/evaluation-board/kit-pse84-eval), the PSOC&trade; Edge E84 Evaluation Kit
* Jumper wires

## Empty project creation and GPIO control

### Objective

The objective of this lab is to cover how to use a GPIO as an output, input, and interrupt. The lab will cover the ModusToolbox&trade; software tools to generate a project, setup the device, and navigate to the peripheral driver layer (PDL) documentation.

### Description

The GPIO system on PSOC&trade; microcontrollers provides the interface between the CPU core and peripheral components to the outside world.

Figure 1 is a block diagram for a PSOC&trade; 4100T Plus GPIO. Most PSOC&trade; MCUs will have a similar GPIO block diagram, sharing concepts like the digital input and output paths, the analog path, and the high-speed I/O matrix. In the digital input path, the control registers are used to configure items like the buffer mode selection, the high-speed I/O matrix, and the interrupt logic. In the digital path, the control registers are used to configure items like drive mode, slew rate control, as well as HSIOM connections in the output direction. The analog path allows for some dedicated connections for analog resources like the SAR ADC and CAPSENSE&trade;. There are also some HSIOM options in the analog path enabled by analog mux buses that allow for a very high configurability of the analog peripherals to the GPIOs.

The high-speed I/O matrix allows for connections between GPIOs and many digital and analog peripherals. This matrix has restrictions, so it is critical to check the device’s datasheet for pin connections.

<img src="assets/images/psoc_4100t_plus_gpio_block_diagram.png" alt="PSOC 4100T Plus Gpio Block Diagram" style="width:600px; height:auto; display:block; margin:0 auto;" />


### Project creation

1. Before creating the first project in this training series, create the workspace. Open **VS Code** from the **Windows Start** menu
2. If you have not installed ModusToolbox&trade; along with the ModusToolbox&trade; for VS Code extension, see the Required development tools section

<img src="assets/images/running_vs_code_from_the_windows_11_search_bar.png" alt="Running Vs Code From The Windows 11 Search Bar" style="width:368px; height:auto; display:block; margin:0 auto;" />


3. Open a **workspace directory** for your project in VS Code

<img src="assets/images/opening_vs_code_workspace.png" alt="Opening Vs Code Workspace" style="width:466px; height:auto; display:block; margin:0 auto;" />


4. Click **File > Open Folder** and choose your workspace directory or create a new folder
5. Click **Select Folder** to open the workspace directory in VS Code

Note: Open the workspace in trusted mode. If the default workspace trust is restricted mode, click on **Restricted Mode** in botton left and change to trust this folder

<img src="assets/images/workspace_opened_in_restricted_mode.png" alt="Opening Vs Code Workspace" style="width:738px; height:auto; display:block; margin:0 auto;" />

<img src="assets/images/opening_workspace_in_trusted_mode.png" alt="Opening Vs Code Workspace" style="width:1200px; height:auto; display:block; margin:0 auto;" />

6. Open the **Command Palette** by pressing **Ctrl+Shift+P**
7. Search for **Infineon ModusToolbox&trade;: Show Main Page** and select by clicking
8. Clicking Show Main Page opens the **Infineon ModusToolbox&trade; for VS Code** main page 

<img src="assets/images/modustoolbox_for_vs_code_main_page.png" alt="Modustoolbox For Vs Code Main Page" style="width:1200px; height:auto; display:block; margin:0 auto;" />


9. Navigate to the **Create Project** tab and click **Launch Project Creation**
10. **Project Creator Tool** opens and prompts you to choose a **BSP** (Board Support Package)

BSPs are aligned with the development and evaluation kits; they provide files for basic device functionality. A BSP typically has a **design.modus** file that configures clocks and other board-specific capabilities. That file is used by the ModusToolbox&trade; configurators. A BSP also includes the required device support code for the device on the board. You can modify the configuration to suit your application

11. Once **Project Creator** launches, select the BSP for the evaluation kit you are using under the PSOC&trade; family of BSPs and click **Next**

<img src="assets/images/project_creator_bsp_selection.png" alt="Project Creator Bsp Selection" style="width:600px; height:auto; display:block; margin:0 auto;" />


12. Select the **Empty PSOCx App** under the Getting Started section. You can do this by selecting the checkbox near the application
13. Choose **Microsoft Visual Studio Code** from the **Target ID** dropdown list and click **Create**
14. Click **Load Project** in the VS Code prompt to load the project in the workspace 

<img src="assets/images/project_creator_example_code_project_creation_for_vs_code.png" alt="Project Creator Example Code Project Creation For Vs Code" style="width:600px; height:auto; display:block; margin:0 auto;" />


15. When you click **Create**, a new project is created, and you can see all the files in the Project Explorer window

<img src="assets/images/vs_code_after_project_creation.png" alt="Vs Code After Project Creation" style="width:1200px; height:auto; display:block; margin:0 auto;" />


> **Note:** If you are using a PSOC&trade; 6 evaluation kit, see the [appendix instructions to disable the HAL for PSOC&trade; 6 BSPs](#appendix-disable-hal-psoc-6)

> **Note:** If you are using a PSOC&trade; Edge evaluation kit, see the [appendix instructions to disable FreeRTOS for the PSOC&trade; Edge Empty Application](#appendix-disable-freertos-psoc-edge)

### GPIO control through the device configurator

When configuring a GPIO for a PSOC&trade; microcontroller, there are 3 main settings to consider: drive mode, input threshold, and output slew rate.

**Drive mode**: The 8 primary drive modes are shown here in their simplified output driver diagrams.

<img src="assets/images/simplified_gpio_output_driver_diagrams.png" alt="Simplified Gpio Output Driver Diagrams" style="width:600px; height:auto; display:block; margin:0 auto;" />


High-Z (high impedance) analog and digital are used when the GPIO is to be used as an input, analog or digital. Resistive modes provide a series resistance in one of the data states and a strong drive in the other, or in the pull-up and pull-down case, there is a series resistor in both data states. Open drain modes provide high-Z in one of the data states and strong drive in the other. The strong drive mode is the standard digital output mode for pins; it provides a strong CMOS output drive in both high and low states.

When using a GPIO as an input, the thresholds (Vih and Vil) are configurable by selecting the input buffer mode. The options are complementary metal-oxide-semiconductor (CMOS) or low-voltage transistor-transistor logic (LVTTL). Typically, CMOS input thresholds will be slightly lower than LVTTL thresholds. Most of the time, LVTTL inputs are only required when interfacing with circuits that require TTL compatibility.

The slew rate for a GPIO configured in strong drive mode is configurable. The default is a fast slew rate, but for certain circuits that require a slower slew rate, the configuration option is available.

1. Navigate to the **Application** tab, which contains the application information, tools, and API documentation. Click **Configure Device** to open the Device Configurator

<img src="assets/images/selecting_device_configurator_from_modustoolbox_for_vs_code_main_page.png" alt="Selecting Device Configurator From Modustoolbox For Vs Code Main Page" style="width:1200px; height:auto; display:block; margin:0 auto;" />


2. Navigate to the **Pins** tab and locate the port with pins used for LED control. This information can be found by searching through each port in the Device Configurator, or by reviewing the schematic for the evaluation kit used

<img src="assets/images/pins_tab_of_the_device_configurator.png" alt="Pins Tab Of The Device Configurator" style="width:1200px; height:auto; display:block; margin:0 auto;" />


3. Enable the GPIO by pressing the check box of the desired GPIO, then in the **Parameters** window on the right, adjust the **Drive Mode** to **Strong Drive. Input buffer on**. Most LEDs on PSOC&trade; evaluation kits will be active high, meaning setting the corresponding GPIO high will turn the LED on. This means the **Initial Drive State** should be set to **Low (0)** so that the LED only turns on once the code written in the following steps executes. Once the changes have been made, save them by pressing the save icon, or by pressing ctrl+s

<img src="assets/images/enabling_a_gpio_in_the_device_configurator_for_led_control.png" alt="Enabling A Gpio In The Device Configurator For Led Control" style="width:1200px; height:auto; display:block; margin:0 auto;" />


> Notice in the **Resource** window on the left, that the GPIO enabled has one or multiple aliases. This can be modified, or the default BSP aliases can be used. This alias will be used later when calling the API functions to set and clear the GPIO. Typically for evaluation kit BSPs, the LEDs will have an alias like **CYBSP\_LEDx** or **CYBSP\_USER\_LEDx**.

4. In the **Parameters** window, click **Configuration Help** to open the supporting documentation for the GPIO peripheral. It contains detailed information about the peripheral as well as API documentation for the PDL. Find the correct API to use for GPIO control

<img src="assets/images/configuration_help_in_parameter_window.png" alt="Configuration Help In Parameter Window" style="width:1200px; height:auto; display:block; margin:0 auto;" />

5. On the main GPIO window, under Modules, click **Functions**

<img src="assets/images/pdl_documentation_landing_site_for_the_gpio_peripheral.png" alt="Pdl Documentation Landing Site For The Gpio Peripheral" style="width:960px; height:auto; display:block; margin:0 auto;" />

6. Click **GPIO Functions**

<img src="assets/images/pdl_documentation_gpio_function_modules.png" alt="Pdl Documentation Gpio Function Modules" style="width:900px; height:auto; display:block; margin:0 auto;" />

7. Find the **Cy\_GPIO\_Set** and **Cy\_GPIO\_Clr**  functions

<img src="assets/images/pdl_documentation_gpio_functions.png" alt="Pdl Documentation Gpio Functions" style="width:1200px; height:auto; display:block; margin:0 auto;" />


7. For this lab, the **Cy\_GPIO\_Set** and **Cy\_GPIO\_Clr** functions will be used to set and clear the GPIO. Clicking these functions will navigate to more details on how to use them

<img src="assets/images/cy_gpio_set_api_documentation.png" alt="Cy Gpio Set Api Documentation" style="width:745px; height:auto; display:block; margin:0 auto;" />


8. Copy the line of code, navigate back to the VS Code and expand the **Empty\_PSOC4\_App** project. Then open the main.c file

<img src="assets/images/vs_code_view_with_main_c_open_for_empty_project.png" alt="Vs Code View With Main C Open For Empty Project" style="width:800px; height:auto; display:block; margin:0 auto;" />


9. Paste the **Cy\_GPIO\_Set** and **Cy\_GPIO\_Clr** APIs within the main.c for loop
10. Navigate back to the device configurator and find the alias for the LED to be controlled in the pins tab on the left panel. The alias will be in the **Name(s)** column of the table. When using the device configurator to enable a GPIO, a few behind-the-scenes items will occur
11. Definitions for the GPIO will be created, which can be used in user code. These definitions will include items like the **\_PORT**, **\_PIN**, **\_PORT\_NUM**, **\_DRIVEMODE**, **\_INIT\_DRIVESTATE**, and **\_HSIOM** (this is used to select the High-Speed I/O Matrix routing). These can be found in the code preview window on the right side of the device configurator
12. The GPIO will be initialised according to the settings selected in the Device Configurator. This will occur in the **cybsp\_init** function
13. If HAL is enabled, GPIO usage will be reserved. HAL will not be covered in this lab manual

<img src="assets/images/code_preview_for_alias_names_of_components.png" alt="Code Preview For Alias Names Of Components" style="width:1200px; height:auto; display:block; margin:0 auto;" />


14. The **Cy\_GPIO\_Set and Cy\_GPIO\_Clr** APIs require the pin **\_PORT** and **\_PIN** definitions. Use the alias with the added suffixes as inputs to those APIs. These macros can be found in the device configurator code preview window
15. A delay is needed so that the GPIO setting and clearing will blink the LED at a rate that is observable. This can be quickly accomplished by using a blocking delay function **Cy\_Syslib\_Delay**. This API is in the Syslib PDL, which can be found in the CAT2 Peripheral Driver Library documentation

<img src="assets/images/syslib_pdl_documentation.png" alt="Syslib Pdl Documentation" style="width:915px; height:auto; display:block; margin:0 auto;" />


16. Update the main.c for loop to switch the LED on and off every second by adding the following code

```c
for (;;)
{
	Cy_GPIO_Set(CYBSP_LED2_PORT, CYBSP_LED2_PIN);	
	Cy_SysLib_Delay(1000);
	Cy_GPIO_Clr(CYBSP_LED2_PORT, CYBSP_LED2_PIN);
	Cy_SysLib_Delay(1000);
}
```

17. Program the device by navigating to the Application tab, pressing **Program** button and observing the LED blinking

<img src="assets/images/programming_the_device_from_the_application_tab.png" alt="Programming The Device From The Application Tab" style="width:1200px; height:auto; display:block; margin:0 auto;" />


### GPIO control through only the Peripheral Driver Library (PDL)

An alternative to using the device configurator to set up a GPIO for application use is to use the middleware libraries for setup and control. Using the steps found in GPIO control through the device configurator, the PDL documentation can be found. In this documentation the APIs to configure and control GPIOs can be found.

All GPIOs not configured by the device configurator follow the device default configuration. This is typically a high-Z analog drive mode, CMOS input buffer, fast slew rate, and no internal connections. This means that to use a GPIO as an output, the only setting that must be changed is the drive mode.

1. Navigate to the corresponding evaluation kit user guide to find the pins used for the LEDs
2. Set the drive mode to strong output

```c
#define NEW_LED_PORT	GPIO_PRT5
#define NEW_LED_PIN		(4u)
{
	cy_rslt_t result;    
	/* Initialize the device and board peripherals */
	result = cybsp_init() ;
	if (result != CY_RSLT_SUCCESS)
	{
		CY_ASSERT(0);
	}
	
	Cy_GPIO_SetDrivemode(NEW_LED_PORT, NEW_LED_PIN, CY_GPIO_DM_STRONG);
```

3. Control the GPIO output with the \_Set and \_Clr APIs

```c
for (;;)
{
	Cy_GPIO_Set(CYBSP_LED2_PORT, CYBSP_LED2_PIN);	
	Cy_GPIO_Clr(NEW_LED_PORT, NEW_LED_PIN);
	Cy_SysLib_Delay(1000);
	Cy_GPIO_Clr(CYBSP_LED2_PORT, CYBSP_LED2_PIN);
	Cy_GPIO_Set(NEW_LED_PORT, NEW_LED_PIN);
	Cy_SysLib_Delay(1000);
}
```

4. Program the device and observe the two LEDs blinking

### Reading a GPIO input

When configuring a GPIO as an input, there are a few things to consider.

* What is driving the signal into the microcontroller?
* When configured for digital input, a GPIO is a high-Z input, meaning that if not pulled or driven to a potential (VDD or GND), the input will generally be at some value in between. This means that the microcontroller will read a ‘1’ (high) or ‘0’ (low) at random
* If the driving circuit is an open-drain circuit, then the opposite direction of the open drain should be pulled to a specific potential. For example, if a circuit is an open-drain drive low, then a pull-up should be added either externally, or the resistive pull-up drive mode should be used so that an internal pull-up resistor is enabled
* As noted in the description of PSOC&trade; GPIOs here, the input threshold of a digital input is configurable, and when connecting the microcontroller to a circuit that requires TTL-compliant inputs, the input threshold should be set to LVTTL
* As the input to a GPIO is transitioning from HIGH to LOW or LOW to HIGH, it may pass the threshold multiple times

<img src="assets/images/switch_bounce.png" alt="Switch Bounce" style="width:390px; height:auto; display:block; margin:0 auto;" />


* Depending on the implementation, a debounce algorithm may need to be implemented in software

1. Navigate to the Device Configurator to configure a GPIO for digital input by changing the drive mode to **Resistive Pull-Up, Input buffer on** and ensure that the initial drive state is **High (1)**

> **Note:** typically for evaluation kit BSPs, the user button will be labelled as **“CYBSP\_USER\_BTNx**”

<img src="assets/images/configuring_a_gpio_for_digital_input_in_the_device_configurator.png" alt="Configuring A Gpio For Digital Input In The Device Configurator" style="width:1200px; height:auto; display:block; margin:0 auto;" />

> **Note:** On the PSOC&trade; 4000T Multi-Sense Kit (CY8CPROTO-040T-MS), the LED2 and user button pins are multiplexed through J6. The code for controlling LED2 must be removed.

2. Save and close the Device Configurator
3. Find the **CY\_GPIO\_Read** API in the PDL documentation. The function requires the GPIO port base address and pin number
4. Add the if statement into the main function for loop to poll the GPIO and only toggle the GPIOs while the button is not pressed

```c
for (;;)
{
	if (1UL == Cy_GPIO_Read(CYBSP_USER_BTN1_PORT, CYBSP_USER_BTN1_PIN))
	{
		Cy_GPIO_Set(CYBSP_LED2_PORT, CYBSP_LED2_PIN);	
		Cy_GPIO_Clr(NEW_LED_PORT, NEW_LED_PIN);
		Cy_SysLib_Delay(1000);
		Cy_GPIO_Clr(CYBSP_LED2_PORT, CYBSP_LED2_PIN);
		Cy_GPIO_Set(NEW_LED_PORT, NEW_LED_PIN);
		Cy_SysLib_Delay(1000);
	}
	else
	{
		Cy_GPIO_Clr(NEW_LED_PORT, NEW_LED_PIN);
		Cy_GPIO_Clr(CYBSP_LED2_PORT, CYBSP_LED2_PIN);
	}
}    
```

5. Program the device and observe the two LEDs blinking, and then press and hold the user button to turn the LEDs off

> **Note:** on the PSOC&trade; 4100S Max kit (CY8CKIT-041S-MAX), the LEDs are active low, meaning that driving the pin low causes the LED to turn on. This means that using the code found for this lab will cause the LED behavior to be inverted from the other kits.

### Interrupt on a GPIO

Using a GPIO as an input has considerations like debounce, threshold settings, and static level control, depending on the type of source driving the signal. When using a GPIO input as an interrupt, some other items should be considered.

* PSOC&trade; GPIOs can be used to detect the rising, falling, or both edges of a signal as it transitions

<img src="assets/images/gpio_edges.png" alt="Gpio Edges" style="width:922px; height:auto; display:block; margin:0 auto;" />


* Debouncing this signal may be required as the edge may be detected multiple times as the signal transitions from LOW to HIGH or HIGH to LOW
* Interrupt priority should also be considered
* The interrupt could be indicating a very high or a very low priority event. The ARM Nested Vectored interrupt controller on PSOC&trade; MCUs will service high-priority interrupts before low-priority interrupts. Also, if a low-priority interrupt is being serviced when a high-priority interrupt occurs, the NVIC will suspend the low-priority ISR and transfer control to the higher-priority ISR

1. Navigate to the Device Configurator to configure a GPIO for a rising edge interrupt
2. Some PSOC&trade; BSPs will have multiple buttons. If they do, and they are enabled by default, the interrupt trigger type for the other buttons may be enabled. Please disable the other button interrupts

<img src="assets/images/rising_edge_interrupt.png" alt="Rising Edge Interrupt" style="width:1200px; height:auto; display:block; margin:0 auto;" />


3. Save and close the Device Configurator
4. Go to the Applications tab on the ModusToolbox&trade; for VS Code main page. Select the project section Empty_PSOC4_App, or the project name you created and find all the project related documentation, middleware and tools in this section
5. Open the PDL library documentation main page under the project documentation and navigate to the **SysInt** PDL documentation

<img src="assets/images/application_tab_project_documentations_middleware_and_tools.png" alt="application tab project documentations middleware and tools" style="width:1200px; height:auto; display:block; margin:0 auto;" />

<img src="assets/images/sysint_pdl_documentation.png" alt="Sysint Pdl Documentation" style="width:1200px; height:auto; display:block; margin:0 auto;" />


6. Before we initialize the interrupt, we need to create an interrupt service routine (ISR)

```c
static bool enable_blink = false;

void button_isr(void)
{
	enable_blink ^= 1;
	Cy_GPIO_ClearInterrupt(CYBSP_USER_BTN1_PORT, CYBSP_USER_BTN1_PIN);
}
```

This ISR toggles a Boolean value, then clears the interrupt for the corresponding GPIO.

7. Initialize the SysInt for the corresponding GPIO

```c
cy_stc_sysint_t intrCfg = 
{
	/*.intrSrc =*/ CYBSP_USER_BTN1_IRQ,
	/*.intrPriority =*/ 3UL 
};
Cy_SysInt_Init(&intrCfg, button_isr);

/* Enable the interrupt */
NVIC_EnableIRQ(intrCfg.intrSrc);
```

8. For CAT1 devices like PSOC6 and PSOC&trade; Edge, an interrupt mask may be needed for the interrupt to work properly. See the PDL documentation and look for **Cy\_GPIO\_SetInterruptMask**
9. Update the main function for the loop to use the **enable\_blink** Boolean value

```c
for (;;)
{
	if (1UL == enable_blink)
	{
		Cy_GPIO_Set(CYBSP_LED2_PORT, CYBSP_LED2_PIN);	
		Cy_GPIO_Clr(NEW_LED_PORT, NEW_LED_PIN);
		Cy_SysLib_Delay(1000);
		Cy_GPIO_Clr(CYBSP_LED2_PORT, CYBSP_LED2_PIN);
		Cy_GPIO_Clr(NEW_LED_PORT, NEW_LED_PIN);
		Cy_SysLib_Delay(1000);
	}
	else
	{
		Cy_GPIO_Clr(NEW_LED_PORT, NEW_LED_PIN);
		Cy_GPIO_Clr(CYBSP_LED2_PORT, CYBSP_LED2_PIN);
	}
}    
```

10. Program the device and note that the LEDs are not blinking, then press the button and observe the LEDs blinking

### Conclusion

The final state of this lab should enable 3 GPIOs, two should be set to outputs for LED control, and the third should be an input used to trigger an interrupt. The interrupt on the user button is used to control whether the LEDs are blinking.

> **Note:** The LEDs configured here (CYBSP_LED2 / CYBSP_USER_LED1, and CYBSP_USER_LED2 via NEW_LED_PORT/PIN) are reused later in the Timer-counter PWMs lab (timer_isr toggles CYBSP_USER_LED1). If working through both labs in the same project, the button-driven blink code from this lab must be removed before adding the TCPWM timer_isr, or the two ISRs will fight over the same GPIO.

## Serial Communication Block with UART

### Objective

The objective of this lab is to demonstrate how to enable a serial communication block, SCB, using the device configurator and the peripheral driver library. The retarget-I/O middleware will also be enabled to showcase easier debugging with standard C libraries like printf.

### Description

The serial communication block on PSOC&trade; devices is a highly configurable digital communication interface. It can be used to enable a universal asynchronous receiver/transmitter interface. This lab will cover setup, sending data, receiving data with a polling and an interrupt-driven method, and the retarget-I/O middleware.

* Adding a UART SCB
* Receiving data from UART
* Enabling interrupts for UART
* Enabling retarget-IO middleware

The Universal Asynchronous Receiver/Transmitter (UART) protocol is an asynchronous serial interface protocol. UART communication is typically point-to-point. The UART interface consists of two signals, the transmitter output (TX) and the receiver input (RX). The serial communication blocks on PSOC&trade; devices can be used as a UART controller, supporting multiple protocols, data frame sizes, programmable number of stop bits, parity support, programmable oversampling, start skipping, and hardware flow control (CTS and RTS).

<img src="assets/images/uart_example.png" alt="Uart Example" style="width:600px; height:auto; display:block; margin:0 auto;" />


A typical UART transfer consists of a start bit followed by multiple data bits, optionally followed by a parity bit, and finally completed by one or more stop bits. The start and stop bits indicate the start and end of data transmission. The parity bit is sent by the transmitter and is used by the receiver to detect single-bit errors. Because the interface does not have a clock (asynchronous), the transmitter and receiver use their own clocks; thus, the transmitter and receiver need to agree on the baud rate.

<img src="assets/images/uart_standard_protocol_example.png" alt="Uart Standard Protocol Example" style="width:600px; height:auto; display:block; margin:0 auto;" />


Most PSOC&trade; SCBs can support alternative UART modes like Smartcard reader, IrDA, and LIN. Those modes will not be covered in this lab.

### Adding a UART SCB

1. Use the project created in the first exercise, or follow those instructions to create a new project
2. After opening the project, navigate to the ModusToolbox&trade; for VS Code main page and click **Configure Device**. Navigate to the **Peripherals** tab and enable the SCB associated with the board's UART port. Typically, the alias name is pre-filled as **CYBSP\_UART**. If no alias is pre-filled, see the evaluation kit user manual to determine which pins connect to the KitProg for UART, and then determine which SCB is associated with those pins

<img src="assets/images/enable_scb_as_a_uart_interface_in_the_device_configurator.png" alt="Enable Scb As A Uart Interface In The Device Configurator" style="width:987px; height:auto; display:block; margin:0 auto;" />

3. Enable SCB as a UART interface in the Device Configurator
4. The settings can be configured in the parameters window on the right side of the device configurator
5. Standard mode, with a baud rate of 115200, LSB first bit order, 8 bits of data, no parity, and 1 stop bit
6. A clock will need to be supplied. PSOC&trade; microcontrollers have many configurable peripheral clocks. You can pick any unused clock divider, and the configurator will set it up for the chosen baud rate. Confirm that the **Baud Rate Accuracy %** is below 2%
7. Select the appropriate GPIOs for RX and TX. The configuration will configure these correctly if it is not used previously. If they were enabled previously in the pins tab, then proceed to the next step to configure them correctly

<img src="assets/images/configure_the_scb_settings_for_debug_uart.png" alt="Configure The Scb Settings For Debug Uart" style="width:1200px; height:auto; display:block; margin:0 auto;" />

8. Configure the SCB settings for Debug UART
9. Navigate to the Pins tab and ensure that the RX pin is set to Digital High-Z. Set the input buffer to on and the TX pin to Strong Drive. Set the input buffer to off

<img src="assets/images/configure_the_rx_gpio_drive_mode.png" alt="Configure The Rx Gpio Drive Mode" style="width:1200px; height:auto; display:block; margin:0 auto;" />


<img src="assets/images/configure_the_tx_gpio_drive_mode.png" alt="Configure The Tx Gpio Drive Mode" style="width:1200px; height:auto; display:block; margin:0 auto;" />


10. Save the device configurator, but keep it open so that the code preview for the UART SCB can be viewed
11. Navigate to the PDL documentation for the SCB in UART mode. Find the **Cy\_SCB\_UART\_Init**, **Cy\_SCB\_UART\_Enable**, and **Cy\_SCB\_UART\_PutString** APIs

> **Note:** PDL documentation shows how to create the config structure, but the device configurator generates the structure automatically when it is saved. To get started, only the **Cy\_SCB\_UART\_Init**, **Cy\_SCB\_UART\_Enable**, and **Cy\_SCB\_UART\_PutString** APIs will be needed as the device configurator will generate and invoke the other needed setup code, including the GPIO initialization and the peripheral clock initialization.

12. Add the required code to enable the SCB and send the first message

```c
Cy_SCB_UART_Init(CYBSP_UART_HW, &CYBSP_UART_config, NULL);

/* Enable global interrupts */
__enable_irq();

Cy_SCB_UART_Enable(CYBSP_UART_HW);
Cy_SCB_UART_PutString(CYBSP_UART_HW, "Hello PSOC\r\n");
```

13. In VS Code, the serial monitor extension must be installed to use serial terminal, alternatively use external tool as serial terminal
14. Once installed, open the serial monitor by navigating to the Serial Monitor tab in the output window at the bottom of the IDE

<img src="assets/images/opening_a_new_serial_monitor_in_vs_code.png" alt="Opening A New Serial Monitor In Vs Code" style="width:1200px; height:auto; display:block; margin:0 auto;" />


15. Select the serial port corresponding with your evaluation kit and configure the terminal

<img src="assets/images/configuring_the_serial_monitor_option.png" alt="Configuring The Serial Monitor Option" style="width:1090px; height:auto; display:block; margin:0 auto;" />


16. Program the device

> **Note:** on the PSOC&trade; 4000T multi-sense kit (CY8CKIT-040T-MS), the SW2 must be in the “**UART**” position

17. Navigate to the new terminal and observe the output

<img src="assets/images/output_of_the_program_to_the_terminal_for_scb_uart_pdl_put_string_vs_code.png" alt="Output Of The Program To The Terminal For Scb Uart Pdl Put String Vs Code" style="width:999px; height:auto; display:block; margin:0 auto;" />


### Receiving data from UART

Most terminals will not echo data typed into them by default. This means that when sending characters to a device using a serial terminal, the user won’t get instant feedback that what they have sent has been received by the device. Let’s read data from the UART RX FIFO and print it back out to the terminal so that the user can see what they have typed in real time and see that the device has received the character.

1. Navigate back to the SCB UART PDL documentation and find the **Cy\_SCB\_UART\_Get**, **Cy\_SCB\_UART\_GetNumInRxFifo**, and **Cy\_SCB\_UART\_ClearRxFifo** APIs
2. The **Cy\_SCB\_UART\_Get** API is a non-blocking function to retrieve data from the SCB FIFO. If the FIFO is empty, the **Get** API returns 0xFFFFFFFF. Check the number of bytes in the FIFO by invoking the **Cy\_SCB\_UART\_GetNumInRxFifo** API before calling the **Get** API. Echo each character, checking for carriage returns to add a new line command. After processing the FIFO, clear it with **Cy\_SCB\_UART\_ClearRxFifo**
3. Update the main for loop in the main function to poll the FIFO status, read the data, then echo the data back

```c
	uint32_t char_received;
for (;;)
{
	uint32_t data_count = Cy_SCB_UART_GetNumInRxFifo(CYBSP_UART_HW);

	for (uint32_t i = 0; i < data_count; i++)
	{
		char_received = (uint32_t)Cy_SCB_UART_Get(CYBSP_UART_HW);
		
		Cy_SCB_UART_Put(CYBSP_UART_HW, char_received);

		/* If the char_received is a carriage return "\r", then add in a new line "\n". */
		if (13 == (char) char_received)
		{
			Cy_SCB_UART_Put(CYBSP_UART_HW, 10);
		}
	}

	if (0UL < data_count)
	{
		Cy_SCB_UART_ClearRxFifo(CYBSP_UART_HW);
	}
}
```

4. Program the device and observe the output. As you enter new characters, they will be echoed back on the terminal

<img src="assets/images/output_of_program_to_terminal_for_polled_echoes_vs_code.png" alt="Output Of Program To Terminal For Polled Echoes Vs Code" style="width:1092px; height:auto; display:block; margin:0 auto;" />


### Enabling interrupts for UART

A more efficient approach is to leverage UART interrupts to handle character reception. This eliminates the need to poll for data and ensures that characters are processed as soon as they are received.

1. Create a UART ISR to read a character from the RX FIFO and put it back on the TX FIFO

```c
void uart_isr(void)
{
	uint32_t interrupt_status = Cy_SCB_GetRxInterruptStatusMasked(CYBSP_UART_HW);

	if (interrupt_status & CY_SCB_RX_INTR_NOT_EMPTY)
	{
		char char_received = Cy_SCB_UART_Get(CYBSP_UART_HW);

		Cy_SCB_UART_Put(CYBSP_UART_HW, char_received);
	
		/* If the char_received is a carriage return "\r", then add in a new line "\n" */
		if (13 == char_received)
		 {
			Cy_SCB_UART_Put(CYBSP_UART_HW, 10);
		}

		Cy_SCB_ClearRxInterrupt(CYBSP_UART_HW, CY_SCB_RX_INTR_NOT_EMPTY);
	}
}
```

> **Note:** the ISR gets the interrupt status, then checks that the **RX\_INTR\_NOT\_EMPTY** interrupt is set, then uses the **Cy\_SCB\_UART\_Get** API to read a byte from the RX FIFO. Then it puts the read byte onto the TX FIFO using **Cy\_SCB\_UART\_Put** API. It does a check to see if a carriage return was received, and if so, it sends out a new line character. Then, before leaving the ISR, it clears the interrupt.

2. Enable the interrupt in the main function

```c
/* Enable global interrupts */
__enable_irq();

cy_stc_sysint_t uart_intr_cfg = {
	CYBSP_UART_IRQ,
	3U,
};

Cy_SysInt_Init(&uart_intr_cfg, uart_isr);
NVIC_EnableIRQ(uart_intr_cfg.intrSrc);

Cy_SCB_SetRxInterruptMask(CYBSP_UART_HW, CY_SCB_RX_INTR_NOT_EMPTY);

Cy_SCB_UART_Enable(CYBSP_UART_HW);
Cy_SCB_UART_PutString(CYBSP_UART_HW, "Echo with intterupts\r\n");

```

3. Remove all the code from the main function for loop
4. Program the device and observe the output. As you enter new characters, they will be echoed back on the terminal

<img src="assets/images/output_of_program_to_terminal_for_interrupt_driven_echoes_vs_code.png" alt="Output Of Program To Terminal For Interrupt Driven Echoes Vs Code" style="width:1091px; height:auto; display:block; margin:0 auto;" />


### Enabling retarget-IO middleware

Printing messages to a serial terminal emulator window on a computer is a common use case for UART (e.g. for printing debug messages). ModusToolbox&trade; provides a library called retarget-io to simplify the process by retargeting the standard inputs and outputs to the SCB UART target. This allows you to use standard C functions such as printf for printing messages over UART.

To use the retarget-io library to print messages, the steps are:

1. Open the library manager by clicking the **Configure middleware** in the ModusToolbox&trade; for VS Code main page

<img src="assets/images/library_manager.png" alt="Library Manager" style="width:600px; height:auto; display:block; margin:0 auto;" />


2. Use the search bar to find retarget, select the check box, and click **OK**

<img src="assets/images/adding_the_retarget_io_library.png" alt="Adding The Retarget Io Library" style="width:600px; height:auto; display:block; margin:0 auto;" />

3. The library will be added to the project libraries. To update the project, press **Update** and wait for it to be complete, then close the library manager
4. Navigate to the retarget-IO documentation

<img src="assets/images/retarget_io_documentation_for_use_with_pdls.png" alt="Retarget Io Documentation For Use With Pdls" style="width:1200px; height:auto; display:block; margin:0 auto;" />


5. Remove all source code relating to the interrupts from the previous lab step, then add in the source code shown below

> **Note:** See the [appendix instructions for using the MTB-HAL for PSOC&trade; Edge devices](#appendix-psoc-edge-mtb-hal)

```c
#include "cy_retarget_io.h"

int main(void)
{
	cy_rslt_t result;
	/* Initialize the device and board peripherals */
	result = cybsp_init() ;
	if (result != CY_RSLT_SUCCESS)
	{
		CY_ASSERT(0);
	}

	Cy_SCB_UART_Init(CYBSP_UART_HW, &CYBSP_UART_config, NULL);

	/* Enable global interrupts */
	__enable_irq();

	Cy_SCB_UART_Enable(CYBSP_UART_HW);

	cy_retarget_io_init(CYBSP_UART_HW);

	printf("Hello from retarget-IO\r\n");

```

6. Program the device
7. Observe the new output in the terminal

<img src="assets/images/output_of_the_program_to_the_terminal_vs_code.png" alt="Output Of The Program To The Terminal Vs Code" style="width:1088px; height:auto; display:block; margin:0 auto;" />


### Conclusion

This lab demonstrated how to enable a UART interface using the device configurator and the PDL libraries, as well as how to enable the retarget-IO library for routing standard C printf functions to the UART interface for easier debug messaging.

## Timer-counter PWMs

### Objective

The objective of this lab is to demonstrate how to enable and configure the TCPWM blocks for different use cases, from a simple timer to signal duty cycle measurement.

### Description

The TCPWM or Timer - Counter - Pulse Width Modulator is a highly configurable peripheral that can interface with other hardware blocks like GPIOs, intelligent analog blocks, DMA, SCBs, and SMART-I/O. PSOC&trade; MCUs typically come with multiple TCPWM blocks. Depending on the device, there may be 8-, 16-, or 32-bit TCPWMs. The labs will cover enabling and configuring the TCPWM block to accomplish some common application use cases for the block.

* Timer-compare counter
* PWM
* Timer-capture for event counting
* Timer-capture for event measuring

> **Note:** only the timer-compare counter and PWM labs steps are supported on the PSOC&trade; 4000T multi-sense kit (CY8CKIT-040T-MS), as that device only has two TCPWM counters. The TCPWM counters on that device support the functionality shown in the event counting and event measuring labs, but the steps described in these labs require four TCPWM counters.

> **Note:** If reusing the same project from the GPIO control lab, remove the button_isr/enable_blink blink-loop code before adding timer_isr below — both drive CYBSP_USER_LED1/CYBSP_LED2 and will conflict.

### Timer-compare counter

The timer functionality increments or decrements a counter between 0 and the value stored in the PERIOD register. When the counter is running, the count value stored in the COUNTER register is compared with the compare/capture register (CC). When the counter changes from a state in which COUNTER equals CC, the cc\_match event is generated. This event can be used to generate an interrupt.

<img src="assets/images/timer_in_up_counting_continuous_mode.png" alt="Timer In Up Counting Continuous Mode" style="width:800px; height:auto; display:block; margin:0 auto;" />


The counter increments on every pulse of the input clock. When using continuous mode, the counter will increment until the count reaches the value in the PERIOD register. Once the counter reaches the value in the COMPARE register, an event is generated, which can be configured as an interrupt. By adjusting the input clock, PERIOD, and COMPARE registers, a timer can be generated that fires an interrupt at a set period. This can be used for tasks like time keeping, triggering time-sensitive events, and more.

Let’s create a timer that generates an interrupt every second. We will use this interrupt to toggle a GPIO in the application code.

1. The project created in the first exercise can be used, or the instructions shown there can be used to create a new project
2. Once the project has been opened, navigate to the application tab and click configure device. Navigate to the **Peripherals** tab and enable a **TCPWM 16-bit Counter** by toggling the checkbox, selecting the **Counter** personality, then pressing OK

<img src="assets/images/enable_tcpwm_16_bit_counter_in_the_device_configurator.png" alt="Enable Tcpwm 16 Bit Counter In The Device Configurator" style="width:872px; height:auto; display:block; margin:0 auto;" />

3. Rename the alias of the block to **TIMER** so that the following code matches the alias
4. Configure the TCPWM for **Compare**, set the **Period** and **Compare** values, select **Compare and Capture** as the interrupt source, and select a **Clock Signal**

<img src="assets/images/configure_the_tcpwm_16_bit_counter_in_the_device_configurator_as_a_compare_timer.png" alt="Configure The Tcpwm 16 Bit Counter In The Device Configurator As A Compare Timer" style="width:419px; height:auto; display:block; margin:0 auto;" />


5. Create a timer that triggers every second. The peripheral clock input must allow the compare interrupt to trigger every second, so set the clock signal to 32 kHz. Navigate to the **Peripheral-Clocks** tab, open the clock signal selected for the TCPWM instance, and adjust it to 32 kHz

<img src="assets/images/configure_the_peripheral_clock_to_meet_the_timing_requirements_of_the_timer.png" alt="Configure The Peripheral Clock To Meet The Timing Requirements Of The Timer" style="width:1200px; height:auto; display:block; margin:0 auto;" />


6. Save the device configurator
7. Navigate back to the **Peripherals** tab, click on the TCPWM that you enabled, then open the documentation link found at the top of the Parameters tab
8. Navigate to the **Functions** module and click on the **Cy\_TCPWM\_Counter\_Init** function and observe the **Function Usage**
9. The device configurator has created the config structure, an alias for the **TCPWM\_Type** base, the **NUM**, and **MASK** definitions. Copy the functions shown here into your main function before the **enable\_irq** function, but after the **cybsp\_init** function, and modify the inputs to match the generated source from the device configurator

**For PSOC&trade; 4 and PSOC&trade; 6:**

```c
if (CY_TCPWM_SUCCESS != Cy_TCPWM_Counter_Init(TIMER_HW, TIMER_NUM, &TIMER_config))
{
	/* Handle possible errors */
}
/* Enable the initialized counter */
Cy_TCPWM_Counter_Enable(TIMER_HW, TIMER_NUM);

/* Then start the counter */
Cy_TCPWM_TriggerStart(TIMER_HW, TIMER_MASK);

```

**For PSOC&trade; Edge:**

```c
if (CY_TCPWM_SUCCESS != Cy_TCPWM_Counter_Init(TIMER_HW, TIMER_NUM, &TIMER_config))
{
	/* Handle possible errors */
}
/* Enable the initialized counter */
Cy_TCPWM_Counter_Enable(TIMER_HW, TIMER_NUM);

/* Then start the counter */
Cy_TCPWM_TriggerStart_Single(TIMER_HW, TIMER_NUM);
```

10. In the TCPWM configuration, we enabled compare and capture interrupts, so let’s add the source code to enable an ISR for the interrupt. Navigate back to the PDL documentation and find the SysInt libraries. We will need to set up the config structure for the interrupt, pass the ISR, and enable the interrupt

```c
cy_stc_sysint_t timer_intr_cfg =
{
	/*.intrSrc =*/ TIMER_IRQ,
	/*.intrPriority =*/ 3UL 
};
Cy_SysInt_Init(&timer_intr_cfg, timer_isr);
/* Enable the interrupt */
NVIC_EnableIRQ(timer_intr_cfg.intrSrc);
```

11. The ISR function must clear the interrupt source. The TCPWM PDL has an API to get and clear interrupts for the block

```c
void timer_isr(void)
{
	Cy_TCPWM_ClearInterrupt(TIMER_HW, TIMER_NUM, 
		Cy_TCPWM_GetInterruptStatus(TIMER_HW, TIMER_NUM));

}
```

12. The last step is to enable a GPIO that is connected to an LED. The steps in the GPIO lab for GPIO control can be used to configure the pin, then the Cy\_GPIO\_Inv API can be used to toggle the GPIO. Add that to the TCPWM ISR

```c
void timer_isr(void)
{
	Cy_GPIO_Inv(CYBSP_USER_LED1_PORT, CYBSP_USER_LED1_PIN);
	Cy_TCPWM_ClearInterrupt(TIMER_HW, TIMER_NUM, 
		Cy_TCPWM_GetInterruptStatus(TIMER_HW, TIMER_NUM));
}
```

13. Program the device and observe the LED blinking every second

### PWM

The PWM can output left, right, centre, or asymmetrically aligned PWM. The PWM signal is generated by incrementing or decrementing a counter between 0 and PERIOD and comparing the counter value COUNTER with CCx. When COUNTER equals CCx, the ccx\_match event is generated. The pulse-width modulated signal is then generated by using the ccx\_match event along with overflow and underflow events. The ccx\_match event used for PWM generation is dictated by the compare swap feature. When the compare swap value is set to 0, the cc0\_match event is used; when it is set to 1, the cc1\_match event is used. Two pulse-width modulated signals, “line\_out” and “line\_compl\_out”, are output from the PWM.

<img src="assets/images/tcpwm_used_for_pwm_generation_on_line_out.png" alt="Tcpwm Used For Pwm Generation On Line Out" style="width:673px; height:auto; display:block; margin:0 auto;" />


By changing the PERIOD and COMPARE (CCx) registers, the frequency and duty cycle of the PWM can be adjusted.

In this portion of the lab, we will add another TCPWM counter to generate a PWM on a GPIO connected to an LED on the evaluation kit.

1. Navigate to the pins tab of the device configurator
2. Find a user LED GPIO and enable it, then connect the internal **Digital Output** connection to a TCPWM counter

LED GPIO used for the PWM output (also referenced later in the event counting/measuring sub-labs)

|  |  |
| --- | --- |
| Evaluation Kit | LED GPIO |
| CY8CPROTO-041TP | P5.6 |
| CY8CKIT-041S-MAX | P6.4 |
| CY8CKIT-062S2-43012 | P11.1 |
| KIT\_PSE84\_EVAL | P16.6 |

> **Note:** if this pin is already in use by another lab in the same project (for example, the user button on CY8CPROTO-041TP also uses P5.6), pick a different available LED GPIO and confirm in Device Configurator's Pins tab which TCPWM counter line/line_compl output actually routes to it before writing code that toggles the same pin elsewhere.

3. Set the pin's **Drive Mode** to **Strong Drive** (input buffer off). Newly-enabled pins default to High-Z Analog, which will not toggle even though the TCPWM PWM signal is routed to it

<img src="assets/images/gpio_configuration_for_use_with_tcpwm_block_as_pwm_line.png" alt="Gpio Configuration For Use With Tcpwm Block As Pwm Line" style="width:1200px; height:auto; display:block; margin:0 auto;" />


4. Navigate to the Peripherals tab, set the alias of the TCPWM counter associated with the GPIO that was just enabled to PWM and enable it by toggling the check box, selecting the PWM personality, then click OK

<img src="assets/images/enabling_the_tcpwm_counter_for_the_associated_gpio.png" alt="Enabling The Tcpwm Counter For The Associated Gpio" style="width:1098px; height:auto; display:block; margin:0 auto;" />


5. Configure the TCPWM to generate a 5 Hz PWM with a 50% duty cycle. Using the same peripheral clock divider as the previously enabled TIMER, which is running at 32 KHz. Set the period to 6400 and set the compare half of that to achieve the 50% duty cycle. The frequency of the PWM is 32 KHz divided by the period (6400), which is 5 Hz

<img src="assets/images/tcpwm_configuration_for_5_hz_pwm_with_a_50_duty_cycle.png" alt="Tcpwm Configuration For 5 Hz Pwm With A 50 Duty Cycle" style="width:605px; height:auto; display:block; margin:0 auto;" />


> **Note:** on some evaluation kits, the LEDs used may need to be modified from the instructions in the lab manual. For example, the PSOC&trade; 4100S Max kit (CY8CKIT-041S-MAX) is configured such that LED2 is associated with the TCPWM counter 6. Also, some kits will have LEDs associated with TCWPM PWM\_N lines. This will also work, but the duty cycle will be inverted.

6. Save the device configurator settings
7. Open the PWM (TCPWM) Documentation and find the Cy\_TCPWM\_PWM\_INIT API documentation
8. Use the functions to initialize, enable, and start the PWM. In step 4, the alias of the TCPWM counter was set to **PWM**. Add the code to the main function before the **enable\_irq** function call

**For PSOC&trade; 4 and 6:**

```c
if (CY_TCPWM_SUCCESS != Cy_TCPWM_PWM_Init(PWM_HW, PWM_NUM, &PWM_config))
{
	/* Handle possible errors */
}    
/* Enable the initialized counter */
Cy_TCPWM_PWM_Enable(PWM_HW, PWM_NUM);
/* Then start the counter */
Cy_TCPWM_TriggerReloadOrIndex(PWM_HW, PWM_MASK);
```

**For PSOC&trade; Edge:**

```c
if (CY_TCPWM_SUCCESS != Cy_TCPWM_PWM_Init(PWM_HW, PWM_NUM, &PWM_config))
{
	/* Handle possible errors */
}    
/* Enable the initialized counter */
Cy_TCPWM_PWM_Enable(PWM_HW, PWM_NUM);
/* Then start the counter */
Cy_TCPWM_TriggerStart_Single(PWM_HW, PWM_NUM);
```

9. Build and program the device. Observe the first LED blinking every second as the timer enabled is still running, and the second LED is blinking at a 5 Hz rate
10. Adjust the period or duty cycle of the PWM using the **Cy\_SetPeriod0** and **Cy\_SetCompare0** APIs

### Timer-capture for event counting

When the count input is configured as rising/falling the count value is changed on each prescaled clk\_counter edge in which an edge is detected on the count input. Using this capability the number of pulses on a GPIO can be counted. If this count is measured over a set period of time, the frequency of the pulses can be measured.

In the following steps, we will add another TCPWM that monitors the pulses of the PWM (Falling Edge) with the count input.

1. Navigate to the **Peripherals** tab of the device configurator
2. Set the alias for another TCPWM counter to **EVENT\_COUNTER** and enable it by toggling the checkbox, then selecting **Counter** as the personality and click OK

<img src="assets/images/enabling_the_tcpwm_pwm_event_counter.png" alt="Enabling The Tcpwm Pwm Event Counter" style="width:886px; height:auto; display:block; margin:0 auto;" />


3. Using the same peripheral clock as the timer and PWM and a period of 32000, the TCPWM counter will count events on a given GPIO and store them in the counter register. Configure the Count Signal for Falling Edge and select an available GPIO

<img src="assets/images/tcpwm_pwm_event_counter_configuration_in_the_device_configurator.png" alt="Tcpwm Pwm Event Counter Configuration In The Device Configurator" style="width:618px; height:auto; display:block; margin:0 auto;" />


4. Configure the Count Signal GPIO, including setting the pin alias to FEEDBACK\_PIN

<img src="assets/images/count_signal_gpio_configuration_and_alias.png" alt="Count Signal Gpio Configuration And Alias" style="width:1200px; height:auto; display:block; margin:0 auto;" />


5. Save the device configurator settings
6. Open the **Timer – Counter (TCPWM) Documentation**, navigate to **Common → Functions**, and review **Cy\_TCWPM\_Enable\_Multiple** and **Cy\_TCWPM\_TriggerReloadOrIndex**. These APIs allow user code to enable and start multiple TCPWM counters by using aliased masks. Use them to enable and start all TCPWM counters in this project. These APIs are available only for PSOC&trade; 4 and PSOC&trade; 6
7. Add the initialization, enable, and start APIs for the new TCPWM block, aliased as **EVENT\_COUNTER**

**For PSOC&trade; 4:**

```c
if (CY_TCPWM_SUCCESS != Cy_TCPWM_Counter_Init(EVENT_COUNTER_HW, EVENT_COUNTER_NUM, &EVENT_COUNTER_config))
{
	/* Handle possible errors */
}	
/* Enable the initialized counters */
Cy_TCPWM_Enable_Multiple(PWM_HW, TIMER_MASK | PWM_MASK | EVENT_COUNTER_MASK);
/* Then start the counters */
Cy_TCPWM_TriggerReloadOrIndex(PWM_HW, TIMER_MASK | PWM_MASK | EVENT_COUNTER_MASK);
```

**For PSOC&trade; 6:**

PSOC&trade; 6 uses a second TCPWM block because the counter input required for this configuration is not available on the first block. Enable and start the second block separately.

```c
if (CY_TCPWM_SUCCESS != Cy_TCPWM_Counter_Init(EVENT_COUNTER_HW, EVENT_COUNTER_NUM, &EVENT_COUNTER_config))
{
	/* Handle possible errors */
}	
/* Enable the initialized counters */
Cy_TCPWM_Enable_Multiple(PWM_HW, TIMER_MASK | PWM_MASK | EVENT_COUNTER_MASK);
Cy_TCPWM_Enable_Multiple(EVENT_COUNTER_HW, EVENT_COUNTER_MASK);
/* Then start the counters */
Cy_TCPWM_TriggerReloadOrIndex(PWM_HW, TIMER_MASK | PWM_MASK | EVENT_COUNTER_MASK);
Cy_TCPWM_TriggerReloadOrIndex(EVENT_COUNTER_HW, EVENT_COUNTER_MASK);
```

**For PSOC&trade; Edge:**

```c
if (CY_TCPWM_SUCCESS != Cy_TCPWM_Counter_Init(EVENT_COUNTER_HW, EVENT_COUNTER_NUM, &EVENT_COUNTER_config))
{
	/* Handle possible errors */
}	
/* Enable the initialized counter */
Cy_TCPWM_Counter_Enable(EVENT_COUNTER_HW, EVENT_COUNTER_NUM);
/* Then start the counter */
Cy_TCPWM_TriggerStart_Single(EVENT_COUNTER_HW, EVENT_COUNTER_NUM);
```

1. Ensure that the previously used start/reload APIs are removed as they will be enabled and started with this new method
2. Do this only for PSOC&trade; 4 and PSOC&trade; 6
3. As the LED GPIO may not be readily available on some evaluation kit headers without rework, another PWM output can be enabled on a pin available. See Table 1 to find the appropriate GPIO

<img src="assets/images/enable_a_second_pwm_output_from_the_same_tcpwm_counter.png" alt="Enable A Second Pwm Output From The Same Tcpwm Counter" style="width:1180px; height:auto; display:block; margin:0 auto;" />

4. Enable a second PWM output from the same TCPWM counter
5. A jumper wire is needed to connect the PWM to be measured and the input to the capture. Connect either the LED GPIO or the second PWM GPIO to the capture GPIO using a jumper wire
6. PWM signal to capture input connection options

|  |  |  |  |
| --- | --- | --- | --- |
| Evaluation Kit | LED GPIO | Second PWM GPIO | Counter GPIO |
| CY8CPROTO-041TP | P5.6 | P4.0 | P4.1 |
| CY8CKIT-041S-MAX | P6.4 | P1.4 | P1.2 |
| CY8CKIT-062S2-43012 | P11.1 | P10.7 | P9.0 |
| KIT\_PSE84\_EVAL | P16.6 | P13.6 | P11.1 |

8. Using the steps here, add a UART SCB to enable printing information to a terminal

> **Note:** it’s best that the TCPWMs and the UART don’t share a peripheral clock, as the UART peripheral uses the peripheral clock to configure the baud rate

9. Add the stdio.h include to the main.c file

```c
#include <stdio.h>
```

10. Add a Boolean flag variable in the timer\_isr to indicate that the timer has expired

```c
volatile bool timer_flag = false;
void timer_isr(void)
{
	timer_flag = true;
	Cy_GPIO_Inv(CYBSP_USER_LED2_PORT, CYBSP_USER_LED2_PIN);
	Cy_TCPWM_ClearInterrupt(TIMER_HW, TIMER_NUM,
		Cy_TCPWM_GetInterruptStatus(TIMER_HW, TIMER_NUM));
}
```

11. In the infinite for loop of the main function, check that this flag has been set, if it has, clear the flag, then read the EVENT\_COUNTER count value and print it to the terminal

```c
for (;;)
{
	if (true == timer_flag)
	{
		timer_flag = false;
		char print[8];
		uint32_t event_count = Cy_TCPWM_Counter_GetCounter(EVENT_COUNTER_HW, EVENT_COUNTER_NUM);
		Cy_TCPWM_Counter_SetCounter(EVENT_COUNTER_HW, EVENT_COUNTER_NUM, 0);
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "******************************************************************\n\r");
		sprintf(print, "%u\r\n", event_count);
		Cy_SCB_UART_PutString(CYBSP_UART_HW, print);
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "******************************************************************\n\r");
	}
}
```

12. Program the device, open a terminal and observe the output

<img src="assets/images/output_of_the_counter_vs_code.png" alt="Output Of The Counter Vs Code" style="width:1092px; height:auto; display:block; margin:0 auto;" />

13. The TCPWM counter is counting 5 falling edge events every second; this means that the signal is operating at a 5 Hz rate. We can use other PDL APIs to determine this frequency, independent of clock and period changes that may be made to the TCPWM counter
14. **Cy\_TCPWM\_Counter\_GetPeriod**: This API returns the period of the TCPWM counter
15. **Cy\_SysClk\_PeriphGetAssignedDivider**: This API returns the divider assigned to the peripheral. On PSOC&trade; 4 the format returned shows the divider type and number, where bits [7:6] = type, and bits[5:0] = divider number within that type. On PSOC&trade; 6 and PSOC&trade; Edge, the format returned shows the divider type and number, where bits [9:8] = type, and bits [7:0] = divider number within that type. It accepts an enumeration of possible peripheral clock assignments. The input enumeration is dependent on the device
16. **Cy\_SysClk\_PeriphGetFrequency**: This API returns the frequency of the peripheral clock
17. Let’s add a function to print a float value

```c
void print_float(float value) 
{
	char print_float[20];
	int int_part = (int)value; /* Integer part */ 
	int frac_part = (int)((value - int_part) * 100); /* Fractional part (2 decimal places) */
	sprintf(print_float, "%d.%02d", int_part, frac_part);
	Cy_SCB_UART_PutString(CYBSP_UART_HW, print_float);
}
```

18. Update the for loop in the main function to calculate and print the signal frequency

**For PSOC&trade; 4:**

```c
/* Get the TCPWM counter period. */
uint32_t counter_period = Cy_TCPWM_Counter_GetPeriod(EVENT_COUNTER_HW, EVENT_COUNTER_NUM);
/* Get the clock divider type and number. */
uint32_t clock_divider = Cy_SysClk_PeriphGetAssignedDivider(PCLK_TCPWM_CLOCKS1);
uint32_t divider_type = (clock_divider&PERI_PCLK_CTL_SEL_TYPE_Msk)>>PERI_PCLK_CTL_SEL_TYPE_Pos;
uint32_t divider_number = (clock_divider&PERI_PCLK_CTL_SEL_DIV_Msk)>>PERI_PCLK_CTL_SEL_DIV_Pos;
/* To divide the TCPWM clock by 1 requires the pre-scaler register to be set to 0, so add 1 to the pre-scaler. */
uint32_t prescaler = TIMER_config.clockPrescaler + 1U;
/* Determine the frequency of the clock driving the TCPWM counter. */
uint32_t clock_frequency = Cy_SysClk_PeriphGetFrequency(divider_type, divider_number)/prescaler;
/* Determine the period in seconds of the TCPWM counter. */
float counter_time = (1/(float)clock_frequency)*(float)counter_period;
for (;;)
{
	if (true == timer_flag)
	{
		timer_flag = false;
		uint32_t event_count = Cy_TCPWM_Counter_GetCounter(EVENT_COUNTER_HW, EVENT_COUNTER_NUM);
		Cy_TCPWM_Counter_SetCounter(EVENT_COUNTER_HW, EVENT_COUNTER_NUM, 0);
		
		float signal_frequency = (float)event_count/counter_time;
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "******************************************************************\n\r");
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "Signal Frequency = ");
		print_float(signal_frequency);
		Cy_SCB_UART_PutString(CYBSP_UART_HW, " hz \r\n");
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "******************************************************************\n\r");
	}
}
```

**For PSOC&trade; 6:**

```c
/* Get the TCPWM counter period. */
uint32_t counter_period = Cy_TCPWM_Counter_GetPeriod(EVENT_COUNTER_HW, EVENT_COUNTER_NUM);
/* Get the clock divider type and number. */
uint32_t clock_divider = Cy_SysClk_PeriphGetAssignedDivider(PCLK_TCPWM1_CLOCKS0);
uint32_t divider_type = (clock_divider&CY_PERI_CLOCK_CTL_TYPE_SEL_Msk)>>CY_PERI_CLOCK_CTL_TYPE_SEL_Pos;
uint32_t divider_number = (clock_divider&CY_PERI_CLOCK_CTL_DIV_SEL_Msk)>> CY_PERI_CLOCK_CTL_DIV_SEL_Pos;
/* To divide the TCPWM clock by 1 requires the pre-scaler register to be set to 0, so add 1 to the pre-scaler. */
uint32_t prescaler = TIMER_config.clockPrescaler + 1U;
/* Determine the frequency of the clock driving the TCPWM counter. */
uint32_t clock_frequency = Cy_SysClk_PeriphGetFrequency(divider_type, divider_number)/prescaler;
/* Determine the period in seconds of the TCPWM counter. */
float counter_time = (1/(float)clock_frequency)*(float)counter_period;
for (;;)
{
	if (true == timer_flag)
	{
		timer_flag = false;
		uint32_t event_count = Cy_TCPWM_Counter_GetCounter(EVENT_COUNTER_HW, EVENT_COUNTER_NUM);
		Cy_TCPWM_Counter_SetCounter(EVENT_COUNTER_HW, EVENT_COUNTER_NUM, 0);
		
		float signal_frequency = (float)event_count/counter_time;
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "******************************************************************\n\r");
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "Signal Frequency = ");
		print_float(signal_frequency);
		Cy_SCB_UART_PutString(CYBSP_UART_HW, " hz \r\n");
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "******************************************************************\n\r");
	}
}
```

**For PSOC&trade; Edge:**

```c
/* Get the TCPWM counter period. */
uint32_t counter_period = Cy_TCPWM_Counter_GetPeriod(EVENT_COUNTER_HW, EVENT_COUNTER_NUM);
/* Get the clock divider type and number. */
uint32_t clock_divider = Cy_SysClk_PeriphGetAssignedDivider(PCLK_TCPWM0_CLOCK_COUNTER_EN2);
uint32_t divider_type = (clock_divider&CY_PERI_CLOCK_CTL_TYPE_SEL_Msk)>>CY_PERI_CLOCK_CTL_TYPE_SEL_Pos;
uint32_t divider_number = (clock_divider&CY_PERI_CLOCK_CTL_DIV_SEL_Msk)>> CY_PERI_CLOCK_CTL_DIV_SEL_Pos;
/* To divide the TCPWM clock by 1 requires the pre-scaler register to be set to 0, so add 1 to the pre-scaler. */
uint32_t prescaler = TIMER_config.clockPrescaler + 1U;
/* Determine the frequency of the clock driving the TCPWM counter. */
uint32_t clock_frequency = Cy_SysClk_PeriphGetFrequency(divider_type, divider_number)/prescaler;
/* Determine the period in seconds of the TCPWM counter. */
float counter_time = (1/(float)clock_frequency)*(float)counter_period;
for (;;)
{
	if (true == timer_flag)
	{
		timer_flag = false;
		uint32_t event_count = Cy_TCPWM_Counter_GetCounter(EVENT_COUNTER_HW, EVENT_COUNTER_NUM);
		Cy_TCPWM_Counter_SetCounter(EVENT_COUNTER_HW, EVENT_COUNTER_NUM, 0);
		
		float signal_frequency = (float)event_count/counter_time;
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "******************************************************************\n\r");
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "Signal Frequency = ");
		print_float(signal_frequency);
		Cy_SCB_UART_PutString(CYBSP_UART_HW, " hz \r\n");
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "******************************************************************\n\r");
	}
}
```

> **Note:** the **PCLK\_TCPWM\_CLOCKSx** will vary based on the TCPWM block used for the event counter.

19. Program the device and observe the output in the terminal

<img src="assets/images/terminal_output_of_the_signal_frequency_vs_code.png" alt="Terminal Output Of The Signal Frequency Vs Code" style="width:1113px; height:auto; display:block; margin:0 auto;" />


### Timer-capture for event measuring

The capture functionality increments/decrements a counter between 0 and PERIOD. When the capture event is activated, the counter value COUNTER is copied to CC (and CC is copied to CC\_BUFF). The capture event can be triggered through the capture trigger input or through a firmware write to the command register.

In the figure below, the capture is set up for a rising edge event. When the capture occurs, the COUNTER is copied into the CC register. It will be copied into the CC\_BUFF register at the next event.

<img src="assets/images/terminal_output_of_the_signal_frequency_2.png" alt="Terminal Output Of The Signal Frequency 2" style="width:848px; height:auto; display:block; margin:0 auto;" />


In this portion of the lab, we will add a TCPWM capture to track how long a pulse is. This can be used to determine the duty cycle of a signal.

1. Navigate to the **Peripherals** tab of the device configurator
2. Set the alias for another TCPWM counter to **CAPTURE** and enable it by toggling the checkbox, selecting **Counter** as the personality, and click OK

<img src="assets/images/enabling_the_tcpwm_capture_in_the_device_configurator.png" alt="Enabling The Tcpwm Capture In The Device Configurator" style="width:866px; height:auto; display:block; margin:0 auto;" />


3. Using the same peripheral clock as the previous TCPWM counters and a period of 32000, the TCPWM counter in capture mode can generate an interrupt on the capture of a signal edge

> **Note:** Device Configurator exposes two separate, similarly-named input parameters for a Counter personality — **Count Signal** and **Capture Signal**. It is easy to configure the wrong one. For this CAPTURE counter, leave **Count Signal** at its default (internal peripheral clock, not routed to an external pin) so the counter free-runs as a time base. It is **Capture Signal** that must be routed to `FEEDBACK_PIN` with a **Both/Either Edge** trigger. If Count Signal is routed to `FEEDBACK_PIN` instead of Capture Signal, the code will build and run without error, but the capture interrupt never fires — `capture_result_high`/`capture_result_low` stay at 0, and the printed duty cycle silently reads **0%** instead of raising any error. Meanwhile the Signal Frequency measurement (driven separately by EVENT_COUNTER/TIMER) still reports correctly, which makes this mistake easy to miss.

<img src="assets/images/tcpwm_pwm_capture_configuration_in_the_device_configurator.png" alt="Tcpwm Pwm Capture Configuration In The Device Configurator" style="width:621px; height:auto; display:block; margin:0 auto;" />


4. Save the device configurator settings
5. Initialize, enable, and start the TCPWM counter in the main function of the project

**For PSOC&trade; 4:**

```c
if (CY_TCPWM_SUCCESS != Cy_TCPWM_Counter_Init(CAPTURE_HW, CAPTURE_NUM, &CAPTURE_config))
{
	/* Handle possible errors */
}	
/* Enable the initialized counters */
Cy_TCPWM_Enable_Multiple(PWM_HW, TIMER_MASK | PWM_MASK | EVENT_COUNTER_MASK | CAPTURE_MASK);
/* Then start the counters */
Cy_TCPWM_TriggerReloadOrIndex(PWM_HW, TIMER_MASK | PWM_MASK | EVENT_COUNTER_MASK | CAPTURE_MASK);
```

**For PSOC&trade; 6:**

```c
if (CY_TCPWM_SUCCESS != Cy_TCPWM_Counter_Init(CAPTURE_HW, CAPTURE_NUM, &CAPTURE_config))
{
	/* Handle possible errors */
}
/* Enable the initialized counters */
Cy_TCPWM_Enable_Multiple(PWM_HW, TIMER_MASK | PWM_MASK);
Cy_TCPWM_Enable_Multiple(EVENT_COUNTER_HW, EVENT_COUNTER_MASK | CAPTURE_MASK);
/* Then start the counters */
Cy_TCPWM_TriggerReloadOrIndex(PWM_HW, TIMER_MASK | PWM_MASK );
Cy_TCPWM_TriggerReloadOrIndex(EVENT_COUNTER_HW, EVENT_COUNTER_MASK | CAPTURE_MASK);
```

**For PSOC&trade; Edge:**

```c
if (CY_TCPWM_SUCCESS != Cy_TCPWM_Counter_Init(CAPTURE_HW, CAPTURE_NUM, &CAPTURE_config))
{
	/* Handle possible errors */
}
/* Enable the CAPTURE counter */
Cy_TCPWM_Counter_Enable(CAPTURE_HW, CAPTURE_NUM);
/* Then start the counter */
Cy_TCPWM_TriggerStart_Single(CAPTURE_HW, CAPTURE_NUM);
```

6. Initialize a SysInt for the capture TCPWM

```c
cy_stc_sysint_t capture_intr_cfg = 
{
	/*.intrSrc =*/ CAPTURE_IRQ,
	/*.intrPriority =*/ 3UL 
};
Cy_SysInt_Init(&capture_intr_cfg, capture_isr);
/* Enable the interrupt */
NVIC_EnableIRQ(capture_intr_cfg.intrSrc);
```

7. Add the ISR

```c
volatile bool capture_flag = false;
void capture_isr(void)
{
	capture_flag = true;
	Cy_TCPWM_ClearInterrupt(CAPTURE_HW, CAPTURE_NUM, Cy_TCPWM_GetInterruptStatus(CAPTURE_HW, 													CAPTURE_NUM));
}
```

8. Update the main function
9. Add two new variables

```c
int main(void)
{
	cy_rslt_t result;
	uint32_t capture_result_high = 0;
	uint32_t capture_result_low = 0;
```

10. Service the **capture\_flag** in the for loop of the main function

```c
if (true == capture_flag)
{
	capture_flag = false;
	if (0UL == Cy_GPIO_Read(FEEDBACK_PIN_PORT, FEEDBACK_PIN_PIN))
	{
		capture_result_low = Cy_TCPWM_Counter_GetCaptureBuf(CAPTURE_HW, CAPTURE_NUM);
	}
	else {
		capture_result_high = Cy_TCPWM_Counter_GetCaptureBuf(CAPTURE_HW, CAPTURE_NUM);
	}
	Cy_TCPWM_Counter_SetCounter(CAPTURE_HW, CAPTURE_NUM, 0);
}
```

11. Calculate and print out the duty cycle of the signal

```c
for (;;)
{
	if (true == timer_flag)
	{
		timer_flag = false;
		uint32_t event_count = Cy_TCPWM_Counter_GetCounter(EVENT_COUNTER_HW, EVENT_COUNTER_NUM);
		uint32_t counter_period = Cy_TCPWM_Counter_GetPeriod(EVENT_COUNTER_HW, EVENT_COUNTER_NUM);
		uint32_t clock_divider = Cy_SysClk_PeriphGetAssignedDivider(PCLK_TCPWM_CLOCKS1);
		uint32_t clock_frequency = Cy_SysClk_PeriphGetFrequency((clock_divider>>6 & 0x03), (clock_divider&0x3F));
		float counter_time = (1/(float)clock_frequency)*(float)counter_period;
		float signal_frequency = (float)event_count/counter_time;
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "******************************************************************\n\r");
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "Signal Frequency = ");
		print_float(signal_frequency);
		Cy_SCB_UART_PutString(CYBSP_UART_HW, " hz \r\n");
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "Signal Duty Cycle =  ");
		print_float(((float)capture_result_high * 100)/((float)capture_result_low + (float)capture_result_high-1));
		Cy_SCB_UART_PutString(CYBSP_UART_HW, " % \r\n");
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "******************************************************************\n\r");
	}
```

12. Program the device and observe the terminal output

<img src="assets/images/terminal_output_with_duty_cycle_measurement_added_vs_code.png" alt="Terminal Output With Duty Cycle Measurement Added Vs Code" style="width:821px; height:auto; display:block; margin:0 auto;" />


13. Now we can modify the PWM duty cycle in the user code

```c
for (;;)
{
	if (true == timer_flag)
	{
		timer_flag = false;
		uint32_t event_count = Cy_TCPWM_Counter_GetCounter(EVENT_COUNTER_HW, EVENT_COUNTER_NUM);
		uint32_t counter_period = Cy_TCPWM_Counter_GetPeriod(EVENT_COUNTER_HW, EVENT_COUNTER_NUM);
		uint32_t clock_divider = Cy_SysClk_PeriphGetAssignedDivider(PCLK_TCPWM_CLOCKS1);
		uint32_t clock_frequency = Cy_SysClk_PeriphGetFrequency((clock_divider>>6 & 0x03), (clock_divider&0x3F));
		float counter_time = (1/(float)clock_frequency)*(float)counter_period;
		float signal_frequency = (float)event_count/counter_time;
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "******************************************************************\n\r");
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "Signal Frequency = ");
		print_float(signal_frequency);
		Cy_SCB_UART_PutString(CYBSP_UART_HW, " hz \r\n");
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "Signal Duty Cycle =  ");
		print_float(((float)capture_result_high * 100)/((float)capture_result_low + (float)capture_result_high-1));
		Cy_SCB_UART_PutString(CYBSP_UART_HW, " % \r\n");
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "******************************************************************\n\r");
		uint32_t pwm_period = Cy_TCPWM_PWM_GetPeriod0(PWM_HW, PWM_NUM);
		uint32_t pwm_compare = Cy_TCPWM_PWM_GetCompare0(PWM_HW, PWM_NUM) + 100;
		if (pwm_period > pwm_compare)
		{
			Cy_TCPWM_PWM_SetCompare0(PWM_HW, PWM_NUM, pwm_compare+100);
		}
		else
		{
			Cy_TCPWM_PWM_SetCompare0(PWM_HW, PWM_NUM, 100);
		}
	}
```

14. Program the device and observe the terminal output with the variable PWM duty cycle

<img src="assets/images/terminal_output_with_a_variable_duty_cycle_vs_code.png" alt="Terminal Output With A Variable Duty Cycle Vs Code" style="width:820px; height:auto; display:block; margin:0 auto;" />


### Conclusion

This lab demonstrated how to enable and configure the TCPWM counter for different use cases using the ModusToolbox&trade; device configurator and the accompanying PDL library documentation. You should now be able to use the TCPWM counter peripheral to create simple timers, generate PWM signals, count and measure events.

## Use the EZI2C driver to communicate with an I2C host

### Objective

The objective of this lab is to communicate with an I2C host using the EZI2C driver for the PSOC&trade; serial communication block (SCB).

### Description

The serial communication block can be configured as an I2C host or an I2C slave. Using the EZI2C slave peripheral driver, an application can be developed quickly. The trainee will learn how to enable the Systick timer to tick every 1 ms, configure a SCB for EZI2C slave mode, update the read buffer, and act upon data written.

* Enabling EZI2C slave peripheral
* Updating the EZI2C buffer with Systick up time
* Controlling an LED using an I2C write command

The standard I2C bus is a two-wire interface with a serial data (SDA) line and a serial clock (SCL) line. I2C devices are connected to these lines using open collector or open-drain output stages, with pull-up resistors (Rp). A simple master/slave relationship exists between devices. Masters and slaves can operate as either transmitter or receiver. Each slave device connected to the bus is software addressable by a unique 7-bit address.

<img src="assets/images/master_write_data_transfer.png" alt="Master Write Data Transfer" style="width:751px; height:auto; display:block; margin:0 auto;" />


<img src="assets/images/master_read_data_transfer.png" alt="Master Read Data Transfer" style="width:752px; height:auto; display:block; margin:0 auto;" />


The EZI2C driver provided by Infineon adds a protocol on top of I2C slaves that allows a master to have random access to a block of memory on the EZI2C slave (a.k.a. a data buffer). The EZI2C component can be configured to have either 1 or 2 bytes of address offset (also called the sub-address). The default is 1 byte, which means the data buffer can be up to 256 bytes. The first byte (or first two bytes if configured for a 2-byte offset) sent by the master in a write sequence is an offset that specifies which location in the buffer to start from. The offset will also be used in any following read sequences.

This protocol is very common and it (or one very similar to it) is used by most memory devices that are accessed using I2C.

<img src="assets/images/ezi2c_example_with_8_bit_sub_addressing.png" alt="Ezi2c Example With 8 Bit Sub Addressing" style="width:600px; height:auto; display:block; margin:0 auto;" />


### Enabling EZI2C slave peripheral

1. Use the project created in the first exercise, or follow those instructions to create a new project
2. After opening the project, navigate to the **Application** tab in the ModusToolbox&trade; for VS Code main page and click **Configure Device**. Navigate to the **Peripherals** tab and enable an SCB for **EZI2C** that is connected to the KitProg on the evaluation kit you are using

SCB associated with KitProg

|  |  |  |  |
| --- | --- | --- | --- |
| Evaluation Kit | SCB | SDA GPIO | SCL GPIO |
| CY8CPROTO-041TP | SCB1 | P6.4 | P6.3 |
| CY8CKIT-040T | SCB1 | P2.3 | P2.2 |
| CY8CKIT-041S-MAX | SCB0 | P1.1 | P1.0 |
| CY8CKIT-062S2-43012 | SCB3 | P6.1 | P6.0 |
| KIT\_PSE84\_EVAL | SCB0 | P8.1 | P8.0 |

<img src="assets/images/enabling_a_psoc_scb_for_ezi2c_mode.png" alt="Enabling A PSOC Scb For Ezi2c Mode" style="width:868px; height:auto; display:block; margin:0 auto;" />


3. Configure the clock signal to the peripheral, the SCL, and the SDA pins

<img src="assets/images/configuring_the_ezi2c_parameters.png" alt="Configuring The Ezi2c Parameters" style="width:622px; height:auto; display:block; margin:0 auto;" />


4. Save the device configurator
5. Open the **EZI2C (SCB) Documentation** and locate the documentation for APIs relating to initialising the interface, setting the buffer, initialising the interrupt, and enabling the interface
6. Let’s add those APIs to the main function
7. The device configurator generates the EZI2C configuration structure used with the **Cy\_SCB\_EZI2C\_Init** API, so only the API needs to be copied into the main function after the cybsp\_init function call and after the enable\_irq function call
8. Next, we will set the buffer for the peripheral to use for reads and writes initiated by the I2C master. We want the entire buffer to be readable and writable, so the **Cy\_SCB\_EZI2C\_SetBuffer1** input **rwBoundary** will be the same as the buffer size
9. The **SysInt** interrupt must be configured with the accompanying ISR
10. Lastly, the SCB must be enabled with the **Cy\_SCB\_EZI2C\_Enable** API

```c
#define BUFFER_SIZE (8UL)
uint8_t buffer[BUFFER_SIZE];
cy_stc_scb_ezi2c_context_t ezI2cContext;
void EZI2C_Isr(void)
{
	Cy_SCB_EZI2C_Interrupt(CYBSP_EZI2C_HW, &ezI2cContext);
}
int main(void)
{
	cy_rslt_t result;
	/* Initialize the device and board peripherals */
	result = cybsp_init() ;
	if (result != CY_RSLT_SUCCESS)
	{
		CY_ASSERT(0);
	}
	/* Configure EZI2C slave */
	(void) Cy_SCB_EZI2C_Init(CYBSP_EZI2C_HW, &CYBSP_EZI2C_config, &ezI2cContext);
	Cy_SCB_EZI2C_SetBuffer1(CYBSP_EZI2C_HW, buffer, BUFFER_SIZE, BUFFER_SIZE, &ezI2cContext);
	/* Populate configuration structure */
	const cy_stc_sysint_t ezI2cIntrConfig =
	{
		.intrSrc      = CYBSP_EZI2C_IRQ,
		.intrPriority = 3U,
	};
	/* Hook interrupt service routine and enable interrupt */
	(void) Cy_SysInt_Init(&ezI2cIntrConfig, &EZI2C_Isr);
	NVIC_EnableIRQ(ezI2cIntrConfig.intrSrc);
	/* Enable EZI2C to operate */
	Cy_SCB_EZI2C_Enable(CYBSP_EZI2C_HW);
	/* Enable global interrupts */
	__enable_irq();
	for (;;)
	{
	}
}
```

11. Program the device
12. Using the Windows search bar, look for **Bridge Control Panel**. This tool comes with [PSoC Programmer](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.psocprogrammer) and allows your PC to utilise the I2C, UART, or SPI bridge on the KitProg that is available on the evaluation kit

<img src="assets/images/bridge_control_panel_on_windows.png" alt="Bridge Control Panel On Windows" style="width:383px; height:auto; display:block; margin:0 auto;" />


<img src="assets/images/bridge_control_panel.png" alt="Bridge Control Panel" style="width:847px; height:auto; display:block; margin:0 auto;" />


More details on how to use the Bridge Control Panel can be found in the **Help** tab.

To read from the device, start with the “r” character, then the slave address “08”, then each “x” corresponds to a byte read, then end the transaction with a stop using the “p” character

<img src="assets/images/bridge_control_panel_reads_8_bytes_of_command.png" alt="Bridge Control Panel Reads 8 Bytes Of Command" style="width:291px; height:auto; display:block; margin:0 auto;" />


13. Connect to the device using the connect button in the bottom right of the application

<img src="assets/images/bridge_control_panel_connect_to_kitprog.png" alt="Bridge Control Panel Connect To Kitprog" style="width:847px; height:auto; display:block; margin:0 auto;" />


14. Once it has connected, press the Send button and observe the successful transaction

<img src="assets/images/bridge_control_panel_send_command_to_kitprog.png" alt="Bridge Control Panel Send Command To Kitprog" style="width:847px; height:auto; display:block; margin:0 auto;" />


15. Ensure that you disconnect from the KitProg before trying to program the device

### Updating the EZI2C buffer with Systick up time

1. Navigate to the Library manager by clicking configure middleware from the application tab in ModusToolbox&trade; for VS Code main page, then open the PDL API Reference, and navigate to the **Systick** **(ARM System Timer)** page
2. This reference code can be copied into the main function and modified to use the IMO. The IMO clock frequency can be found by navigating to the device configurators **Clocks** tab
3. Alternatively, the device configurator can be used to generate the initialization code from the **Clocks** tab. Enable the SYSTICK, select the clock source and reload value. The reload value should be the source clock frequency divided by 1000 to achieve a tick interrupt every 1 ms
4. If the LFCLK is not enabled, enable the LFCLK and the source for the LFCLK

<img src="assets/images/systick_configuration_in_the_device_configurator.png" alt="Systick Configuration In The Device Configurator" style="width:1200px; height:auto; display:block; margin:0 auto;" />


5. The device configurator will generate the initialization code, but not the ISR code. That must be added to the user code in the main function

```c
volatile uint32_t tick = 0;
void EZI2C_Isr(void)
{
	Cy_SCB_EZI2C_Interrupt(CYBSP_EZI2C_HW, &ezI2cContext);
}
void SysTick_Callback(void)
{
	tick++;
}
int main(void)
{
	cy_rslt_t result;
	
	/* Initialize the device and board peripherals */
	result = cybsp_init() ;
	if (result != CY_RSLT_SUCCESS)
	{
		CY_ASSERT(0);
	}
	/* Register one of the SysTick callbacks */
	Cy_SysTick_SetCallback(0UL, &SysTick_Callback);
```

6. Add the tick value to the buffer

```c
uint32_t old_tick = tick;
for (;;)
{
	if (tick != old_tick)
	{
		old_tick = tick;
		buffer[0] = ((tick>>24) & 0xFF);
		buffer[1] = ((tick>>16) & 0xFF);
		buffer[2] = ((tick>>8) & 0xFF);
		buffer[3] = (tick & 0xFF);
	}
}
```

7. Program the device
8. Using the bridge control panel the buffer can be read periodically and mapped to a variable

9. Configure the variable
<img src="assets/images/adding_a_chart_variable.png" alt="Adding A Chart Variable" style="width:600px; height:auto; display:block; margin:0 auto;" />

10. Map the read command to the variable
<img src="assets/images/configuring_the_read_to_map_the_bytes_to_the_chart_variable.png" alt="Configuring The Read To Map The Bytes To The Chart Variable" style="width:600px; height:auto; display:block; margin:0 auto;" />

11. Set the **Scan period** to 100 ms, then press the **Repeat** button so that the command begins repeating
<img src="assets/images/repeating_the_command_every_100_ms.png" alt="Repeating The Command Every 100 Ms" style="width:600px; height:auto; display:block; margin:0 auto;" />

12. Navigate to the **Table** tab to view the timestamp bein stored 
<img src="assets/images/table_of_the_variable_being_read_every_100_ms.png" alt="Table Of The Variable Being Read Every 100 Ms" style="width:282px; height:auto; display:block; margin:0 auto;" />


### Controlling an LED using an I2C write command

The EZI2C driver emulates a typical EEPROM interface with configurable sub-address size (8 or 16 bits). This means that when writing to the device, the steps are I2C start, write address, write sub-address, write data, I2C stop.

1. Enable a User LED as shown in the GPIO lab here
2. We will use the **Cy\_SCB\_EZI2C\_GetActivity** API to determine if a write transaction has occurred on the interface. This API will need to be polled in the user application code. If a write transaction has occurred, check if the 4th byte in the buffer corresponds to a predetermined **TURN\_LED\_OFF** or **TURN\_LED\_ON** value, then set the GPIO accordingly

```c
#define TURN_LED_OFF	(0x5A)
#define TURN_LED_ON		(0xA5)
```

```c
for (;;)
{
	if (tick != old_tick)
	{
		old_tick = tick;
		buffer[0] = ((tick>>24) & 0xFF);
		buffer[1] = ((tick>>16) & 0xFF);
		buffer[2] = ((tick>>8) & 0xFF);
		buffer[3] = (tick & 0xFF);
	}
	if (CY_SCB_EZI2C_STATUS_WRITE1 == 
		(CY_SCB_EZI2C_STATUS_WRITE1 & Cy_SCB_EZI2C_GetActivity(CYBSP_EZI2C_HW, &ezI2cContext)))
	{
		/* If a write to the first buffer occurred */
		if (TURN_LED_OFF == buffer[4])
		{
			Cy_GPIO_Clr(CYBSP_LED2_PORT, CYBSP_LED2_PIN);
		}
		else if (TURN_LED_ON == buffer[4])
		{
			Cy_GPIO_Set(CYBSP_LED2_PORT, CYBSP_LED2_PIN);
		}
	}
}
```

3. Program the device, then open the bridge control panel and reconnect to the KitProg
4. Send 0xA5 to the 4th byte to turn the LED on

<img src="assets/images/writing_the_command_to_turn_the_led_on.png" alt="Writing The Command To Turn The Led On" style="width:600px; height:auto; display:block; margin:0 auto;" />


> **Note:** the command structure is a **w** for write, then the address **08**, then the sub-address **04**, the LED command **A5**, and the stop bit **p**

 Send 0x5A to the 4th byte to turn the LED off

<img src="assets/images/writing_the_command_to_turn_the_led_off.png" alt="Writing The Command To Turn The Led Off" style="width:600px; height:auto; display:block; margin:0 auto;" />


### Conclusion

This lab demonstrates how to use the EZI2C driver to quickly set up an I2C slave on a PSOC&trade; SCB. You should now be able to configure and enable the SCB, use the Systick Timer, and read and write data to the device using the Bridge Control Panel.

## Serial Communication Block with SPI

### Objective

The objective of this lab is to demonstrate how to use ModusToolbox&trade; and the PSOC&trade; peripheral driver library to communicate between MCUs using a serial communication block configured for SPI.

### Description

The serial communication block (SCB) can be configured as a SPI master or slave. Using the high-level SPI driver, the communication portion of an application can be developed quickly, allowing the user to focus on the rest of the application. The trainee will learn how to set up a PSOC&trade; device to operate as an SPI master and another PSOC&trade; device as an SPI slave.

The lab steps utilised a CY8CKIT-041S-MAX as the SPI master and a CY8CKIT-062S2-43012 as the SPI slave.

* SPI master
* SPI slave
* SPI slave with callbacks

The SPI protocol is a synchronous serial interface protocol. Devices operate in either master or slave mode. The master initiates the data transfer. The SCB supports a single-master-multiple-slaves topology for SPI. Multiple slaves are supported with individual slave select lines.

<img src="assets/images/spi_motorola_data_transfer_with_cpol_0_and_cpha_0.png" alt="Spi Motorola Data Transfer With Cpol 0 And Cpha 0" style="width:329px; height:auto; display:block; margin:0 auto;" />


The signals used for SPI are Master Out Slave In (MOSI), Master In Slave Out (MISO), Slave Select (SS), and the clock (SCLK). Since there is a signal for each direction, most SPI modes support full duplex communication. The master drives the slave select signal to indicate to a slave that the communication on the bus is directed at the slave. This allows for multiple SPI slaves on a single bus.

The PSOC&trade; SCB supports many types of SPI protocols like Motorola SPI, T.I. SPI, and National Semiconductor (Microwire) SPI. It can support master and slave functionality, multiple slave select lines, data frame sizing from 4 to 16 bits, and MSB or LSB bit order. The clock polarity (CPOL) and clock phase (CPHA) are configurable (depending on the SPI protocol chosen). See Table 3 for more details on the different clock modes.

 SPI clock modes

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Mode | CPOL | CPHA | SCLK Idle State | Data Driven | Data Captured |
| 0 | 0 | 0 | Low | Falling edge of SCLK | Rising edge of SCLK |
| 1 | 0 | 1 | Low | Rising edge of SCLK | Falling edge of SCLK |
| 2 | 1 | 0 | High | Rising edge of SCLK | Falling edge of SCLK |
| 3 | 1 | 1 | High | Falling edge of SCLK | Rising edge of SCLK |

### SPI master

1. The project created in the first exercise can be used, or the instructions shown there can be used to create a new project
2. Once the project has been opened, navigate to the application tab in ModusToolbox&trade; for VS Code main page and click configure device. Navigate to the **Peripherals** tab and enable an SCB for SPI mode based on which SCB is associated with SPI pins that are available on the evaluation kit
3. When using a PSOC&trade; 6 evaluation kit, see the [appendix instructions for setting the system clocks on PSOC&trade; 6](#appendix-psoc-6-clocks) to get the SPI baud rate to work properly
4. When using a PSOC&trade; Edge evaluation kit, adjusting the oversampling rate to 10 will allow for the input clock to be set such that the data rate of 1000 kbps is achievable
5. SCB associated with the SPI pins available on headers

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Evaluation kit | SCB | MOSI GPIO | MISO GPIO | SCLK | SS |
| CY8CKIT-041S-MAX | SCB2 | P10.0 | P10.1 | P10.2 | P10.3 |
| CY8CKIT-062S2-43012 | SCB6 | P12.0 | P12.1 | P12.2 | P12.3 |
| KIT\_PSE84\_EVAL | SCB10 | P16.1 | P16.2 | P16.0 | P16.3 |

<img src="assets/images/enabling_an_scb_for_spi_mode.png" alt="Enabling An Scb For Spi Mode" style="width:991px; height:auto; display:block; margin:0 auto;" />


6. Configure the SCB for SPI master mode, leave the sub mode set to Motorola, leave the SCLK mode as CPHA = 0 and CPOL = 0, leave the data rate at 1000 kbps, leave the bit order set to MSB first with a bit width of 8 for RX and TX, select an unused peripheral clock, and the GPIOs according to your hardware

<img src="assets/images/configuring_a_scb_for_spi_slave_mode_2.png" alt="Configuring A Scb For Spi Slave Mode 2" style="width:602px; height:auto; display:block; margin:0 auto;" /><img src="assets/images/configuring_a_scb_for_spi_slave_mode.png" alt="Configuring A Scb For Spi Slave Mode" style="width:601px; height:auto; display:block; margin:0 auto;" />


7. Follow the steps here to enable an SCB for UART mode to allow for printing data to a terminal. Note that it is best for the SCB used for SPI and the SCB used for UART not to share a peripheral clock
8. Save the device configurator
9. Open the **SPI SCB Documentation** and find the documentation for initialising, configuring the interrupt, and enabling the SPI interface

> **Note:** the steps for configuring a SPI master and a SPI slave will be the same when using the high-level driver option

10. The device configurator generates the configuration structure as well as generates and adds code to assign and configure pins, assign the clock divider, and configure the data rate. The code in the documentation to initialise the SCB, configure the interrupt, and enable the SPI interface will need to be copied into the user application

> **Note:** the alias chosen in step 2 is used when providing the inputs to these APIs

```c
#include <stdio.h>
/* Allocate context for SPI operation */
cy_stc_scb_spi_context_t spiContext;
void spi_isr(void)
{
	Cy_SCB_SPI_Interrupt(SPI_MASTER_HW, &spiContext);
}
int main(void)
{
	cy_rslt_t result;
	/* Initialize the device and board peripherals */
	result = cybsp_init() ;
	if (result != CY_RSLT_SUCCESS)
	{
		CY_ASSERT(0);
	}
	/* Configure SPI to operate */
	(void) Cy_SCB_SPI_Init(SPI_MASTER_HW, &SPI_MASTER_config, &spiContext);
	/* Populate configuration structure */
	const cy_stc_sysint_t spi_intr_config =
	{
		.intrSrc      = SPI_MASTER_IRQ,
		.intrPriority = 3U,
	};
	/* Hook interrupt service routine and enable interrupt */
	(void)Cy_SysInt_Init(&spi_intr_config, &spi_isr);
	/* Enable interrupt in NVIC */
	NVIC_EnableIRQ(SPI_MASTER_IRQ);
	
	/* Enable the SPI Master block */
	Cy_SCB_SPI_Enable(SPI_MASTER_HW);
```

11. We will need to add in the code to enable UART SCB as well

```c
Cy_SCB_UART_Init(CYBSP_UART_HW, &CYBSP_UART_config, NULL);
Cy_SCB_UART_Enable(CYBSP_UART_HW);
Cy_SCB_UART_PutString(CYBSP_UART_HW, "SPI Master\r\n");
```

12. Navigate back to the SPI PDL documentation and look for the **High-Level API** portion. This shows example code for using the **Cy\_SCB\_SPI\_Transfer** and **Cy\_SCB\_SPI\_GetTransferStatus** APIs to transfer bytes from the master to the slave
13. Let’s add a GPIO input using the steps found here as a trigger for initiating the transfer
14. Update the main for loop

```c
cy_en_scb_spi_status_t master_status;
uint8_t tx_buffer[4] = {0xDE, 0xAD, 0xBE, 0xEF};
uint8_t rx_buffer[4];
for (;;)
{
	if (0UL == Cy_GPIO_Read(CYBSP_SW2_PORT, CYBSP_SW2_PIN))
	{
		/* Initiate SPI Master write transaction. */
		master_status = Cy_SCB_SPI_Transfer(SPI_MASTER_HW, tx_buffer, rx_buffer, 4, &spiContext);
		
		if (CY_SCB_SPI_BAD_PARAM == master_status)
		{
			CY_ASSERT(0);
		}
		/* Blocking wait for transfer completion */
		while (0UL != (CY_SCB_SPI_TRANSFER_ACTIVE & Cy_SCB_SPI_GetTransferStatus(SPI_MASTER_HW, &spiContext)))
		{
		}
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "Send Bytes: ");
		for (uint8_t i = 0; i < 4; i++)
		{
			char print[8];
			sprintf(print, "0x%x; ", tx_buffer[i]);
			Cy_SCB_UART_PutString(CYBSP_UART_HW, print);
		}
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "\r\n");
		
		/* Simple de-bounce on the GPIO press. */
		Cy_SysLib_Delay(500);
		
	}
}
```


15. Program the device, open a terminal, press the button and observe the output

<img src="assets/images/spi_master_transfer_4_bytes_vs_code.png" alt="Spi Master Transfer 4 Bytes Vs Code" style="width:369px; height:auto; display:block; margin:0 auto;" />


16. Let’s add a function to print a buffer so that we can easily print the RX and TX buffers

```c
void print_buffer(char * message, uint8_t * buffer, uint8_t size)
{
	Cy_SCB_UART_PutString(CYBSP_UART_HW, message);
	for (uint8_t i = 0; i < size; i++)
	{
		char print[8];
		sprintf(print, "0x%x; ", buffer[i]);
		Cy_SCB_UART_PutString(CYBSP_UART_HW, print);
	}
	Cy_SCB_UART_PutString(CYBSP_UART_HW, "\r\n");
}
```

17. Use the function to print the buffer

```c
cy_en_scb_spi_status_t master_status;
uint8_t tx_buffer[4] = {0xDE, 0xAD, 0xBE, 0xEF};
uint8_t rx_buffer[4];
for (;;)
{
	if (0UL == Cy_GPIO_Read(CYBSP_SW2_PORT, CYBSP_SW2_PIN))
	{
		/* Initiate SPI Master write transaction. */
		master_status = Cy_SCB_SPI_Transfer(SPI_MASTER_HW, tx_buffer, rx_buffer, 4, &spiContext);
		
		if (CY_SCB_SPI_BAD_PARAM == master_status)
		{
			CY_ASSERT(0);
		}
		/* Blocking wait for transfer completion */
		while (0UL != (CY_SCB_SPI_TRANSFER_ACTIVE & Cy_SCB_SPI_GetTransferStatus(SPI_MASTER_HW, &spiContext)))
		{
		}
		print_buffer("Send Bytes: ", tx_buffer, 4);
		print_buffer("Receive Bytes: ", rx_buffer, 4);
		
		/* Simple de-bounce on the GPIO press. */
		Cy_SysLib_Delay(500);
		
	}
}
```

18. Program the device, press the button, and observe the new output

> **Note:** Since an SPI slave has not been connected, the RX data will be 0x00 because the MISO pin is floating.

<img src="assets/images/terminal_output_while_printing_spi_master_send_and_receive_data_vs_code.png" alt="Terminal Output While Printing Spi Master Send And Receive Data Vs Code" style="width:373px; height:auto; display:block; margin:0 auto;" />


### SPI slave

 SCB associated with the SPI pins available on headers

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Evaluation kit | SCB | MOSI GPIO | MISO GPIO | SCLK | SS |
| CY8CKIT-041S-MAX | SCB2 | P10.0 | P10.1 | P10.2 | P10.3 |
| CY8CKIT-062S2-43012 | SCB6 | P12.0 | P12.1 | P12.2 | P12.3 |
| KIT\_PSE84\_EVAL | SCB10 | P16.1 | P16.2 | P16.0 | P16.3 |

1. The project created in the first exercise can be used, or the instructions shown there can be used to create a new project
2. Once the project has been opened, navigate to the application tab in ModusToolbox&trade; for VS Code main page and click configure device. Navigate to the **Peripherals** tab and enable an SCB for SPI mode

> **Note:** When using a PSOC&trade; 6 evaluation kit, see the [appendix instructions for setting the system clocks on PSOC&trade; 6](#appendix-psoc-6-clocks) to get the SPI baud rate to work properly.

<img src="assets/images/enabling_a_scb_for_spi_mode.png" alt="Enabling A Scb For Spi Mode" style="width:739px; height:auto; display:block; margin:0 auto;" />


3. Configure the SCB for SPI slave mode, leave the sub mode set to Motorola, leave the SCLK mode as CPHA = 0 and CPOL = 0, leave the data rate at 1000 kbps, leave the bit order set to MSB first with a bit width of 8 for RX and TX, select an unused peripheral clock, and the GPIOs according to your hardware

<img src="assets/images/configuring_an_scb_for_spi_slave_mode.png" alt="Configuring An Scb For Spi Slave Mode" style="width:572px; height:auto; display:block; margin:0 auto;" />


4. Follow the steps here to enable an SCB for UART mode to allow for printing data to a terminal

> **Note:** it’s best for the SCB used for SPI and the SCB used for UART not to share a peripheral clock

5. Save the device configurator
6. Open the SPI SCB Documentation and find the documentation for initialising, configuring the interrupt, and enabling the SPI interface

> **Note:** the steps for configuring a SPI master and a SPI slave will be the same when using the high-level driver option

7. The device configurator generates the configuration structure as well as generates and adds code to assign and configure pins, assign the clock divider, and configure the data rate. The code in the documentation to initialise the SCB, configure the interrupt, and enable the SPI interface will need to be copied into the user application

> **Note:** the alias chosen in step 2 is used when providing the inputs to these APIs

```c
#include <stdio.h>
/* Allocate context for SPI operation */
cy_stc_scb_spi_context_t spiContext;
void spi_sr(void)
{
	Cy_SCB_SPI_Interrupt(SPI_SLAVE_HW, &spiContext);
}
```
The initialization code should be placed after the **cybsp\_init** and **enable\_irq** function calls.
```c
/* Configure SPI to operate */
(void) Cy_SCB_SPI_Init(SPI_SLAVE_HW, &SPI_SLAVE_config, &spiContext);
/* Populate configuration structure */
const cy_stc_sysint_t spiIntrConfig =
{
	.intrSrc      = SPI_SLAVE_IRQ,
	.intrPriority = 3U,
};
/* Hook interrupt service routine and enable interrupt */
(void) Cy_SysInt_Init(&spiIntrConfig, &spi_sr);
NVIC_EnableIRQ(spiIntrConfig.intrSrc);
/* Enable the SPI Slave block */
Cy_SCB_SPI_Enable(SPI_SLAVE_HW);
```



8. We will need to add the code to enable the UART SCB as well

```c
Cy_SCB_UART_Init(CYBSP_UART_HW, &CYBSP_UART_config, NULL);
Cy_SCB_UART_Enable(CYBSP_UART_HW);
Cy_SCB_UART_PutString(CYBSP_UART_HW, "SPI Slave\r\n");
```

9. Navigate back to the SPI PDL documentation and look for the **High-Level API** portion. This shows example code for using the **Cy\_SCB\_SPI\_Transfer** and **Cy\_SCB\_SPI\_GetTransferStatus** APIs to transfer bytes from the master to the slave
10. Let’s add this user code to the infinite for loop of the main function, along with code to print the received data using the debug UART

```c
uint8_t rx_buffer[4];
for (;;)
{
	volatile cy_en_scb_spi_status_t status;
	/* Master: start a transfer. Slave: prepare for a transfer. */
	status = Cy_SCB_SPI_Transfer(SPI_SLAVE_HW, NULL, rx_buffer, 4, &spiContext);
	if (CY_SCB_SPI_SUCCESS == status)
	{
		/* Blocking wait for transfer completion */
		uint32_t transfer_status;
		do {
			transfer_status = Cy_SCB_SPI_GetTransferStatus(SPI_SLAVE_HW, &spiContext);
		}while (0UL != (CY_SCB_SPI_TRANSFER_ACTIVE & transfer_status));
	}
	Cy_SCB_UART_PutString(CYBSP_UART_HW, "Receive Bytes: ");
	for (uint8_t i = 0; i < 4; i++)
	{
		char print[8];
		sprintf(print, "0x%x; ", rx_buffer[i]);
		Cy_SCB_UART_PutString(CYBSP_UART_HW, print);
	}
	Cy_SCB_UART_PutString(CYBSP_UART_HW, "\r\n");
}
```


11. We need to connect the SPI slave to the SPI master created in the first portion of this lab. Be sure that the GPIOs used are operating at the same voltage. The PSOC&trade; 4100S Max evaluation kit can operate at 5 V or 3.3 V by adjusting the J10 jumper. The PSOC&trade; 6 evaluation kit can operate at 3.3 V or 1.8 V by adjusting the J14 jumper. The PSOC&trade; Edge evaluation kit SPI GPIOs can operate at 3.3 V or 1.8 V by adjusting the J23 jumper


|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Evaluation kit | MOSI | MISO | SCLK | SS |
| CY8CKIT-041S-MAX | P10[0] (D11) | P10[1] (D12) | P10[2] (D13) | P10[3] (D10) |
| CY8CKIT-062S2-43012 | P12[0] (D11) | P12[1] (D12) | P12[2] (D13) | P12[3] (D10) |
| KIT\_PSE84\_EVAL | P16[1] (SPI.MOSI) | P16[2] (SPI.MISO) | P16[0] (SPI.SCK) | P16[3] (SPI.CS) |

12. Program the device, open a terminal, press the button on the SPI slave and observe the output

> **Note:** some evaluation kits cannot be programmed if other evaluation kits are connected. It is best practice to only connect the evaluation kit you are programming during the programming step

<img src="assets/images/terminal_output_of_a_spi_slave_receiving_4_bytes_vs_code.png" alt="Terminal Output Of A Spi Slave Receiving 4 Bytes Vs Code" style="width:369px; height:auto; display:block; margin:0 auto;" />


### SPI slave with callbacks

The initial SPI slave implementation used a polled, blocking method. A more common and useful implementation is fully interrupt-driven using callbacks to handle the SPI transactions.

1. Navigate to the SCB SPI PDL documentation and go to the **Interrupt** section, then look for the **Cy\_SCB\_SPI\_RegisterCallback** API
2. Let’s add a callback to service the **CY\_SCB\_SPI\_TRANSFER\_CMPLT\_EVENT** complete event and enable sending data back to the master
	* Make the **rx\_buffer** and **tx\_buffer** global variables
	* Add the callback function that sets up a new transfer and flags the main code that new buffer data to print is available
	

```c
/* Allocate context for SPI operation */
cy_stc_scb_spi_context_t spiContext;
volatile bool print_data;
uint8_t rx_buffer[4];
uint8_t tx_buffer[4] = {0xBE, 0xEF, 0xCA, 0xFE};
void spi_sr(void)
{
	Cy_SCB_SPI_Interrupt(SPI_SLAVE_HW, &spiContext);
}
void spi_callback(uint32_t event)
{
	if (CY_SCB_SPI_TRANSFER_CMPLT_EVENT == event)
	{
		Cy_SCB_SPI_Transfer(SPI_SLAVE_HW, tx_buffer, rx_buffer, 4, &spiContext);
		print_data = true;
	}
}
```

3. Register the callback after initializing the peripheral

```c
/* Configure SPI to operate */
(void) Cy_SCB_SPI_Init(SPI_SLAVE_HW, &SPI_SLAVE_config, &spiContext);
Cy_SCB_SPI_RegisterCallback(SPI_SLAVE_HW, spi_callback, &spiContext);
```

4. Add the print buffer function from the SPI Master portion

```c
void print_buffer(char * message, uint8_t * buffer, uint8_t size)
{
	Cy_SCB_UART_PutString(CYBSP_UART_HW, message);
	for (uint8_t i = 0; i < size; i++)
	{
		char print[8];
		sprintf(print, "0x%x; ", buffer[i]);
		Cy_SCB_UART_PutString(CYBSP_UART_HW, print);
	}
	Cy_SCB_UART_PutString(CYBSP_UART_HW, "\r\n");
}
```

5. Update the main function infinite for loop to only act when new buffer data to print is available

```c
/* Setup the first transfer. */
Cy_SCB_SPI_Transfer(SPI_SLAVE_HW, tx_buffer, rx_buffer, 4, &spiContext);
for (;;)
{
	if(true == print_data)
	{
		print_data = false;
		print_buffer("Receive Bytes: ", rx_buffer, 4);
		print_buffer("Send Bytes: ", tx_buffer, 4);
	}
}
```

6. Program the device, open the terminal, press the SPI Master button, and observe the output

<img src="assets/images/terminal_output_of_callback_implementation_of_spi_slave_vs_code.png" alt="Terminal Output Of Callback Implementation Of Spi Slave Vs Code" style="width:372px; height:auto; display:block; margin:0 auto;" />


<img src="assets/images/terminal_output_of_spi_master_vs_code.png" alt="Terminal Output Of Spi Master Vs Code" style="width:379px; height:auto; display:block; margin:0 auto;" />


### Conclusion

The user should now be able to use ModusToolbox&trade; to enable an SPI master or an SPI slave on a PSOC&trade; device. The user should also know how to access the PDL documentation for the SCB when configured as a SPI controller and how to implement a callback for the high-level version of the SPI PDL.

## Watchdog timer

### Objective

The objective of this lab is to demonstrate how to enable the watchdog timer (WDT) on PSOC&trade; devices using ModusToolbox&trade; and the peripheral driver library (PDL) libraries.

### Description

The watchdog timer on PSOC&trade; devices can be used to handle error conditions where the device is unable to leave a task. The WDT is typically sourced from a low-frequency clock (LFCLK) and can be configured for a few different use cases, like a periodic interrupt or a system reset on the expiration of the timer.

<img src="assets/images/psoc_watchdog_timer_block_diagram.png" alt="PSOC Watchdog Timer Block Diagram" style="width:486px; height:auto; display:block; margin:0 auto;" />


The WDT asserts a system reset to the device on the third WDT match event, unless it is periodically serviced in firmware.

<img src="assets/images/psoc_watchdog_timer_block_diagram_2.png" alt="PSOC Watchdog Timer Block Diagram 2" style="width:825px; height:auto; display:block; margin:0 auto;" />
 

The WDT\_COUNTER register provides the count value of the WDT. The WDT generates an interrupt when the count value in WDT\_COUNTER equals the match value stored in the WDT\_MATCH register, but it does not reset the count to '0'. Instead, the WDT keeps counting until it overflows (after 0xFFFF when the resolution is set to 16 bits) and rolls back to 0. When the count value again reaches the match value, another interrupt is generated. Note that the match count can be changed when the counter is running. A bit named WDT\_MATCH in the SRSS\_INTR register is set whenever the WDT interrupt occurs. This interrupt must be cleared by writing a '1' to the WDT\_MATCH bit in SRSS\_INTR to reset the watchdog. If the firmware does not reset the WDT for two consecutive interrupts, the third match event will generate a system reset. The IGNORE\_BITS in the WDT\_MATCH register can be used to reduce the entire WDT counter period. The ignore bits can specify the number of MSBs that need to be discarded.

### WDT with a system reset on expiration

1. The project created in the first exercise can be used, or the instructions shown there can be used to create a new project
2. Once the project has been opened, navigate to the application tab in ModusToolbox&trade; for VS Code main page and click configure device. Navigate to the **Peripherals** tab and enable the **Watchdog Timer**

> **Note:** on CAT 1 devices, the WDT cannot be configured in the device configurator and must be initialized in user code using the PDL APIs

<img src="assets/images/enabling_the_wdt_in_the_device_configurator.png" alt="Enabling The Wdt In The Device Configurator" style="width:1200px; height:auto; display:block; margin:0 auto;" />


3. Follow the steps here to enable an SCB for UART mode to allow for printing information to a terminal
4. Let’s add a GPIO input using the steps found here as a trigger for causing an infinite loop
5. Save the device configurator, then open the **Watchdog Timer Documentation** and navigate to the Functions page. Use the **Cy\_WDT\_Enable** and **Cy\_WDT\_ClearWatchdog** APIs
6. The device configurator will configure the WDT settings as shown in the parameters window, but it will not enable the WDT; the user application code must enable the WDT and clear the timer

**For PSOC&trade; 4**
```c
Cy_SCB_UART_Init(CYBSP_UART_HW, &CYBSP_UART_config, NULL);
Cy_SCB_UART_Enable(CYBSP_UART_HW);
Cy_SCB_UART_PutString(CYBSP_UART_HW, "WDT with system reset on expiration \r\n");
/* Enables the watchdog timer reset generation. */
Cy_WDT_Enable();
/* Enable global interrupts */
__enable_irq();
for (;;)
{
	if (0UL == Cy_GPIO_Read(CYBSP_SW4_PORT, CYBSP_SW4_PIN))
	{
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "Button pressed, entering infinite loop \r\n");
		while(1);
	}
	Cy_WDT_ClearWatchdog();
}
```
**For PSOC&trade; 6**
```c
Cy_SCB_UART_Init(CYBSP_UART_HW, &CYBSP_UART_config, NULL);
Cy_SCB_UART_Enable(CYBSP_UART_HW);
Cy_SCB_UART_PutString(CYBSP_UART_HW, "WDT with system reset on expiration \r\n");
Cy_WDT_Unlock();
Cy_WDT_SetMatch(0x8000);
Cy_WDT_ClearInterrupt();
Cy_WDT_Enable();
Cy_WDT_Lock();
/* Enable global interrupts */
__enable_irq();
for(;;)
{
	if (0UL == Cy_GPIO_Read(CYBSP_SW4_PORT, CYBSP_SW4_PIN))
	{
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "Button pressed, entering infinite loop \r\n");
		while(1);
	}
	Cy_WDT_ClearWatchdog();
}
```
**For PSOC&trade; Edge**
```c
Cy_SCB_UART_Init(CYBSP_UART_HW, &CYBSP_UART_config, NULL);
Cy_SCB_UART_Enable(CYBSP_UART_HW);
Cy_SCB_UART_PutString(CYBSP_UART_HW, "WDT with system reset on expiration \r\n");
Cy_WDT_Unlock();
/* PSOC Edge default match bits is 0, 
*  set to 14 so that first 14 match bits are used. Only for PSOC Edge. */
Cy_WDT_SetMatchBits(14);
Cy_WDT_SetMatch(0x8000);
Cy_WDT_ClearInterrupt();
Cy_WDT_Enable();
Cy_WDT_Lock();
/* Enable global interrupts */
__enable_irq();
for(;;)
{
	if (0UL == Cy_GPIO_Read(CYBSP_SW4_PORT, CYBSP_SW4_PIN))
	{
		Cy_SCB_UART_PutString(CYBSP_UART_HW, "Button pressed, entering infinite loop \r\n");
		while(1);
	}
	Cy_WDT_ClearWatchdog();
}
```

7. Program the device, open a terminal, and observe the output

<img src="assets/images/terminal_output_after_programming_vs_code.png" alt="Terminal Output After Programming Vs Code" style="width:368px; height:auto; display:block; margin:0 auto;" />


8. Press the user button and see that it enters the infinite loop, then resets it once the WDT expires

<img src="assets/images/terminal_output_after_pressing_the_user_button_and_the_wdt_reset_vs_code.png" alt="Terminal Output After Pressing The User Button And The Wdt Reset Vs Code" style="width:371px; height:auto; display:block; margin:0 auto;" />


### Conclusion

The user should now be able to configure, enable, and clear the WDT for PSOC&trade; devices using ModusToolbox&trade;.

## Smart I/O

### Objective

The objective of this lab is to demonstrate how to enable the Smart I/O block in the device configurator and implement a ramping LED logic using the Smart I/O configurator.

### Description

The Smart I/O block is a digital resource available in PSOC&trade; devices that provides the added feature of programmable logic to the I/O ports. The Smart I/O block is placed in the signal path between the HSIOM and the I/O port, and it can process signals from the port pins and HSIOM to implement a desired logic function.

<img src="assets/images/smartio_interface.png" alt="smartio interface - signal path between HSIOM and IO port" style="width:671px; height:auto; display:block; margin:0 auto;" />

The Smart I/O block supports the following signal paths:

* Implement self-contained logic functions that directly operate on port I/O signals
* Implement self-contained logic functions that operate on HSIOM
* Operate on and modify HSIOM output signals and route the modified signals to port I/O signals
* Operate on and modify port I/O signals and route the modified signals to HSIOM input signals

The Smart I/O block is made up of the following components:

* Clock/reset
* Synchronizers
* Lookup table
* Data unit

In PSOC&trade; 4100T Plus, one Smart I/O block is available at port 2. For a different PSOC&trade; device, refer to the respective datasheet.

### Ramping LED

The implementation utilizes PWM and the Smart I/O to generate two square waves of slightly varying frequencies and uses the Smart I/O to exclusive-OR (XOR) them to get a signal that has a gradually changing duty cycle. When this signal is applied to an LED, it produces a ramping brightness in the LED.

The PWM driven with a 10 kHz clock and a 50 % duty cycle will generate a 40 ms period square wave. The Smart I/O is operated at 99 Hz. When the input clock is divided by four using the lookup table (LUT) of the Smart I/O, it generates a square wave with a 40.4 ms period.

To implement a divide-by-4 sequential circuit, consider the state transition values shown in Table

| Clock | Q0(n) | Q1(n) | Q0(n+1) | Q1(n+1) | D0 | D1 |
|-------|-------|-------|---------|---------|----|----|
| &#8593; | 0 | 0 | 1 | 1 | 1 | 1 |
| &#8593; | 1 | 1 | 0 | 1 | 0 | 1 |
| &#8593; | 0 | 1 | 1 | 0 | 1 | 0 |
| &#8593; | 1 | 0 | 0 | 0 | 0 | 0 |

From this state transition table, you can observe that Q0 is half the frequency of Clk_SmartIO and Q1 is one-fourth the frequency of Clk_SmartIO. You can implement this sequential logic using the LUTs of the Smart I/O resource.

Figure below shows the implementation of this logic using LUT 2 and LUT 3. In addition, the divided clock is XORed with the PWM output using LUT1 to generate a signal with the duty cycle gradually increasing and decreasing over time.

<img src="assets/images/lut_configuration_raming_led.png" alt="resultant signals after the lut configuration" style="width:600px; height:auto; display:block; margin:0 auto;" />

#### Enabling Smart I/O

1. Use the project created in the first exercise, or follow those instructions to create a new project

2. After opening the project, navigate to the ModusToolbox&trade; for VS Code main page and click **Configure Device**. Navigate to the **Peripherals** tab, enable **TCPWM 16-bit Counter 2**, and configure it as PWM

	* Set the period to 399 and the compare value to 200 to achieve a 50 % duty cycle.
	* Route the PWM output to **Chip 1** of the Smart I/O block.


<img src="assets/images/device_congifurator_tcpwm_ramping_led_settings.png" alt="PWM settings for ramping LED to get 10 kHz square wave" style="width:600px; height:auto; display:block; margin:0 auto;" />

3. Configure the 16-bit divider so that it drives the PWM at 10 kHz

<img src="assets/images/device_configurator_pwm_divider_clock_settings.png" alt="PWM clock settings for ramping LED to get 10 kHz square wave" style="width:600px; height:auto; display:block; margin:0 auto;" />


4. Navigate to the **Pins** tab, enable Smart I/O in the port, and then click **Launch Smart I/O Configurator**
<img src="assets/images/launching_smart_io_configurator.png" alt="clock selection for smart io block" style="width:1000px; height:auto; display:block; margin:0 auto;" />

> **Note:** PSOC&trade; 4100T Plus has one Smart I/O block in port 2; for the respective PSOC&trade; device, refer to the datasheet.

5. Configure the clock for the Smart I/O block as the active peripheral clock divider, and then choose the 24.5-bit divider clock

<img src="assets/images/smart_io_configurator_peripheral_clock_selection.png" alt="clock selection for smart io block" style="width:800px; height:auto; display:block; margin:0 auto;" />

6. Configure the fabric routing:

	* **Chip 1** is an **Input (Async)** using **TCPWM 16-bit Counter 2 pwm_n**.
	* **LUT 1** uses **Chip 1** and **LUT 3** as inputs.
	* **LUT 2** uses **LUT 2** as its input.
	* **LUT 3** uses **LUT 2** and **LUT 3** as its inputs.
	* **I/O 1** is the only I/O output.

<img src="assets/images/smart_io_configurator_lut_settings.png" alt="clock selection for smart io block" style="width:800px; height:auto; display:block; margin:0 auto;" />

7. Configure the logic and output gating for each LUT:

	* Set up **LUT 1** to XOR the signal from **LUT 3** and **Chip 1**, which is the 10 kHz PWM output.

	<img src="assets/images/smart_io_configurator_lut_1.png" alt="lut 1 settings" style="width:600px; height:auto; display:block; margin:0 auto;" />

	* Set the **LUT 2** input to **LUT 2** to create a NOT gate with a D flip-flop.

	<img src="assets/images/smart_io_configurator_lut_2.png" alt="lut 2 settings" style="width:600px; height:auto; display:block; margin:0 auto;" />

	* Set **LUT 3** as an XNOR gate for the signals from **LUT 2** and **LUT 3** with a D flip-flop.

	<img src="assets/images/smart_io_configurator_lut_3.png" alt="lut 3 settings" style="width:600px; height:auto; display:block; margin:0 auto;" />

8. Save and close the Smart I/O configurator

9. In the device configurator, set the integer divider so that the resulting clock frequency is 99 Hz. Note that you cannot change the clock divider configuration while it is locked by the Smart I/O configurator

<img src="assets/images/configuring_smart_io_peri_clock.png" alt="lut 3 settings" style="width:1000px; height:auto; display:block; margin:0 auto;" />

10. Configure the Smart I/O GPIO as a **Strong Drive** output with the input buffer disabled

<img src="assets/images/configure_smart_io_gpio.png" alt="lut 3 settings" style="width:1000px; height:auto; display:block; margin:0 auto;" />

11. Configure the LED GPIO as a digital input

<img src="assets/images/configuring_led_gpio.png" alt="lut 3 settings" style="width:1000px; height:auto; display:block; margin:0 auto;" />

12. Save and clode the device configurator

13. Navigate to `main.c` and paste the following code to enable the TCPWM and Smart I/O

```c
Cy_TCPWM_PWM_Init(tcpwm_0_cnt_2_HW, tcpwm_0_cnt_2_NUM, &tcpwm_0_cnt_2_config);
Cy_TCPWM_PWM_Enable(tcpwm_0_cnt_2_HW, tcpwm_0_cnt_2_NUM);
Cy_TCPWM_TriggerStart(tcpwm_0_cnt_2_HW, tcpwm_0_cnt_2_MASK);

Cy_SmartIO_Init(PRGIO_PRT0, &ioss_0_smartio_0_config);
Cy_SmartIO_Enable(PRGIO_PRT0);
```
14. Program the PSOC&trade; device

15. Connect P2.1 to P6.2 using a jumper wire so that the Smart I/O GPIO controls the LED GPIO signal. This is required because the Smart I/O GPIOs do not connect to an LED

<img src="assets/gifs/breathing_led.gif" alt="lut 3 settings" style="width:600px; height:auto; display:block; margin:0 auto;" />

### Conclusion

The user should now be able to configure, enable, and implement the ramping LED logic in PSOC&trade; devices using ModusToolbox&trade;.

## Appendix

<a id="appendix-disable-hal-psoc-6"></a>

### Disabling the HAL on PSOC&trade; 6 BSPs

The hardware abstraction layer (HAL) is not required for this training and prevents the use of PDLs with certain libraries. For these reasons, it is best to disable the HAL if a PSOC&trade; 6 is used during this training.

1. Once the PSOC&trade; 6 Empty App project has been created, open the BSP assistant from the application tab in modusToolbox&trade; for VS Code main page

<img src="assets/images/launching_the_bsp_assistant_from_the_application_tab_in_modustoolbox_for_vs_code.png" alt="Launching The Bsp Assistant From The Application Tab In Modustoolbox For Vs Code" style="width:1200px; height:auto; display:block; margin:0 auto;" />


2. In the device properties, change the **Using HAL Interface** option to **N/A**

<img src="assets/images/disabling_the_hal_for_the_device.png" alt="Disabling The Hal For The Device" style="width:1013px; height:auto; display:block; margin:0 auto;" />


3. Remove the HAL libraries from the project by pressing the **X** next to the library

<img src="assets/images/removing_the_hal_libraries_from_the_project_using_the_bsp_assistant_tool.png" alt="Removing The Hal Libraries From The Project Using The Bsp Assistant Tool" style="width:1013px; height:auto; display:block; margin:0 auto;" />


4. Save the changes and close the BSP assistant tool
5. When closing the BSP assistant tool, a pop-up will appear instructing you to update the library manager. Open the library manager from the application tab of ModusToolbox&trade; for VS Code main page and press the “Update” button

<a id="appendix-disable-freertos-psoc-edge"></a>

### Disabling FreeRTOS from PSOC&trade; Edge Empty Application

The PSOC&trade; Edge Empty Application enables FreeRTOS and an MCWDT for both the CM33\_NS and CM55 projects to show how to blink an LED in both cores. To disable these items, modifications to the main.c file, included libraries, and makefiles for the corresponding projects are required.

1. Once the project has been created, open the library manager by clicking on configure middleware from the application tab in modusToolbox&trade; for VS Code main page

<img src="assets/images/launching_the_library_manager_from_the_application_tab_in_modustoolbox_for_vs_code.png" alt="Launching The Library Manager From The Application Tab In Modustoolbox For Vs Code" style="width:1146px; height:auto; display:block; margin:0 auto;" />


2. Delete the **freertos** library from the **proj\_cm33\_ns** and **proj\_cm55** libraries then press the Update button

<img src="assets/images/removing_the_freetos_library_from_the_library_manager.png" alt="Removing The Freetos Library From The Library Manager" style="width:849px; height:auto; display:block; margin:0 auto;" />


3. Navigate to the main.c file for the corresponding project

<img src="assets/images/main_c_file_in_the_vs_code_project_explorer.png" alt="Main C File In The Vs Code Project Explorer" style="width:416px; height:auto; display:block; margin:0 auto;" />


4. Remove #include cy\_time.h, #include FreeRTOS.h, #include task.h, #include cyabs\_rtos.h, and #include cyabs\_rtos.impl.h

<img src="assets/images/removing_freertos_related_header_files.png" alt="Removing Freertos Related Header Files" style="width:275px; height:auto; display:block; margin:0 auto;" />


5. Remove all **BLINKY\_LED\_TASK** macros and the macros for the LP timer

<img src="assets/images/removing_freertos_related_macros.png" alt="Removing Freertos Related Macros" style="width:641px; height:auto; display:block; margin:0 auto;" />


6. Remove the **lptimer\_obj** global variable

<img src="assets/images/removing_freertos_related_global_variables.png" alt="Removing Freertos Related Global Variables" style="width:621px; height:auto; display:block; margin:0 auto;" />


7. Remove the functions **setup\_clib\_support, cm33\_blinky\_task**, **lptimer\_interrupt\_handler**, and **setup\_tickless\_idle\_timer,** as well as where they are invoked in the main function

<img src="assets/images/removing_clib_support_init_function.png" alt="Removing Clib Support Init Function" style="width:607px; height:auto; display:block; margin:0 auto;" />


<img src="assets/images/removing_freertos_related_functions.png" alt="Removing Freertos Related Functions" style="width:632px; height:auto; display:block; margin:0 auto;" />


<img src="assets/images/removing_freertos_related_function_calls_in_main_function.png" alt="Removing Freertos Related Function Calls In Main Function" style="width:574px; height:auto; display:block; margin:0 auto;" />


8. Add an infinite for loop to the main function

<img src="assets/images/adding_infinite_for_loop_to_main_function.png" alt="Adding Infinite For Loop To Main Function" style="width:591px; height:auto; display:block; margin:0 auto;" />


9. Navigate to the makefile for each project and remove the FREERTOS and RTOS\_AWARE components

<img src="assets/images/removing_the_freertos_and_rtos_aware_components_from_the_makefile.png" alt="Removing The Freertos And Rtos Aware Components From The Makefile" style="width:636px; height:auto; display:block; margin:0 auto;" />


10. Ensure that these steps are completed for the CM33\_NS and CM55 projects
11. Build the project to ensure that all steps were completed successfully

<a id="appendix-psoc-edge-mtb-hal"></a>

### PSOC&trade; Edge MTB-HAL for retarget-IO

The PSOC&trade; Edge support within ModusToolbox&trade; introduces a Device Support Library (DSL) concept. The DSL for PSOC&trade; Edge includes the stdlib-stubs, the MTB-HAL, the PDL, and the Syspm-Callbacks libraries. This means that disabling the MTB-HAL is not available for PSOC&trade; Edge. Please use the following source code to enable retarget-IO for the PSOC&trade; Edge.

```c
#include "cy_retarget_io.h"
mtb_hal_uart_t DEBUG_UART_hal_obj;
cy_stc_scb_uart_context_t DEBUG_UART_context;
int main(void)
{
	cy_rslt_t result;
	/* Initialize the device and board peripherals */
	result = cybsp_init() ;
	if (result != CY_RSLT_SUCCESS)
	{
		CY_ASSERT(0);
	}
	Cy_SCB_UART_Init(CYBSP_UART_HW, &CYBSP_UART_config, NULL);
	/* Enable global interrupts */
	__enable_irq();
	Cy_SCB_UART_Enable(CYBSP_UART_HW);
	result = mtb_hal_uart_setup(&DEBUG_UART_hal_obj, &CYBSP_UART_hal_config, &DEBUG_UART_context, NULL);
	
	cy_retarget_io_init(&DEBUG_UART_hal_obj);
	printf("Hello from retarget-IO\r\n");
```

<a id="appendix-psoc-6-clocks"></a>

### PSOC&trade; 6 system and peripheral clocks

The PSOC&trade; 6 default clock tree setup for BSPs sets the CLK\_HF0 to 100 MHz using the FLL to generate the input. The CLK\_HF0 is used to drive the CLK\_PERI, which provides the source clock frequency for all peripheral clock dividers. The CLK\_HF0 can also be derived from the PLL0 and PLL1, which can drive the input to CLK\_HF0 at 150 MHz. This is important for PSOC&trade; peripherals like SPI that require a specific peripheral clock input to meet the required baud rate. When needing to achieve a baud rate of 1 MHz (1000 ksps) for an SPI bus, it is best to set the CLK\_PERI to 75 MHz, which means that the CLK\_HF0 needs to be set to 150 MHz. Follow these steps to adjust the clock system before enabling the SCB for SPI.

1. Open the device configurator and navigate to the **System** tab

<img src="assets/images/psoc_6_system_tab_view.png" alt="PSOC 6 System Tab View" style="width:1200px; height:auto; display:block; margin:0 auto;" />


2. Click on the PLL0 block and adjust the frequency to 150 MHz

<img src="assets/images/psoc_6_system_tab_view_2.png" alt="PSOC 6 System Tab View 2" style="width:373px; height:auto; display:block; margin:0 auto;" />


3. Click on the CLK\_HF0 and change the clock path to CLK\_PATH1 (PLL0)

<img src="assets/images/psoc_6_system_tab_view_3.png" alt="PSOC 6 System Tab View 3" style="width:375px; height:auto; display:block; margin:0 auto;" />


4. Click on the CLK\_PERI and set the divider to 2

<img src="assets/images/psoc_6_system_tab_view_4.png" alt="PSOC 6 System Tab View 4" style="width:367px; height:auto; display:block; margin:0 auto;" />


5. Now, when enabling the SCB for SPI, and selecting an unused peripheral clock will cause the device configurator to modify the peripheral clock divider to meet the baud rate requirements automatically

### Evaluation kits

|  |  |  |
| --- | --- | --- |
| Product family | Evaluation kit | Link |
| PSOC&trade; 4100T Plus | CY8CPROTO-041TP | [Evaluation board](https://www.infineon.com/evaluation-board/CY8CPROTO-041TP) |
| PSOC&trade; 4000T | CY8CKIT-040T-MS | [Evaluation board](https://www.infineon.com/evaluation-board/CY8CPROTO-040T-MS) |
| PSOC&trade; 4100S Max | CY8CKIT-041S-MAX | [Evaluation board](https://www.infineon.com/evaluation-board/CY8CKIT-041S-MAX) |
| PSOC&trade; 6 | CY8CKIT-062S2-43012 | [Evaluation board](https://www.infineon.com/evaluation-board/CY8CKIT-062S2-43012) |
| PSOC&trade; Edge | KIT\_PSE84\_EVAL | [Evaluation board](https://www.infineon.com/evaluation-board/KIT-PSE84-EVAL) |

## References

1. Infineon Technologies AG: ModusToolbox&trade; Software Training Level 2 – PSOC&trade; MCUs; [Available online](https://github.com/infineon/training-modustoolbox-level2-psoc)
2. Infineon Technologies AG: AN79953 Getting started with PSOC&trade; 4 MCU; [Available online](https://www.infineon.com/assets/row/public/documents/30/42/infineon-an79953-getting-started-psoc-4-mcu-applicationnotes-en.pdf)
3. Infineon Technologies AG: AN228571 Getting started with PSOC&trade; 6 MCU on ModusToolbox&trade; software; [Available online](https://www.infineon.com/assets/row/public/documents/30/42/infineon-an228571-getting-started-psoc6-modustoolbox-applicationnotes-en.pdf)
4. Infineon Technologies AG: AN235935 – Getting started with PSOC&trade; Edge E84 On ModusToolbox&trade;; [Available online](https://www.infineon.com/assets/row/public/documents/30/42/infineon-an235935-getting-started-with-psoc-edge-e8-modustoolbox-applicationnotes-en.pdf)

### Glossary

**RTC** *Real time clock*

**PDL** *Peripheral driver library*

**SCB** *Serial communication block*

**DSL** *Device support library*

**WDT** *Watch dog timer*

## Revision history

| Document revision | Date | Description of changes |
| --- | --- | --- |
| \*\* | 2025-09-30 | Initial release |
| \*A | 2026-05-19 | Updated to the latest Empower template. |
| \*B | 2026-09-08 | Migrated to VS Code IDE from Eclipse IDE. |

## Disclaimer

All referenced product or service names and trademarks are the property of their respective owners.

The Bluetooth&reg; word mark and logos are registered trademarks owned by Bluetooth SIG, Inc., and any use of such marks by Infineon is under license.

PSOC&trade;, formerly known as PSoC&trade;, is a trademark of Infineon Technologies. Any references to PSoC&trade; in this document or others shall be deemed to refer to PSOC&trade;.

---------------------------------------------------------

© Cypress Semiconductor Corporation, 2023-2026. This document is the property of Cypress Semiconductor Corporation, an Infineon Technologies company, and its affiliates ("Cypress").  This document, including any software or firmware included or referenced in this document ("Software"), is owned by Cypress under the intellectual property laws and treaties of the United States and other countries worldwide.  Cypress reserves all rights under such laws and treaties and does not, except as specifically stated in this paragraph, grant any license under its patents, copyrights, trademarks, or other intellectual property rights.  If the Software is not accompanied by a license agreement and you do not otherwise have a written agreement with Cypress governing the use of the Software, then Cypress hereby grants you a personal, non-exclusive, nontransferable license (without the right to sublicense) (1) under its copyright rights in the Software (a) for Software provided in source code form, to modify and reproduce the Software solely for use with Cypress hardware products, only internally within your organization, and (b) to distribute the Software in binary code form externally to end users (either directly or indirectly through resellers and distributors), solely for use on Cypress hardware product units, and (2) under those claims of Cypress's patents that are infringed by the Software (as provided by Cypress, unmodified) to make, use, distribute, and import the Software solely for use with Cypress hardware products.  Any other use, reproduction, modification, translation, or compilation of the Software is prohibited.
<br>
TO THE EXTENT PERMITTED BY APPLICABLE LAW, CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH REGARD TO THIS DOCUMENT OR ANY SOFTWARE OR ACCOMPANYING HARDWARE, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  No computing device can be absolutely secure.  Therefore, despite security measures implemented in Cypress hardware or software products, Cypress shall have no liability arising out of any security breach, such as unauthorized access to or use of a Cypress product. CYPRESS DOES NOT REPRESENT, WARRANT, OR GUARANTEE THAT CYPRESS PRODUCTS, OR SYSTEMS CREATED USING CYPRESS PRODUCTS, WILL BE FREE FROM CORRUPTION, ATTACK, VIRUSES, INTERFERENCE, HACKING, DATA LOSS OR THEFT, OR OTHER SECURITY INTRUSION (collectively, "Security Breach").  Cypress disclaims any liability relating to any Security Breach, and you shall and hereby do release Cypress from any claim, damage, or other liability arising from any Security Breach.  In addition, the products described in these materials may contain design defects or errors known as errata which may cause the product to deviate from published specifications. To the extent permitted by applicable law, Cypress reserves the right to make changes to this document without further notice. Cypress does not assume any liability arising out of the application or use of any product or circuit described in this document. Any information provided in this document, including any sample design information or programming code, is provided only for reference purposes.  It is the responsibility of the user of this document to properly design, program, and test the functionality and safety of any application made of this information and any resulting product.  "High-Risk Device" means any device or system whose failure could cause personal injury, death, or property damage.  Examples of High-Risk Devices are weapons, nuclear installations, surgical implants, and other medical devices.  "Critical Component" means any component of a High-Risk Device whose failure to perform can be reasonably expected to cause, directly or indirectly, the failure of the High-Risk Device, or to affect its safety or effectiveness.  Cypress is not liable, in whole or in part, and you shall and hereby do release Cypress from any claim, damage, or other liability arising from any use of a Cypress product as a Critical Component in a High-Risk Device. You shall indemnify and hold Cypress, including its affiliates, and its directors, officers, employees, agents, distributors, and assigns harmless from and against all claims, costs, damages, and expenses, arising out of any claim, including claims for product liability, personal injury or death, or property damage arising from any use of a Cypress product as a Critical Component in a High-Risk Device. Cypress products are not intended or authorized for use as a Critical Component in any High-Risk Device except to the limited extent that (i) Cypress's published data sheet for the product explicitly states Cypress has qualified the product for use in a specific High-Risk Device, or (ii) Cypress has given you advance written authorization to use the product as a Critical Component in the specific High-Risk Device and you have signed a separate indemnification agreement.
<br>
Cypress, the Cypress logo, and combinations thereof, ModusToolbox, PSoC, CAPSENSE, EZ-USB, F-RAM, and TRAVEO are trademarks or registered trademarks of Cypress or a subsidiary of Cypress in the United States or in other countries. For a more complete list of Cypress trademarks, visit www.infineon.com. Other names and brands may be claimed as property of their respective owners.
