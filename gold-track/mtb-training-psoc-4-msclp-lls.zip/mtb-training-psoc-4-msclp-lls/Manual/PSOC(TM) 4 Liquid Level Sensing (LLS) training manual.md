# PSOC&trade; 4 Liquid level sensing (LLS) training manual

## About this document

This training manual covers the labs for the introduction to liquid level sensing on the PSOC&trade; 4000T and the PSOC&trade; 4100T Plus training.

## Scope and purpose

The labs will cover objectives, project creation, tuning liquid level sensors, and calibrating the foam detection coefficient.

## Intended audience

This manual is intended for design engineers, technicians, and developers of electronic systems.

## Table of contents

* [About this document](#about-this-document)
* [Scope and purpose](#scope-and-purpose)
* [Intended audience](#intended-audience)
* [Introduction](#introduction)
* [Required development tools and prerequisites](#required-development-tools-and-prerequisites)
* [Liquid-level factory calibration procedure](#_Liquid-level_factory_calibration)
* [Liquid-level factory calibration procedure with foam detection enabled](#_Liquid-level_factory_calibration_foam_detection)
* [Foam detection calibration](#foam-detection-calibration)
* [References](#references)
* [Revision history](#revision-history)

## Introduction

This manual provides instructions to create, configure, and build the **PSOC&trade; 4000T MSCLP liquid level sensing** project to optimise the capacitive performance and tune the liquid level sensing algorithms.

## Required development tools and prerequisites

### Tools

- **ModusToolbox&trade; software** v3.9 or later (Recommended installation via [ModusToolbox&trade; Setup tool](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup))
- [**Microsoft Visual Studio Code**](https://code.visualstudio.com/) with the [**ModusToolbox&trade; for VS Code**](https://marketplace.visualstudio.com/items?itemName=InfineonAG.modustoolbox-for-vscode) extension installed
- **ModusToolbox&trade; Programming Tools** v1.9.0 or later (Installed by [ModusToolbox&trade; Setup tool](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup) as a dependency to ModusToolbox&trade; v3.9)
- **ModusToolbox&trade; CAPSENSE&trade; and Multi-Sense Pack** v1.6.0 or later (Recommended installation via [ModusToolbox&trade; Setup tool](https://softwaretools.infineon.com/tools/com.ifx.tb.tool.modustoolboxsetup))
- [**CY8CPROTO-040T-MS**](https://www.infineon.com/evaluation-board/CY8CPROTO-040T-MS), the PSOC&trade; 4000T Multi-Sense Prototyping Kit

<div class="figure-images">
<img src="assets/images/psoc_4000t_multi_sense_prototyping_kit.png" alt="PSOC&trade; 4000T Multi-Sense Prototyping Kit" style="width:456px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

### Prerequisites

- [Introduction to PSOC&trade; 4000T Training](https://infineon-academy.csod.com/ui/lms-learning-details/app/course/073efb2e-7bbc-45ab-819d-12c504682ec0)
- Install the software and obtain the hardware listed in the Required development tools section.

## <span id="_Liquid-level_factory_calibration"></span>Liquid-level factory calibration procedure

### Objective

This manual aims to demonstrate how to implement and evaluate a capacitive liquid-level sensing system using PSOC&trade; 4 microcontrollers equipped with CAPSENSE&trade; with Multisense. The goal is to perform non-contact, accurate measurement of liquid levels in non-conductive containers, understand the effect of capacitance variation caused by the presence of liquid, and perform calibration procedures to ensure reliable detection across varying conditions, including the added ability to reject foam interference.

### Description

The CAPSENSE&trade; block in PSOC&trade; 4 devices operates by charging and discharging the sensor electrode and then measuring the resulting signal to determine capacitance. Functionally, it behaves like a high-resolution sigma-delta converter that translates the sensor’s capacitance into digital counts. The total capacitance measured is the sum of the sensor’s parasitic capacitance and the additional capacitance introduced when a liquid comes in contact with the sensor’s sensing region. As the liquid level rises, this effective capacitance increases, and the CAPSENSE&trade; hardware registers higher counts. By processing these digital values, the system can accurately map the change in capacitance to the corresponding liquid level inside the container.

### Project creation

1. Before creating the first project in this training series, create the workspace. Open **VS Code** from the **Windows Start** menu

> **Note:** If you have not installed ModusToolbox&trade; along with the ModusToolbox&trade; for VS Code extension, see the [Required development tools](#required-development-tools-and-prerequisites) section.

<div class="figure-images">
<img src="assets/images/running_vs_code_from_the_windows_11_search_bar.png" alt="Running VS Code from the Windows 11 Search Bar" style="width:368px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

2. Open a **workspace directory** for your project in VS Code

<div class="figure-images">
<img src="assets/images/opening_vs_code_workspace.png" alt="Opening VS Code Workspace" style="width:466px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

3. Click **File > Open Folder** and choose your workspace directory or create a new folder

4. Click **Select Folder** to open the workspace directory in VS Code

> **Note:** Open the workspace in trusted mode. If the default workspace trust is restricted mode, click **Restricted Mode** in the bottom left and change to trust this folder.

<div class="figure-images">
<img src="assets/images/workspace_opened_in_restricted_mode.png" alt="Opening VS Code Workspace" style="width:738px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

<div class="figure-images">
<img src="assets/images/opening_workspace_in_trusted_mode.png" alt="Opening VS Code Workspace" style="width:680px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

5. Open the **Command Palette** by pressing **Ctrl+Shift+P**

6. Search for **Infineon ModusToolbox&trade;: Show Main Page** and select it

7. Open the **Infineon ModusToolbox&trade; for VS Code** main page

<div class="figure-images">
<img src="assets/images/modustoolbox_for_vs_code_main_page.png" alt="ModusToolbox for VS Code Main Page" style="width:680px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

8. Navigate to the **Create Project** tab and click **Launch Project Creation**

9. The **Project Creator Tool** opens and prompts you to choose a **BSP** (Board Support Package). Select the **CY8CPROTO-040T-MS** BSP under the **PSOC&trade; 4 BSPs**, and continue to the application selection

<div class="figure-images">
<img src="assets/images/select_the_cy8proto_040t_ms_bsp.png" alt="Select the CY8CPROTO-040T-MS BSP" style="width:600px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

10. Select the **MSCLP CAPSENSE&trade; liquid level sensing** application, choose a project directory, and click **Create**

<div class="figure-images">
<img src="assets/images/select_the_msclp_capsense_liquid_level_sensing_application.png" alt="Select the MSCLP CAPSENSE&trade; liquid level sensing application" style="width:600px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

11. When project creation is complete, it will prompt you to **Load Project**. Do this so that the VS Code workspace for the new project is loaded

<div class="figure-images">
<img src="assets/images/load_project.png" alt="Select the MSCLP CAPSENSE&trade; liquid level sensing application" style="width:400px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

12. Once the workspace is loaded, the ModusToolbox&trade; application view provides actions to build, clean, erase, program, and configure the device

<div class="figure-images">
<img src="assets/images/vscode_extension_after_project_creation.png" alt="Select the MSCLP CAPSENSE&trade; liquid level sensing application" style="width:1200px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

> **Note:** The ModusToolbox&trade; for VS Code extension may display buttons indicating that the VS Code tasks and settings need to be updated. Simply click the buttons to correct the issues. This is a minor version mismatch between the ModusToolbox&trade; tools and the VS Code extension and does not affect functionality.

<div class="figure-images">
<img src="assets/images/vscode_fix_settings_and_tasks.png" alt="VS Code extension prompting to fix tasks and settings" style="width:680px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

### Disabling the foam detection feature

This code example enables the foam detection feature by default. This step disables it to demonstrate how to calibrate a liquid level sensor without the foam detection feature.

> **Note:** To complete the liquid level calibration procedure with the foam detection feature enabled, complete the [Initial calibration for foam detection enabled sensors](#_Initial_calibration_for) procedure instead.

1. Open the CAPSENSE&trade; configurator


<div class="figure-images">
<img src="assets/images/launching_capsense_configurator.png" alt="Opening the CAPSENSE&trade; Configurator" style="width:800px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

2. Navigate to the **Advanced tab**, and go to the **Widget Details**. For the **LiquidLevel0** widget, disable the **foam detection** feature


<div class="figure-images">
<img src="assets/images/disable_the_foam_rejection_feature.png" alt="Disable the foam detection feature" style="width:800px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

3. Save the CAPSENSE&trade; configurator

4. In VS Code, open the main.c file and comment out the lines associated with the foam detection widget

```c
for (;;)
{
	// uint32_t level_w_FR, level_wo_FR;
	/* Scan the normal Liquid Level Widget */
	Cy_CapSense_ScanWidget(CY_CAPSENSE_LIQUIDLEVEL0_WDGT_ID, &cy_capsense_context);
	/* Wait until the scan is finished */
	while(Cy_CapSense_IsBusy(&cy_capsense_context)) {}
	// /* Scan the Foam Detection Widget */
	// Cy_CapSense_ScanWidget(CY_CAPSENSE_LIQUIDLEVEL0_FR_WDGT_ID, &cy_capsense_context);
	// /* Wait until the scan is finished */
	// while(Cy_CapSense_IsBusy(&cy_capsense_context)) {}
	/* Process all the widgets */
	Cy_CapSense_ProcessAllWidgets(&cy_capsense_context);
	/* Send CAPSENSE data to the Tuner */
	Cy_CapSense_RunTuner(&cy_capsense_context);
	/* store the liquid level before and after foam detection */
	// level_wo_FR = CY_CAPSENSE_LIQUIDLEVEL0_PTRPOSITION_VALUE->x;
	// level_w_FR = CY_CAPSENSE_LIQUIDLEVEL0_FR_PTRPOSITION_VALUE->x;
	//
	// (void)level_wo_FR;
	// (void)level_w_FR;
}
```

5. Program the device


<div class="figure-images">
<img src="assets/images/program_the_device.png" alt="Program the device" style="width:800px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

### Liquid level calibration procedure

Before calibrating, ensure that the liquid-level sensors are properly tuned following the guidance in the “Tuning Procedure” section of PSOC&trade; 4: [MSCLP CAPSENSE&trade; liquid-level sensing code example](https://github.com/Infineon/mtb-example-psoc4-msclp-lls?tab=readme-ov-file#tuning-procedure).

1. Open the CAPSENSE&trade; tuner


<div class="figure-images">
<img src="assets/images/launching_capsense_tuner.png" alt="Opening the CAPSENSE&trade; tuner" style="width:800px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

2. Connect to the device, select all widgets and sensor, and then start streaming

<div class="figure-images">
<img src="assets/images/capsense_tuner_widget_view.png" alt="CAPSENSE&trade; Tuner Widget view" style="width:400px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

3. Navigate to the **Liquid level measurement** tab. Since the code example was calibrated with the foam detection enabled, you will need to clear the results before beginning the calibration process


<div class="figure-images">
<img src="assets/images/clearing_the_results_from_the_previous_calibration.png" alt="Clearing the results from the previous calibration" style="width:400px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

4. With the tank empty, complete the process shown in the tool


<div class="figure-images">
<img src="assets/images/locking_cdac_calibration_parameters.png" alt="Locking CDAC calibration parameters" style="width:800px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

> **Note:** This process allows the device to calibrate the sensors to the empty tank, then locks those calibration parameters.

5. In the CAPSENSE&trade; Tuner, configure the system parameters:
    - **Tank height**: The total height of the liquid to be measured in mm
    - **Minimum resolution (height step)**: The minimum change in liquid depth you would like to measure. Note that the amount of calibration data you need to collect is inversely proportional to this value. Lower minimum resolution values yield more data collection
    - **Number of averaged samples per step**: The number of raw count samples that are averaged to yield one data point while logging data. Higher values increase data logging time and accuracy. Note that if foam detection is enabled, the minimum resolution and number of averaged samples per step will only be configurable after completing the [Initial calibration for foam detection enabled sensors](#_Initial_calibration_for)


<div class="figure-images">
<img src="assets/images/set_the_tank_settings.png" alt="Set the tank settings" style="width:1200px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

6. <span id="_Liquid_level_calibration_1"></span>Incrementally fill the tank in steps defined by the resolution and log the data at each level. For each subsequent step, fill the tank to the level indicated by the minimum resolution and log data


<div class="figure-images">
<img src="assets/images/log_tank_data.png" alt="Log tank data" style="width:1200px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

> **Note:** You can navigate to any level by clicking previous/next level. Click **Log Data** after filling in the next level every time.


<div class="figure-images">
<img src="assets/images/navigating_to_previous_or_next_levels.png" alt="Navigating to previous or next levels" style="width:1200px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

7. <span id="_Liquid_level_calibration_2"></span>Click **Forward**, and then finish the calibration after logging the data


<div class="figure-images">
<img src="assets/images/finishing_calibration.png" alt="Finishing calibration" style="width:800px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

> **Note:** Multiple units and multiple profiles can be created at this step. This allows for the calibration of the same sensor hardware to different scenarios or for using multiple units to calibrate for the same scenario, making the data set more robust.

> **Note:** If you are completing the [Initial calibration for foam detection enabled sensors](#_foam_detection_data_logging) procedure, return to that step now to continue.


8. Once the calibration is complete, you can see the accuracy and error plots


<div class="figure-images">
<img src="assets/images/linearity_plots.png" alt="Linearity plots" style="width:1200px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

9. Select **Apply to Project**, and then disconnect from the tuner


<div class="figure-images">
<img src="assets/images/applying_the_settings_to_the_project_and_disconnecting_the_tuner.png" alt="Applying the settings to the project and disconnecting the tuner" style="width:680px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

10. Program the part to apply the calibration to the device

<div class="figure-images">
<img src="assets/images/program_the_device.png" alt="Programming the device" style="width:800px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

11. Empty the tank

12. Reconnect to the tuner and navigate to the **Graph View** tab


<div class="figure-images">
<img src="assets/images/showing_the_graph_view_after_connecting.png" alt="Showing the Graph view after connecting" style="width:1200px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

13. Observe the liquid level displayed in the Position graph

<div class="figure-images">
<img src="assets/images/fluctuating_liquid_level_position.png" alt="Fluctuating liquid level position" style="width:800px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

14. If readings fluctuate, apply digital filtering methods such as IIR, median, averaging, or jitter filters in CAPSENSE&trade; Configurator for improved stability

<div class="figure-images">
<img src="assets/images/enabling_filters.png" alt="Enabling filters" style="width:680px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

- **IIR filter**: Programmable filter that behaves as a lowpass filter. Lower coefficient values have a lower cutoff frequency and reduce response time
- **Median filter**: Averages three samples to remove noise spikes
- **Average filter**: Averages two samples to remove periodic noise
- **Jitter filter**: Eliminates toggling noise

### Output


<div class="figure-images">
<img src="assets/images/lls_tank_connected_to_the_device.jpg" alt="LLS tank connected to the device" style="width:400px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

Fill the tank with a known amount and check if the position closely matches the expected value. The expected position value is defined by the equation below.

$$
\mathrm{Position} = \mathrm{PositionMax} \times \frac{\mathrm{Minimum\ resolution}}{\mathrm{Tank\ height}} \times \mathrm{LiquidLevelCurrent}
$$

- **PositionMax**: The liquid-level sensor widget’s maximum Level parameter
- **Minimum resolution**: Minimum resolution set in the tuner
- **Tank height**: Tank height value set in the tuner
- **LiquidLevelCurrent**: The current level of liquid is present in the container

### Conclusion

The implementation of liquid level sensing using Infineon’s PSOC&trade; 4 CAPSENSE&trade; technology provides reliable, accurate, and non-invasive liquid level detection methods. By utilising capacitive sensing principles, the system effectively measures liquid levels through the walls of non-conductive containers, eliminating direct contact with the liquid. The manual provides insights into how the factors affect sensor performance and the importance of precise and reliable liquid detection.

Through proper calibration, the sensing solution delivers high-resolution measurements with robustness under real-world operating conditions for water. The integration of the ModusToolbox software tools further simplifies sensor configuration, tuning, and optimisation, making the approach scalable and adaptable to a wide range of applications.

## <span id="_Liquid-level_factory_calibration_foam_detection"></span>Liquid-level factory calibration procedure with foam detection enabled

### Description

Foam on the liquid surface can cause false readings in the capacitive liquid level. The foam detection process compensates for this by detecting and filtering out the capacitance contribution of foam. During calibration, the system measures both the actual liquid level and the foam-affected readings, calculates a correction factor, and applies it in firmware. This ensures that the sensor accurately reports the true liquid level, even in the presence of bubbles or foam.

### Enabling foam detection

1. To re-enable foam detection for the code example, open the CAPSENSE&trade; Configurator and navigate to the widget details


<div class="figure-images">
<img src="assets/images/enabling_foam_rejection.png" alt="Enabling foam detection" style="width:555px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

2. In VS Code, open the main.c file and add the lines associated with the foam detection widget

```c
for (;;)
{
	uint32_t level_w_FR, level_wo_FR;
	/* Scan the normal Liquid Level Widget */
	Cy_CapSense_ScanWidget(CY_CAPSENSE_LIQUIDLEVEL0_WDGT_ID,
	                       &cy_capsense_context);
	/* Wait until the scan is finished */
	while (Cy_CapSense_IsBusy(&cy_capsense_context))
	{
	}
	/* Scan the Foam Detection Widget */
	Cy_CapSense_ScanWidget(CY_CAPSENSE_LIQUIDLEVEL0_FR_WDGT_ID,
	                       &cy_capsense_context);
	/* Wait until the scan is finished */
	while (Cy_CapSense_IsBusy(&cy_capsense_context))
	{
	}
	/* Process all the widgets */
	Cy_CapSense_ProcessAllWidgets(&cy_capsense_context);
	/* Send CAPSENSE data to the Tuner */
	Cy_CapSense_RunTuner(&cy_capsense_context);
	/* Store the liquid level before and after foam detection */
	level_wo_FR = CY_CAPSENSE_LIQUIDLEVEL0_PTRPOSITION_VALUE->x;
	level_w_FR = CY_CAPSENSE_LIQUIDLEVEL0_FR_PTRPOSITION_VALUE->x;
	/* Keep the compiler happy */
	(void)level_wo_FR;
	(void)level_w_FR;
}
```

3. Program the device<span id="_Initial_calibration_for"></span>

### Initial calibration for foam detection enabled sensors

Before calibrating, ensure that the liquid-level sensors are properly tuned following the guidance in the “Tuning Procedure” section of PSOC&trade; 4: [MSCLP CAPSENSE&trade; liquid-level sensing code example](https://github.com/Infineon/mtb-example-psoc4-msclp-lls?tab=readme-ov-file#tuning-procedure)

1. If the liquid level calibration was completed with foam detection disabled, clear the results by pressing **OK** in the pop-up window


<div class="figure-images">
<img src="assets/images/clearing_the_results_from_the_previous_calibration.png" alt="Clearing results" style="width:400px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

2. With the tank empty, complete the process shown in the tool


<div class="figure-images">
<img src="assets/images/locking_cdac_calibration_parameters.png" alt="Locking CDAC calibration parameters" style="width:800px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

> **Note:** This process allows the device to calibrate the sensors to the empty tank, then locks those calibration parameters.

3. Set the tank height


<div class="figure-images">
<img src="assets/images/setting_the_tank_height_foam_detection.png" alt="Setting the tank height" style="width:800px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

4. With the tank empty, log the empty data


<div class="figure-images">
<img src="assets/images/empty_tank_calibration_for_foam_rejection.png" alt="Empty tank calibration for foam detection" style="width:210px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

5. Fill the tank halfway, ensure that the step in the tool is halfway, and then log the data

6. Press the **Forward** button

7. <span id="_foam_detection_data_logging"></span>Repeat the data logging steps (steps 6 and 7) from the [Liquid level calibration procedure](#_Liquid_level_calibration_1) to complete the calibration

8. When the foam detection feature is enabled, the charts will show accuracy and error plots for the liquid level and foam detection widgets


<div class="figure-images">
<img src="assets/images/linearity_plots_for_liquid_level_and_foam_rejection_widgets.png" alt="Linearity plots for liquid level and foam detection widgets" style="width:1200px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

## Foam detection calibration

The foam detection widget contains an additional parameter – the foam correction coefficient that determines how much compensation is applied to the level detection to remove signal from the foam. The foam correction coefficient is given by the following equation:

$$
\mathrm{Coeff}_{\mathrm{foam}} = 256 \times \frac{\mathrm{Level}_{\mathrm{Foam}} - \mathrm{Level}_{\mathrm{known}}}{\mathrm{Level}_{\mathrm{liquid}} - \mathrm{Level}_{\mathrm{foam}}}
$$

- $\mathrm{Level}_{\mathrm{Foam}}$: The level displayed by the CAPSENSE&trade; Tuner for the foam detection widget
- $\mathrm{Level}_{\mathrm{known}}$: The level of the target liquid known by measurement with an external tool
- $\mathrm{Level}_{\mathrm{liquid}}$: The level displayed by the CAPSENSE&trade; Tuner for the base liquid-level widget

To calculate the foam correction coefficient, ensure that you have correctly followed the process detailed in [the Liquid-level factory calibration procedure with foam detection enabled](#_Liquid-level_factory_calibration_foam_detection). Then, perform the following steps:

1. Fill the tank to a known liquid level and generate foam on the surface using a surfactant

2. Enable both liquid level and foam detection widgets in the CAPSENSE&trade; Tuner


<div class="figure-images">
<img src="assets/images/tuner_data_showing_the_position_of_the_liquid_level_base_and_foam_detected.png" alt="Tuner data showing the position of the liquid level base and foam detection widgets" style="width:1200px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

3. Record sensor outputs ($\mathrm{Level}_{\mathrm{Foam}}$, $\mathrm{Level}_{\mathrm{known}}$, and $\mathrm{Level}_{\mathrm{liquid}}$)

4. Calculate the foam correction coefficient to adjust for measurement deviation caused by foam

5. For example: If $\mathrm{Level}_{\mathrm{Foam}}$ is 65, $\mathrm{Level}_{\mathrm{known}}$ is 60, and $\mathrm{Level}_{\mathrm{liquid}}$ is 68, the foam correction coefficient will be 427 (rounded to the nearest whole number)

6. Apply the correction factor in firmware and validate readings to ensure that the output matches the actual liquid level


<div class="figure-images">
<img src="assets/images/applying_the_foam_correction_coefficient.png" alt="Applying the foam correction coefficient" style="width:414px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

### Output


<div class="figure-images">
<img src="assets/images/liquid_level_with_foam_ignored.png" alt="Liquid level and foam detection level" style="width:1200px; max-width:100%; height:auto; display:block; margin:0 auto;" />
</div>

### Conclusion

The foam detection process ensures accurate liquid level measurements by compensating for the capacitance effect of foam. By applying a correction factor during calibration, the system reliably distinguishes between actual liquid and foam, maintaining precise readings under real-world conditions.

This manual guides you through setting up, calibrating, and operating a Liquid Level Sensing (LLS) system, gaining hands-on experience in real-time monitoring, accurate measurement of liquid levels, and understanding the principles behind the sensor’s operation and response. Also, the benefit of using this manual is that it will guide you through step-by-step procedures in detail so that you understand the significance of every step as you perform them.

## References

1. Infineon Technologies AG : AN239805: Liquid-level sensing with PSOC&trade; 4 CAPSENSE&trade; ; [Available online](https://www.infineon.com/row/public/documents/30/42/infineon-an239805-liquid-level-sensing-PSOC-4-capsense-applicationnotes-en.pdf)


## Revision history

| Document revision | Date | Description of changes |
| :--- | :--- | :--- |
| \*\* | 2025-12-12 | Initial release. |
| \*A | 2026-04-07 | Updated to align with the Empower template. |

## Disclaimer

All referenced product or service names and trademarks are the property of their respective owners.

The Bluetooth&reg; word mark and logos are registered trademarks owned by Bluetooth SIG, Inc., and any use of such marks by Infineon is under license.

PSOC&trade;, formerly known as PSoC&trade;, is a trademark of Infineon Technologies. Any references to PSoC&trade; in this document or others shall be deemed to refer to PSOC&trade;.

---------------------------------------------------------

© Cypress Semiconductor Corporation, 2023-2026. This document is the property of Cypress Semiconductor Corporation, an Infineon Technologies company, and its affiliates ("Cypress").  This document, including any software or firmware included or referenced in this document ("Software"), is owned by Cypress under the intellectual property laws and treaties of the United States and other countries worldwide.  Cypress reserves all rights under such laws and treaties and does not, except as specifically stated in this paragraph, grant any license under its patents, copyrights, trademarks, or other intellectual property rights.  If the Software is not accompanied by a license agreement and you do not otherwise have a written agreement with Cypress governing the use of the Software, then Cypress hereby grants you a personal, non-exclusive, nontransferable license (without the right to sublicense) (1) under its copyright rights in the Software (a) for Software provided in source code form, to modify and reproduce the Software solely for use with Cypress hardware products, only internally within your organization, and (b) to distribute the Software in binary code form externally to end users (either directly or indirectly through resellers and distributors), solely for use on Cypress hardware product units, and (2) under those claims of Cypress's patents that are infringed by the Software (as provided by Cypress, unmodified) to make, use, distribute, and import the Software solely for use with Cypress hardware products.  Any other use, reproduction, modification, translation, or compilation of the Software is prohibited.
<br>
TO THE EXTENT PERMITTED BY APPLICABLE LAW, CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH REGARD TO THIS DOCUMENT OR ANY SOFTWARE OR ACCOMPANYING HARDWARE, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  No computing device can be absolutely secure.  Therefore, despite security measures implemented in Cypress hardware or software products, Cypress shall have no liability arising out of any security breach, such as unauthorized access to or use of a Cypress product. CYPRESS DOES NOT REPRESENT, WARRANT, OR GUARANTEE THAT CYPRESS PRODUCTS, OR SYSTEMS CREATED USING CYPRESS PRODUCTS, WILL BE FREE FROM CORRUPTION, ATTACK, VIRUSES, INTERFERENCE, HACKING, DATA LOSS OR THEFT, OR OTHER SECURITY INTRUSION (collectively, "Security Breach").  Cypress disclaims any liability relating to any Security Breach, and you shall and hereby do release Cypress from any claim, damage, or other liability arising from any Security Breach.  In addition, the products described in these materials may contain design defects or errors known as errata which may cause the product to deviate from published specifications. To the extent permitted by applicable law, Cypress reserves the right to make changes to this document without further notice. Cypress does not assume any liability arising out of the application or use of any product or circuit described in this document. Any information provided in this document, including any sample design information or programming code, is provided only for reference purposes.  It is the responsibility of the user of this document to properly design, program, and test the functionality and safety of any application made of this information and any resulting product.  "High-Risk Device" means any device or system whose failure could cause personal injury, death, or property damage.  Examples of High-Risk Devices are weapons, nuclear installations, surgical implants, and other medical devices.  "Critical Component" means any component of a High-Risk Device whose failure to perform can be reasonably expected to cause, directly or indirectly, the failure of the High-Risk Device, or to affect its safety or effectiveness.  Cypress is not liable, in whole or in part, and you shall and hereby do release Cypress from any claim, damage, or other liability arising from any use of a Cypress product as a Critical Component in a High-Risk Device. You shall indemnify and hold Cypress, including its affiliates, and its directors, officers, employees, agents, distributors, and assigns harmless from and against all claims, costs, damages, and expenses, arising out of any claim, including claims for product liability, personal injury or death, or property damage arising from any use of a Cypress product as a Critical Component in a High-Risk Device. Cypress products are not intended or authorized for use as a Critical Component in any High-Risk Device except to the limited extent that (i) Cypress's published data sheet for the product explicitly states Cypress has qualified the product for use in a specific High-Risk Device, or (ii) Cypress has given you advance written authorization to use the product as a Critical Component in the specific High-Risk Device and you have signed a separate indemnification agreement.
<br>
Cypress, the Cypress logo, and combinations thereof, ModusToolbox, PSoC, CAPSENSE, EZ-USB, F-RAM, and TRAVEO are trademarks or registered trademarks of Cypress or a subsidiary of Cypress in the United States or in other countries. For a more complete list of Cypress trademarks, visit www.infineon.com. Other names and brands may be claimed as property of their respective owners.