# Zephyr Windows Prework Bundle

Installs all 8 official Zephyr Windows dependencies to your user profile —
no admin rights required, no Scoop, no winget, no Chocolatey.

## Quick start

1. Get the repo onto your machine, either way works:
   - **Download:** from the GitLab repo page, use "Download source code" →
     `zip` to get `zephyr-windows-training-prereqs-main.zip`, then extract
     it. The exact destination folder doesn't matter — anywhere you can
     find again (e.g. `Downloads` or `Desktop`) is fine, as long as
     `setup-zephyr-windows-deps.ps1` and `gperf-dtc-windows-bundle.zip` end
     up in the same folder after extracting.
   - **Clone:**
     ```powershell
     git clone https://gitlab.intra.infineon.com/JarvisC/zephyr-windows-training-prereqs.git
     ```
2. Open a regular (non-admin) PowerShell window and navigate into that
   folder (wherever you extracted or cloned it), e.g.:
   ```powershell
   cd zephyr-windows-training-prereqs
   ```
3. Run:
   ```powershell
   powershell -ExecutionPolicy Bypass -File .\setup-zephyr-windows-deps.ps1
   ```
4. Close and reopen your terminal when it finishes.

The script downloads each tool's official vendor package, installs
everything to your user profile, wires up your **User** PATH, and prints a
pass/fail check for all 8 tools. Safe to re-run — it skips steps that are
already done.

## How do I know it worked?

The last thing the script prints is a verification table, one line per
tool:

```
==> Verifying installed tools
  [OK] cmake    cmake version 4.4.2
  [OK] ninja    1.13.2
  [OK] python   Python 3.12.10
  [OK] git      git version 2.55.0.windows.5
  [OK] wget     GNU Wget 1.21.4 built on mingw32.
  [OK] 7z
  [OK] gperf    GNU gperf 3.3
  [OK] dtc      Version: DTC 1.7.2
```

**All 8 lines showing `[OK]` means you're done — no further action
needed.** If any line instead shows `[MISSING]`, close and reopen your
terminal (PATH changes only take effect in a new window) and re-run the
script once — it will skip everything already installed and only retry
what's missing. If a tool still shows `[MISSING]` after that, see the
Troubleshooting sections below.

## Uninstalling

```powershell
powershell -ExecutionPolicy Bypass -File .\uninstall-zephyr-windows-deps.ps1
```

Only removes tools this script installed — never touches anything you
already had before running setup.

## Contents

| File | Purpose |
|---|---|
| `setup-zephyr-windows-deps.ps1` | One-shot installer/verifier |
| `uninstall-zephyr-windows-deps.ps1` | Removes everything the setup script installed |
| `Restore-ZephyrPrereqsPath.ps1` | Restores your User PATH from a backup taken before setup/uninstall ran |
| `gperf-dtc-windows-bundle.zip` | Standalone `gperf.exe` + `dtc.exe` + runtime DLLs |

### Bundle zip contents

| File | Purpose |
|---|---|
| `dtc.exe` | Device-tree compiler (v1.7.2) |
| `gperf.exe` | Perfect hash generator (v3.3) |
| `libfdt-1.dll` | dtc runtime dependency |
| `libyaml-0-2.dll` | dtc runtime dependency |
| `libgcc_s_seh-1.dll`, `libstdc++-6.dll`, `libwinpthread-1.dll` | Shared MinGW runtime, required by both exes |

Both binaries were rebuilt from the same upstream MSYS2 packages that
`oss-winget.dtc` / `oss-winget.gperf` themselves install from
(`repo.msys2.org/mingw/mingw64`), just extracted directly instead of via
winget. No installer, no admin rights, no registry changes.

## Troubleshooting: "running scripts is disabled on this system"

Run the script with:
```powershell
powershell -ExecutionPolicy Bypass -File .\setup-zephyr-windows-deps.ps1
```
This only affects the single script invocation — no persistent machine
setting is changed, and no admin rights are required.

## Troubleshooting: an installer prompts for admin/elevated permissions

Get the latest `setup-zephyr-windows-deps.ps1` from this repo and re-run.

## Troubleshooting: `python` shows `[??] found but failed to run`

Windows ships a fake `python.exe` "app execution alias" in
`%LOCALAPPDATA%\Microsoft\WindowsApps` on every profile, whether or not
Python is actually installed - it's a placeholder, not a real
interpreter, and errors out (or opens the Microsoft Store) if run
directly. Get the latest `setup-zephyr-windows-deps.ps1` from this repo
and re-run - it now detects this stub and installs a real Python
alongside it, prioritizing the real one on PATH.

## Troubleshooting: a tool shows `[??] ... exited -1` but the version looks correct

This is a display bug in an older version of the verification step, not a
failed install. If the line shows a correct version string next to the
`-1`, that tool is installed and working fine — no action needed. Get the
latest `setup-zephyr-windows-deps.ps1` from this repo and re-run to get a
clean `[OK]` line instead.

## Troubleshooting: `wget` looks "not found" or errors oddly

Windows PowerShell has a built-in `wget` alias for `Invoke-WebRequest` that
shadows the real installed `wget.exe`. If typing `wget --version` directly
in PowerShell gives a "remote name could not be resolved" error, that's the
alias, not a failed install — use `wget.exe --version` instead (the setup
script's verification step already accounts for this).

