#Requires -Version 5.1
<#
  Zephyr Windows prework: restore your User PATH from a backup taken by
  setup-zephyr-windows-deps.ps1 or uninstall-zephyr-windows-deps.ps1.

  Both of those scripts write a timestamped, plain-text snapshot of your
  User PATH to %USERPROFILE%\tools\path-backups\ before making any changes.
  Use this script if your PATH ever looks wrong and you want to roll back
  to exactly what it was at one of those snapshot points.

  Usage:
    .\Restore-ZephyrPrereqsPath.ps1              # lists available backups, asks which to restore
    .\Restore-ZephyrPrereqsPath.ps1 -File <path> # restores a specific backup file directly
#>

param(
    [string]$File
)

$ErrorActionPreference = "Stop"
$BackupDir = Join-Path $env:USERPROFILE "tools\path-backups"

if (-not (Test-Path $BackupDir)) {
    Write-Host "No backup folder found at $BackupDir - nothing to restore from." -ForegroundColor Red
    exit 1
}

if (-not $File) {
    $backups = Get-ChildItem $BackupDir -Filter "*.txt" | Sort-Object LastWriteTime -Descending
    if ($backups.Count -eq 0) {
        Write-Host "No backup files found in $BackupDir." -ForegroundColor Red
        exit 1
    }
    Write-Host "Available PATH backups (newest first):`n"
    for ($i = 0; $i -lt $backups.Count; $i++) {
        Write-Host ("  [{0}] {1}  ({2})" -f $i, $backups[$i].Name, $backups[$i].LastWriteTime)
    }
    $choice = Read-Host "`nEnter the number of the backup to restore (or Ctrl+C to cancel)"
    $File = $backups[[int]$choice].FullName
}

if (-not (Test-Path $File)) {
    Write-Host "File not found: $File" -ForegroundColor Red
    exit 1
}

$restoredPath = Get-Content $File -Raw
$currentPath  = [System.Environment]::GetEnvironmentVariable("Path", "User")

# Always snapshot what's about to be overwritten, so restoring is itself
# reversible.
$safetyStamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
$safetyFile  = Join-Path $BackupDir "user-path-before-restore-$safetyStamp.txt"
$currentPath | Set-Content -Path $safetyFile -Encoding UTF8 -NoNewline

Write-Host "`nRestoring from: $File"
Write-Host "Current PATH backed up to: $safetyFile (in case you need to undo this restore too)"
[System.Environment]::SetEnvironmentVariable("Path", $restoredPath, "User")
Write-Host "`nDone. Close and reopen your terminal to see the restored PATH." -ForegroundColor Green
