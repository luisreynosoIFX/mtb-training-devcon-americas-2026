#Requires -Version 5.1
<#
  Zephyr Windows prework: companion uninstaller for setup-zephyr-windows-deps.ps1.

  Safety guarantee: this script ONLY removes tools that
  setup-zephyr-windows-deps.ps1 actually installed on this machine. It
  reads the install manifest written by that script
  (%USERPROFILE%\tools\zephyr-prereqs-install-manifest.json) and skips any
  tool marked as "already present" during install - so if you had cmake,
  git, python, etc. installed *before* running the setup script, this
  uninstaller will never touch them.

  If the manifest file is missing (e.g. it was deleted, or the setup script
  was never run on this machine), this script refuses to do anything and
  tells you so - there is no safe fallback guess here.

  Usage:
    1. Open a regular (non-admin) PowerShell window.
    2. Run: .\uninstall-zephyr-windows-deps.ps1
    3. Close and reopen your terminal when it finishes.
#>

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ToolsDir  = Join-Path $env:USERPROFILE "tools"
$TempDir   = Join-Path $env:TEMP "zephyr-prereqs"
$ManifestPath = Join-Path $ToolsDir "zephyr-prereqs-install-manifest.json"
$BackupDir = Join-Path $ToolsDir "path-backups"

function Write-Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Cyan }

# Extra safety net, independent of the manifest logic below: before doing
# anything, take a fresh backup of the CURRENT User PATH (i.e. the state
# right before this uninstall runs), so this run itself is always
# reversible too - not just the original install.
if (Test-Path $BackupDir) {
    $preUninstallStamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
    $preUninstallFile = Join-Path $BackupDir "user-path-before-uninstall-$preUninstallStamp.txt"
    [System.Environment]::GetEnvironmentVariable("Path", "User") | Set-Content -Path $preUninstallFile -Encoding UTF8 -NoNewline
    Write-Host "Backed up your current User PATH (pre-uninstall) to: $preUninstallFile"
}

if (-not (Test-Path $ManifestPath)) {
    Write-Host "No install manifest found at $ManifestPath." -ForegroundColor Red
    Write-Host "This means either setup-zephyr-windows-deps.ps1 was never run on this" -ForegroundColor Red
    Write-Host "machine, or the manifest was deleted. Nothing will be uninstalled, because" -ForegroundColor Red
    Write-Host "there is no safe way to tell which tools this script installed vs. tools" -ForegroundColor Red
    Write-Host "you already had. Exiting without changes." -ForegroundColor Red
    if (Test-Path $BackupDir) {
        Write-Host "`nIf your PATH looks wrong for an unrelated reason, restore an earlier" -ForegroundColor Yellow
        Write-Host "snapshot from $BackupDir (see the README's 'Restoring PATH from backup' section)." -ForegroundColor Yellow
    }
    exit 1
}

$Manifest = Get-Content $ManifestPath -Raw | ConvertFrom-Json

New-Item -ItemType Directory -Path $TempDir -Force | Out-Null

function Remove-UserPath($dir) {
    $userPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
    if (-not $userPath) { return }
    $parts = $userPath -split ';' | Where-Object { $_ -and ($_.TrimEnd('\') -ne $dir.TrimEnd('\')) }
    $newPath = ($parts -join ';')
    if ($newPath -ne $userPath) {
        [System.Environment]::SetEnvironmentVariable("Path", $newPath, "User")
        Write-Host "  Removed $dir from your User PATH."
    }
    $env:Path = ($env:Path -split ';' | Where-Object { $_ -and ($_.TrimEnd('\') -ne $dir.TrimEnd('\')) }) -join ';'
}

function Get-File($url, $dest) {
    if (Test-Path $dest) { return }
    Write-Host "  Downloading $url ..."
    Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing
}

function Invoke-Uninstaller($name, $path, $argString) {
    Write-Host "  Uninstalling $name - a progress window may appear, please wait..."
    $proc = Start-Process -FilePath $path -ArgumentList $argString -Wait -PassThru
    if ($proc.ExitCode -ne 0) {
        Write-Warning ("  {0} uninstaller exited with code {1}." -f $name, $proc.ExitCode)
    } else {
        Write-Host "  $name uninstalled (exit code 0)."
    }
    return $proc.ExitCode
}

$skipped = [System.Collections.Generic.List[string]]::new()
$removed = [System.Collections.Generic.List[string]]::new()

# 1. cmake (self-contained zip - just delete the folder)
Write-Step "CMake"
if ($Manifest.cmake) {
    $cmakeDir = Join-Path $ToolsDir "cmake"
    if (Test-Path $cmakeDir) { Remove-Item -Recurse -Force $cmakeDir }
    Remove-UserPath (Join-Path $cmakeDir "bin")
    $removed.Add("cmake")
} else {
    Write-Host "  Skipping - was already installed before setup ran (or never installed by it)."
    $skipped.Add("cmake")
}

# 2. ninja (self-contained zip - just delete the folder)
Write-Step "Ninja"
if ($Manifest.ninja) {
    $ninjaDir = Join-Path $ToolsDir "ninja"
    if (Test-Path $ninjaDir) { Remove-Item -Recurse -Force $ninjaDir }
    Remove-UserPath $ninjaDir
    $removed.Add("ninja")
} else {
    Write-Host "  Skipping - was already installed before setup ran (or never installed by it)."
    $skipped.Add("ninja")
}

# 3. Python (official installer's own /uninstall flag)
Write-Step "Python"
if ($Manifest.python) {
    $pyExe = Join-Path $TempDir "python-3.12.10-amd64.exe"
    $pyInstallDir = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312"
    Get-File "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe" $pyExe
    Invoke-Uninstaller "Python" $pyExe "/uninstall /passive InstallAllUsers=0" | Out-Null
    Remove-UserPath $pyInstallDir
    Remove-UserPath (Join-Path $pyInstallDir "Scripts")
    $removed.Add("python")
} else {
    Write-Host "  Skipping - was already installed before setup ran (or never installed by it)."
    $skipped.Add("python")
}

# 4. Git for Windows (Inno Setup - has its own unins000.exe)
Write-Step "Git for Windows"
if ($Manifest.git) {
    $gitUninstaller = Join-Path $env:LOCALAPPDATA "Programs\Git\unins000.exe"
    if (Test-Path $gitUninstaller) {
        Invoke-Uninstaller "Git for Windows" $gitUninstaller "/SILENT /NORESTART /SUPPRESSMSGBOXES" | Out-Null
        $removed.Add("git")
    } else {
        Write-Warning "  Git uninstaller not found at $gitUninstaller - it may have been moved or reinstalled elsewhere. Skipping."
        $skipped.Add("git")
    }
} else {
    Write-Host "  Skipping - was already installed before setup ran (or never installed by it)."
    $skipped.Add("git")
}

# 5. wget (self-contained zip - just delete the folder)
Write-Step "wget"
if ($Manifest.wget) {
    $wgetDir = Join-Path $ToolsDir "wget"
    if (Test-Path $wgetDir) { Remove-Item -Recurse -Force $wgetDir }
    Remove-UserPath $wgetDir
    $removed.Add("wget")
} else {
    Write-Host "  Skipping - was already installed before setup ran (or never installed by it)."
    $skipped.Add("wget")
}

# 6. 7-Zip (self-contained portable console build - just delete the folder)
Write-Step "7-Zip"
if ($Manifest.sevenzip) {
    $sevenZipDir = Join-Path $ToolsDir "7-zip"
    if (Test-Path $sevenZipDir) { Remove-Item -Recurse -Force $sevenZipDir }
    Remove-UserPath $sevenZipDir
    $removed.Add("7zip")
} else {
    Write-Host "  Skipping - was already installed before setup ran (or never installed by it)."
    $skipped.Add("7zip")
}

# 7. gperf + dtc (self-contained zip - just delete the folder)
Write-Step "gperf + dtc"
if ($Manifest.gperfdtc) {
    $gperfDtcDir = Join-Path $ToolsDir "gperf-dtc"
    if (Test-Path $gperfDtcDir) { Remove-Item -Recurse -Force $gperfDtcDir }
    Remove-UserPath $gperfDtcDir
    $removed.Add("gperf-dtc")
} else {
    Write-Host "  Skipping - was already installed before setup ran (or never installed by it)."
    $skipped.Add("gperf-dtc")
}

# The manifest has now served its purpose - remove it so a future setup run
# starts from a clean slate and re-tracks installs correctly.
Remove-Item -Force $ManifestPath

Write-Step "Summary"
if ($removed.Count -gt 0) {
    Write-Host "  Uninstalled: $($removed -join ', ')" -ForegroundColor Green
} else {
    Write-Host "  Nothing was uninstalled - every tool was already present before setup ran." -ForegroundColor Yellow
}
if ($skipped.Count -gt 0) {
    Write-Host "  Left untouched (pre-existing before setup, or not found): $($skipped -join ', ')" -ForegroundColor Cyan
}
Write-Host "`nDone. Close and reopen your terminal to pick up the PATH changes."
