#Requires -Version 5.1
<#
  Zephyr Windows prework: one-shot dependency installer (native installers).

  Installs cmake, ninja, python, git, wget, 7zip via each vendor's own
  official installer (MSI/EXE/zip), plus the bundled gperf/dtc. No Scoop,
  no winget, no Chocolatey, no admin rights required.

  Why this approach: Scoop's own installer hard-refuses to run under
  PowerShell Constrained Language Mode ("Scoop requires PowerShell
  FullLanguage mode to run"), which several Infineon-managed machines
  enforce via WDAC policies that vary by device/build. This script
  sidesteps that entirely - it only uses Invoke-WebRequest, Expand-Archive,
  and Start-Process to launch native installers, all of which work under
  Constrained Language Mode because the installers run as independent
  Win32 processes, unaffected by the calling shell's language mode.

  Usage:
    1. Place this script and gperf-dtc-windows-bundle.zip in the same folder.
    2. Open a regular (non-admin) PowerShell window.
    3. Run: .\setup-zephyr-windows-deps.ps1
    4. Close and reopen your terminal when it finishes.
#>

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ToolsDir  = Join-Path $env:USERPROFILE "tools"
$TempDir   = Join-Path $env:TEMP "zephyr-prereqs"
$ManifestPath = Join-Path $ToolsDir "zephyr-prereqs-install-manifest.json"

function Write-Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Cyan }

New-Item -ItemType Directory -Path $ToolsDir -Force | Out-Null
New-Item -ItemType Directory -Path $TempDir -Force | Out-Null

# Safety net: back up the current User PATH verbatim before this script
# touches anything, regardless of what else may or may not go wrong. This is
# independent of the install manifest below - the manifest lets the
# uninstall script surgically remove only what it added, but this raw
# backup guarantees a full, restorable copy of your PATH exists no matter
# what (including if it's ever corrupted by something outside this script's
# control, e.g. a third-party installer).
$BackupDir = Join-Path $ToolsDir "path-backups"
New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
$backupStamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
$backupFile = Join-Path $BackupDir "user-path-backup-$backupStamp.txt"
[System.Environment]::GetEnvironmentVariable("Path", "User") | Set-Content -Path $backupFile -Encoding UTF8 -NoNewline
Write-Host "Backed up your current User PATH to: $backupFile"
Write-Host "(Keep this file - if anything looks wrong afterwards, your old PATH can be restored from it.)"

# Tracks which tools THIS script actually installed vs. found already
# present (and therefore left alone). The companion uninstall script reads
# this and only removes entries marked $true here - so it never touches a
# tool you already had installed before running this script.
#
# IMPORTANT: this starts from any EXISTING manifest (if this script has been
# run before) rather than a blank slate. Otherwise, running the script a
# second time - e.g. to double-check the verification output, as the final
# message suggests - would see every tool already installed, skip every
# install branch below, and then overwrite the manifest with all-false,
# permanently losing the record that an earlier run installed them (which
# would make the uninstaller think nothing is safe to remove).
if (Test-Path $ManifestPath) {
    $existingManifest = Get-Content $ManifestPath -Raw | ConvertFrom-Json
} else {
    $existingManifest = $null
}
function Get-PriorFlag($name) {
    if ($existingManifest -and $existingManifest.PSObject.Properties[$name]) {
        return [bool]$existingManifest.$name
    }
    return $false
}
$Manifest = @{
    cmake    = Get-PriorFlag "cmake"
    ninja    = Get-PriorFlag "ninja"
    python   = Get-PriorFlag "python"
    git      = Get-PriorFlag "git"
    wget     = Get-PriorFlag "wget"
    sevenzip = Get-PriorFlag "sevenzip"
    gperfdtc = Get-PriorFlag "gperfdtc"
}

function Add-UserPath($dir, [switch]$Prepend) {
    $userPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
    $parts = @($userPath -split ';' | Where-Object { $_ -and $_ -ne $dir })
    if ($Prepend) {
        # Used for Python: puts $dir ahead of whatever's already on PATH so
        # it wins over the built-in WindowsApps python.exe alias stub (see
        # Test-RealPython below), which a plain append could still lose to.
        $newUserPath = ($dir + ';' + ($parts -join ';'))
    } elseif ($userPath -notlike "*$dir*") {
        $newUserPath = "$userPath;$dir"
    }
    if ($newUserPath -and $newUserPath -ne $userPath) {
        [System.Environment]::SetEnvironmentVariable("Path", $newUserPath, "User")
        Write-Host "  Added $dir to your User PATH."
    }
    if ($Prepend) {
        $envParts = @($env:Path -split ';' | Where-Object { $_ -and $_ -ne $dir })
        $env:Path = ($dir + ';' + ($envParts -join ';'))
    } elseif ($env:Path -notlike "*$dir*") {
        $env:Path += ";$dir"
    }
}

# Windows drops fake python.exe / python3.exe "App execution alias" stubs
# into %LOCALAPPDATA%\Microsoft\WindowsApps on every Windows 10/11 profile,
# whether or not Python is actually installed from the Microsoft Store.
# Get-Command finds these stubs just like a real interpreter, but running
# one either silently opens the Store or errors out - which is exactly the
# "found but failed to run" symptom this works around. Treat that stub, or
# any python.exe that doesn't actually print a version, as "not installed"
# so the script proceeds to install a real one instead of skipping.
function Test-RealPython {
    $cmd = Get-Command python -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $cmd) { return $false }
    if ($cmd.Source -like "*\WindowsApps\python.exe") {
        Write-Host "  Found python.exe at $($cmd.Source) - that's the Windows Store alias stub, not a real interpreter. Treating as not installed."
        return $false
    }
    try {
        $out = & $cmd.Source --version 2>&1
        if ($LASTEXITCODE -eq 0 -and $out -match "^Python \d") { return $true }
        Write-Host "  Found python.exe at $($cmd.Source) but it didn't report a version (exit $LASTEXITCODE, output: $out). Treating as not installed."
        return $false
    } catch {
        Write-Host "  Found python.exe at $($cmd.Source) but running it threw: $($_.Exception.Message). Treating as not installed."
        return $false
    }
}

function Get-File($url, $dest) {
    if (Test-Path $dest) { return }
    Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing
}

# Runs an installer with a visible (but unattended) progress bar instead of
# fully silent, so it doesn't look hung during the minute-plus some of these
# take, and reports the exit code so a failure is visible instead of silent.
function Invoke-Installer($label, $path, $installerArgs) {
    Write-Host "  Installing $label - a progress window may appear, please wait..."
    $proc = Start-Process -FilePath $path -ArgumentList $installerArgs -Wait -PassThru
    if ($proc.ExitCode -ne 0) {
        Write-Warning "  $label installer exited with code $($proc.ExitCode) - it may not have installed correctly."
    } else {
        Write-Host "  $label installer finished (exit code 0)." -ForegroundColor Green
    }
    return $proc.ExitCode
}

# Pinned versions (checked 2026-08-21). Bump these periodically; a stale
# link just means a slower/older install, not a broken one, since these are
# all direct vendor/GitHub-release URLs rather than a rolling "latest" alias.

# 1. CMake (portable zip, official Kitware release - not the MSI)
# NOTE: the official CMake MSI hardcodes ALLUSERS=1 and installs under
# Program Files regardless of the ADD_CMAKE_TO_PATH property (that property
# only controls PATH scope, not install scope), so it always triggers a UAC
# elevation prompt. The zip is a plain extract-only distribution with no
# installer, so it's used here instead - same no-admin approach as Ninja.
Write-Step "CMake 4.4.2"
$cmakeZip = Join-Path $TempDir "cmake-4.4.2-windows-x86_64.zip"
$cmakeDir = Join-Path $ToolsDir "cmake"
Get-File "https://github.com/Kitware/CMake/releases/download/v4.4.2/cmake-4.4.2-windows-x86_64.zip" $cmakeZip
if (-not (Test-Path (Join-Path $cmakeDir "bin\cmake.exe"))) {
    New-Item -ItemType Directory -Path $cmakeDir -Force | Out-Null
    Expand-Archive -Path $cmakeZip -DestinationPath $cmakeDir -Force
    # The zip contains a single top-level folder (e.g. cmake-4.4.2-windows-x86_64\...);
    # flatten it so $cmakeDir\bin\cmake.exe is a stable path across versions.
    $extractedRoot = Get-ChildItem -Path $cmakeDir -Directory | Select-Object -First 1
    if ($extractedRoot) {
        Get-ChildItem -Path $extractedRoot.FullName | Move-Item -Destination $cmakeDir -Force
        Remove-Item -Path $extractedRoot.FullName -Force -Recurse
    }
    $Manifest.cmake = $true
} else { Write-Host "  cmake already installed, skipping." }
Add-UserPath (Join-Path $cmakeDir "bin")

# 2. Ninja (single static exe in a zip - no installer)
Write-Step "Ninja 1.13.2"
$ninjaZip = Join-Path $TempDir "ninja-win.zip"
$ninjaDir = Join-Path $ToolsDir "ninja"
Get-File "https://github.com/ninja-build/ninja/releases/download/v1.13.2/ninja-win.zip" $ninjaZip
if (-not (Test-Path (Join-Path $ninjaDir "ninja.exe"))) {
    New-Item -ItemType Directory -Path $ninjaDir -Force | Out-Null
    Expand-Archive -Path $ninjaZip -DestinationPath $ninjaDir -Force
    $Manifest.ninja = $true
}
Add-UserPath $ninjaDir

# 3. Python (official python.org installer)
# NOTE: 3.12 exited "bugfix" support 2025-04-02; python.org stops publishing
# Windows .exe installers for a branch once it's security-fixes-only, so
# 3.12.10 (Apr 2025) - not the newer source-only 3.12.14 - is the last
# 3.12.x release with a Windows installer available.
Write-Step "Python 3.12.10"
$pyExe = Join-Path $TempDir "python-3.12.10-amd64.exe"
$pyLog = Join-Path $TempDir "python-install.log"
Get-File "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe" $pyExe
$pyInstallDir = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312"
$pyAlreadyOurs = Test-Path (Join-Path $pyInstallDir "python.exe")
if ($pyAlreadyOurs) {
    # A prior run already installed Python here. Don't trust `Get-Command`
    # to decide whether to (re)install - it reflects this process's
    # in-memory PATH, which can differ from the persisted User PATH in the
    # registry (e.g. if a previous run only patched $env:Path transiently).
    # A brand-new terminal only sees the registry value, so always re-check
    # and re-apply PATH below regardless of what Get-Command reports here.
    Write-Host "  python already installed at $pyInstallDir, ensuring PATH is set."
} elseif (Test-RealPython) {
    Write-Host "  python already installed (found elsewhere on PATH), skipping."
} else {
    Invoke-Installer "Python" $pyExe "/passive InstallAllUsers=0 PrependPath=1 Include_test=0 Include_launcher=0 /log `"$pyLog`"" | Out-Null
    $Manifest.python = $true
}
if ($pyAlreadyOurs -or $Manifest.python) {
    # Belt-and-suspenders: add Python's per-user install dir + Scripts
    # folder to PATH ourselves, instead of relying solely on the
    # installer's PrependPath option (which only fires on a fresh install,
    # not on a no-op "modify" of an already-present package). Prepend (not
    # append) so this real install wins over the WindowsApps python.exe
    # stub, which Windows puts on PATH ahead of anything a plain append
    # would add.
    Add-UserPath $pyInstallDir -Prepend
    Add-UserPath (Join-Path $pyInstallDir "Scripts") -Prepend
}
if (-not (Test-RealPython)) {
    Write-Warning "  python still not found (or not runnable) on PATH after install. Check the log: $pyLog"
}

# 4. Git for Windows (Inno Setup installer)
Write-Step "Git for Windows 2.55.0.5"
$gitExe = Join-Path $TempDir "Git-2.55.0.5-64-bit.exe"
Get-File "https://github.com/git-for-windows/git/releases/download/v2.55.0.windows.5/Git-2.55.0.5-64-bit.exe" $gitExe
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Invoke-Installer "Git for Windows" $gitExe "/SILENT /NORESTART /NOCANCEL /SP- /SUPPRESSMSGBOXES /CURRENTUSER" | Out-Null
    $Manifest.git = $true
} else { Write-Host "  git already installed, skipping." }

# 5. wget (static exe, no installer - eternallybored.org build)
Write-Step "wget 1.21.4"
$wgetZip = Join-Path $TempDir "wget-1.21.4-win64.zip"
$wgetDir = Join-Path $ToolsDir "wget"
Get-File "https://eternallybored.org/misc/wget/releases/wget-1.21.4-win64.zip" $wgetZip
if (-not (Test-Path (Join-Path $wgetDir "wget.exe"))) {
    New-Item -ItemType Directory -Path $wgetDir -Force | Out-Null
    Expand-Archive -Path $wgetZip -DestinationPath $wgetDir -Force
    $Manifest.wget = $true
}
Add-UserPath $wgetDir

# 6. 7-Zip (portable "extra" console package, official - not the MSI/exe installer)
# NOTE: 7-Zip's MSI sets ALLUSERS=2 ("per-user if the account isn't an
# admin, else per-machine"). On an account that's a member of the local
# Administrators group (common on Infineon-managed laptops, even when not
# running elevated), that resolves to a per-machine install under Program
# Files, which triggers a UAC prompt - breaking the no-admin-rights goal
# the same way the CMake MSI did. Kitware-style zips aren't published for
# 7-Zip, but the official "7z2602-extra.7z" package is a plain archive
# containing the standalone 7za.exe console build with no installer at
# all. 7zr.exe (a tiny standalone .exe, not an installer) is used first to
# extract that archive, since it isn't a .zip Expand-Archive can open.
Write-Step "7-Zip 26.02"
$sevenZipDir = Join-Path $ToolsDir "7-zip"
if (-not (Test-Path (Join-Path $sevenZipDir "7z.exe"))) {
    $sevenZr = Join-Path $TempDir "7zr.exe"
    $sevenExtra = Join-Path $TempDir "7z2602-extra.7z"
    Get-File "https://github.com/ip7z/7zip/releases/download/26.02/7zr.exe" $sevenZr
    Get-File "https://github.com/ip7z/7zip/releases/download/26.02/7z2602-extra.7z" $sevenExtra
    New-Item -ItemType Directory -Path $sevenZipDir -Force | Out-Null
    $extractProc = Start-Process -FilePath $sevenZr -ArgumentList "x `"$sevenExtra`" -o`"$sevenZipDir`" -y x64\*" -Wait -PassThru -WindowStyle Hidden
    if ($extractProc.ExitCode -ne 0) {
        Write-Warning "  7-Zip extraction exited with code $($extractProc.ExitCode)."
    }
    # The extra package's x64 build extracts into a nested x64\ subfolder;
    # flatten it and name the console exe 7z.exe (its usual public name),
    # matching how other tools in this script (e.g. dtc, gperf) expose
    # themselves once extracted.
    $x64Dir = Join-Path $sevenZipDir "x64"
    if (Test-Path $x64Dir) {
        Get-ChildItem -Path $x64Dir | Move-Item -Destination $sevenZipDir -Force
        Remove-Item -Path $x64Dir -Force -Recurse
    }
    $sevenZa = Join-Path $sevenZipDir "7za.exe"
    if (Test-Path $sevenZa) { Copy-Item $sevenZa (Join-Path $sevenZipDir "7z.exe") -Force }
    $Manifest.sevenzip = $true
} else { Write-Host "  7z already installed, skipping." }
Add-UserPath $sevenZipDir

# 7. gperf + dtc (bundled zip, not available as a native installer)
Write-Step "gperf + dtc (device-tree compiler)"
$bundleZip = Join-Path $ScriptDir "gperf-dtc-windows-bundle.zip"
$gperfDtcDir = Join-Path $ToolsDir "gperf-dtc"
if (Test-Path $bundleZip) {
    if (-not (Test-Path (Join-Path $gperfDtcDir "dtc.exe"))) {
        New-Item -ItemType Directory -Path $gperfDtcDir -Force | Out-Null
        Expand-Archive -Path $bundleZip -DestinationPath $gperfDtcDir -Force
        $Manifest.gperfdtc = $true
    }
    Add-UserPath $gperfDtcDir
} else {
    Write-Warning "gperf-dtc-windows-bundle.zip not found next to this script - skipping gperf/dtc install."
}

# Persist the install manifest so the companion uninstall script only
# removes what THIS script actually installed, never a tool you already had.
$Manifest | ConvertTo-Json | Set-Content -Path $ManifestPath -Encoding UTF8
Write-Host "`nInstall manifest written to $ManifestPath (used by the uninstall script)."

# Refresh PATH in this process so freshly-installed tools resolve without
# reopening the shell (installer-added Machine/User PATH entries + ours).
$env:Path = [System.Environment]::GetEnvironmentVariable("Path", "User") + ";" +
            [System.Environment]::GetEnvironmentVariable("Path", "Machine")

# 8. Verify everything
Write-Step "Verifying installed tools"
$tools = @(
    @{ Name = "cmake";  Args = "--version" },
    @{ Name = "ninja";  Args = "--version" },
    @{ Name = "python";  Args = "--version" },
    @{ Name = "git";    Args = "--version" },
    @{ Name = "wget";   Args = "--version" },
    @{ Name = "7z";     Args = "" },
    @{ Name = "gperf";  Args = "--version" },
    @{ Name = "dtc";    Args = "-v" }
)
foreach ($t in $tools) {
    $cmd = Get-Command $t.Name -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($cmd) {
        try {
            # Collect ALL output before selecting the first line. Windows
            # PowerShell 5.1 sets $LASTEXITCODE to -1 whenever a still-running
            # native process's output is piped directly into `Select-Object
            # -First N` (confirmed via repeated local repro: cmake/ninja/git
            # --version always report exit -1 that way, even though the
            # correct version string is printed and the process genuinely
            # exits 0). Letting the process finish and close its output
            # first, then slicing the array afterwards, avoids the pipeline
            # early-stop signal that causes the false -1.
            $allOut = & $cmd.Source $t.Args 2>&1
            $exitCode = $LASTEXITCODE
            $out = @($allOut) | Select-Object -First 1
            if ($exitCode -and $exitCode -ne 0) {
                Write-Host ("  [??] {0,-8} at {1} exited {2}: {3}" -f $t.Name, $cmd.Source, $exitCode, $out) -ForegroundColor Yellow
            } else {
                Write-Host ("  [OK] {0,-8} {1}" -f $t.Name, $out) -ForegroundColor Green
            }
        } catch {
            Write-Host ("  [??] {0,-8} at {1} threw: {2}" -f $t.Name, $cmd.Source, $_.Exception.Message) -ForegroundColor Yellow
        }
    } else {
        Write-Host ("  [MISSING] {0}" -f $t.Name) -ForegroundColor Red
    }
}

Write-Step "Done. Close and reopen your terminal, then re-run this script's verification section if anything shows MISSING."
